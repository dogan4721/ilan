import React, { useState, useMemo, useEffect } from 'react';
import { StorageService } from './services/storage';
import { FirestoreService } from './firebase/firestoreService';
import { useAuth } from './context/AuthContext';
import { Listing, User, CategoryId, ListingType } from './types';
import { TURGUTLU_NEIGHBORHOODS } from './data/turgutluData';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { MobileNav } from './components/MobileNav';
import { ListingCard } from './components/ListingCard';
import { ListingDetailModal } from './components/ListingDetailModal';
import { PostListingWizard } from './components/PostListingWizard';
import { UserDashboard } from './components/UserDashboard';
import { AdminPanel } from './components/AdminPanel';
import { RealtorPortal } from './components/RealtorPortal';
import { PaymentModal } from './components/PaymentModal';
import { OfferModal } from './components/OfferModal';
import { ReportModal } from './components/ReportModal';
import { TurgutluMapModal } from './components/TurgutluMapModal';
import { AuthModal } from './components/AuthModal';
import { AiAssistantModal } from './components/AiAssistantModal';
import {
  Search,
  SlidersHorizontal,
  MapPin,
  Sparkles,
  ArrowUpDown,
  Building2,
  Car,
  Smartphone,
  Armchair,
  Wheat,
  Briefcase,
  X,
  Compass,
  CheckCircle2,
  RotateCcw,
  Flame,
  Info
} from 'lucide-react';

export default function App() {
  const { user: authUser, isLiveFirebase, logout } = useAuth();

  // App State
  const [currentUser, setCurrentUser] = useState<User>(() => authUser || StorageService.getCurrentUser());
  const [listings, setListings] = useState<Listing[]>(() => StorageService.getListings());
  const [favorites, setFavorites] = useState<string[]>(() => StorageService.getFavorites());
  const [activeView, setActiveView] = useState<'home' | 'dashboard' | 'realtor-portal' | 'categories'>('home');
  const [dashboardTab, setDashboardTab] = useState<string>('ilanlarim');
  const [announcement, setAnnouncement] = useState<string>(() => StorageService.getAnnouncement());

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedSubcategory, setSelectedSubcategory] = useState<string>('all');
  const [selectedNeighborhood, setSelectedNeighborhood] = useState<string>('all');
  const [selectedListingType, setSelectedListingType] = useState<string>('all');
  const [minPrice, setMinPrice] = useState<string>('');
  const [maxPrice, setMaxPrice] = useState<string>('');
  const [sortBy, setSortBy] = useState<'recommended' | 'newest' | 'price-asc' | 'price-desc' | 'popular'>('recommended');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  // Modals State
  const [selectedListing, setSelectedListing] = useState<Listing | null>(null);
  const [isPostListingOpen, setIsPostListingOpen] = useState(false);
  const [isOfferModalOpen, setIsOfferModalOpen] = useState(false);
  const [offerTargetListing, setOfferTargetListing] = useState<Listing | null>(null);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [reportTargetListing, setReportTargetListing] = useState<Listing | null>(null);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentConfig, setPaymentConfig] = useState({ packageName: 'Ana Sayfa Vitrin Paketi (30 Gün)', amount: 299 });
  const [isMapModalOpen, setIsMapModalOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isAiAssistantOpen, setIsAiAssistantOpen] = useState(false);
  const [aiAssistantListingContext, setAiAssistantListingContext] = useState<Listing | null>(null);

  // Sync auth user
  useEffect(() => {
    if (authUser) {
      setCurrentUser(authUser);
    }
  }, [authUser]);

  // Real-time Firestore sync
  useEffect(() => {
    if (isLiveFirebase) {
      const unsub = FirestoreService.subscribeListings((newListings) => {
        if (newListings && newListings.length > 0) {
          setListings(newListings);
        }
      });
      return () => unsub();
    }
  }, [isLiveFirebase]);

  // Re-sync with Storage
  const refreshData = () => {
    setListings(StorageService.getListings());
    setFavorites(StorageService.getFavorites());
    setCurrentUser(StorageService.getCurrentUser());
    setAnnouncement(StorageService.getAnnouncement());
  };

  const categories = StorageService.getCategories();
  const currentCategoryObj = categories.find((c) => c.id === selectedCategory);

  // Toggle Favorite
  const handleToggleFavorite = (listingId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    StorageService.toggleFavorite(listingId);
    setFavorites(StorageService.getFavorites());
    setListings(StorageService.getListings());
  };

  // Open detail
  const handleOpenDetail = (listing: Listing) => {
    StorageService.incrementView(listing.id);
    setSelectedListing(listing);
    setListings(StorageService.getListings());
  };

  // Protected Action: Post Listing
  const handleOpenPostListingGuard = () => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      return;
    }
    setIsPostListingOpen(true);
  };

  // Protected Action: Offer
  const handleOpenOfferModalGuard = (listing: Listing) => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      return;
    }
    setOfferTargetListing(listing);
    setIsOfferModalOpen(true);
  };

  // Protected Action: Message
  const handleOpenMessageModalGuard = (listing: Listing) => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      return;
    }
    StorageService.sendMessage({
      listingId: listing.id,
      text: `Merhaba, "${listing.title}" ilanınız hakkında detaylı bilgi almak istiyorum.`
    });
    setActiveView('dashboard');
    setDashboardTab('mesajlarim');
  };

  // Open Report Modal
  const handleOpenReportModal = (listing: Listing) => {
    setReportTargetListing(listing);
    setIsReportModalOpen(true);
  };

  // Open Payment modal with config
  const handleOpenPayment = (packageName: string, amount: number) => {
    setPaymentConfig({ packageName, amount });
    setIsPaymentModalOpen(true);
  };

  // Reset Filters
  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedSubcategory('all');
    setSelectedNeighborhood('all');
    setSelectedListingType('all');
    setMinPrice('');
    setMaxPrice('');
    setSortBy('recommended');
  };

  // Filtered & Sorted Listings
  const filteredListings = useMemo(() => {
    let result = listings.filter((item) => item.status === 'active');

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        (item) =>
          item.title.toLowerCase().includes(q) ||
          item.description.toLowerCase().includes(q) ||
          item.neighborhood.toLowerCase().includes(q) ||
          item.subcategory.toLowerCase().includes(q) ||
          (item.specs.roomCount && item.specs.roomCount.toLowerCase().includes(q)) ||
          (item.specs.brand && item.specs.brand.toLowerCase().includes(q))
      );
    }

    // Category
    if (selectedCategory !== 'all') {
      result = result.filter((item) => item.categoryId === selectedCategory);
    }

    // Subcategory
    if (selectedSubcategory !== 'all') {
      result = result.filter((item) => item.subcategory === selectedSubcategory);
    }

    // Neighborhood
    if (selectedNeighborhood !== 'all') {
      result = result.filter((item) => item.neighborhood === selectedNeighborhood);
    }

    // Listing Type
    if (selectedListingType !== 'all') {
      result = result.filter((item) => item.listingType === selectedListingType);
    }

    // Price
    if (minPrice) {
      const min = parseFloat(minPrice.replace(/[^0-9]/g, ''));
      if (!isNaN(min)) {
        result = result.filter((item) => item.price >= min);
      }
    }
    if (maxPrice) {
      const max = parseFloat(maxPrice.replace(/[^0-9]/g, ''));
      if (!isNaN(max)) {
        result = result.filter((item) => item.price <= max);
      }
    }

    // Sorting
    return result.sort((a, b) => {
      if (sortBy === 'newest') {
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
      if (sortBy === 'price-asc') {
        return a.price - b.price;
      }
      if (sortBy === 'price-desc') {
        return b.price - a.price;
      }
      if (sortBy === 'popular') {
        return (b.viewCount || 0) - (a.viewCount || 0);
      }
      if (a.isFeatured && !b.isFeatured) return -1;
      if (!a.isFeatured && b.isFeatured) return 1;
      return (b.favoriteCount || 0) - (a.favoriteCount || 0);
    });
  }, [
    listings,
    searchQuery,
    selectedCategory,
    selectedSubcategory,
    selectedNeighborhood,
    selectedListingType,
    minPrice,
    maxPrice,
    sortBy
  ]);

  // Featured Listings for vitrin
  const featuredListings = useMemo(() => {
    return listings.filter((l) => l.isFeatured && l.status === 'active');
  }, [listings]);

  const hasActiveFilters =
    searchQuery !== '' ||
    selectedCategory !== 'all' ||
    selectedSubcategory !== 'all' ||
    selectedNeighborhood !== 'all' ||
    selectedListingType !== 'all' ||
    minPrice !== '' ||
    maxPrice !== '';

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans">
      {/* Announcement Banner (Only if present) */}
      {announcement && (
        <div className="bg-emerald-900 text-emerald-100 text-xs py-1.5 px-4 text-center font-semibold border-b border-emerald-800 flex items-center justify-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          <span>{announcement}</span>
        </div>
      )}

      {/* Main Header */}
      <Header
        currentUser={currentUser}
        onOpenPostListing={handleOpenPostListingGuard}
        onOpenDashboard={(tab) => {
          setActiveView('dashboard');
          if (tab) setDashboardTab(tab);
        }}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onOpenRealtorPortal={() => setActiveView('realtor-portal')}
        onOpenMap={() => setIsMapModalOpen(true)}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onOpenAiAssistant={() => {
          setAiAssistantListingContext(null);
          setIsAiAssistantOpen(true);
        }}
        onSelectCategoryFilter={(catId) => {
          setActiveView('home');
          setSelectedCategory(catId);
          setSelectedSubcategory('all');
        }}
      />

      {/* Main Body Switcher */}
      <main className="flex-1">
        {activeView === 'dashboard' && (
          <UserDashboard
            currentUser={currentUser}
            onNavigateToListing={handleOpenDetail}
            onOpenPaymentModal={handleOpenPayment}
            onOpenPostListing={handleOpenPostListingGuard}
            initialTab={dashboardTab}
          />
        )}

        {activeView === 'realtor-portal' && (
          <RealtorPortal
            onNavigateToListing={handleOpenDetail}
            onOpenOfferModal={handleOpenOfferModalGuard}
            onOpenMessageModal={handleOpenMessageModalGuard}
          />
        )}

        {activeView === 'categories' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
            <h1 className="text-2xl font-bold text-slate-900">Turgutlu Kategorileri</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {categories.map((cat) => (
                <div key={cat.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
                  <div className="flex items-center gap-2.5 font-bold text-base text-slate-900">
                    <span className="text-emerald-600">
                      {cat.id === 'emlak' && <Building2 className="w-5 h-5" />}
                      {cat.id === 'arac' && <Car className="w-5 h-5" />}
                      {cat.id === 'elektronik' && <Smartphone className="w-5 h-5" />}
                      {cat.id === 'ev-yasam' && <Armchair className="w-5 h-5" />}
                      {cat.id === 'tarim' && <Wheat className="w-5 h-5" />}
                      {cat.id === 'is-hizmet' && <Briefcase className="w-5 h-5" />}
                    </span>
                    <span>{cat.name}</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5 pt-2">
                    {cat.subcategories.map((sub) => (
                      <button
                        key={sub}
                        onClick={() => {
                          setSelectedCategory(cat.id);
                          setSelectedSubcategory(sub);
                          setActiveView('home');
                        }}
                        className="px-2.5 py-1 bg-slate-50 hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 rounded-lg text-xs font-medium border border-slate-200/80 transition-colors"
                      >
                        {sub}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeView === 'home' && (
          <div className="space-y-8 pb-12">
            {/* HERO SECTION WITH SEARCH ENGINE */}
            <section className="relative bg-gradient-to-b from-white via-slate-50/80 to-slate-50 border-b border-slate-200/80 pt-8 pb-10">
              <div className="max-w-5xl mx-auto px-4 sm:px-6 text-center space-y-6">
                <div>
                  <span className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-800 bg-emerald-50 border border-emerald-200/70 px-3 py-1 rounded-full mb-3">
                    <MapPin className="w-3.5 h-3.5 text-emerald-600" /> Manisa / Turgutlu ve Gediz Ovası
                  </span>
                  <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight">
                    Turgutlu’da Güvenli Emlak ve Yerel Alım Satım
                  </h1>
                  <p className="text-slate-600 text-xs sm:text-sm mt-2 max-w-xl mx-auto">
                    İstasyonaltı, Subaşı, Selvilitepe ve tüm mahallelerde satılık daire, bağ, tarla, traktör ve vasıta ilanları.
                  </p>
                </div>

                {/* Primary Search Bar Container */}
                <div className="bg-white rounded-2xl shadow-xl border border-slate-200/90 p-3 sm:p-4 text-left space-y-3">
                  <div className="flex flex-col md:flex-row items-stretch gap-2">
                    {/* Main Text Input */}
                    <div className="relative flex-1">
                      <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        placeholder="Ne arıyorsunuz? (Örn: 3+1 İstasyonaltı daire, traktör, arsa)"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 text-sm font-medium text-slate-900 placeholder:text-slate-400"
                      />
                      {searchQuery && (
                        <button
                          onClick={() => setSearchQuery('')}
                          className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    {/* Quick Filters Row inside Hero */}
                    <div className="flex items-center gap-2">
                      {/* Neighborhood Selector */}
                      <div className="relative min-w-[150px] flex-1 sm:flex-initial">
                        <select
                          value={selectedNeighborhood}
                          onChange={(e) => setSelectedNeighborhood(e.target.value)}
                          className="w-full px-3 py-3 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 bg-white focus:border-emerald-600 truncate"
                        >
                          <option value="all">Tüm Mahalleler</option>
                          {TURGUTLU_NEIGHBORHOODS.map((nh) => (
                            <option key={nh} value={nh}>
                              {nh} Mah.
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Map View Toggle */}
                      <button
                        onClick={() => setIsMapModalOpen(true)}
                        className="px-3.5 py-3 rounded-xl border border-slate-200 hover:border-emerald-600 text-emerald-700 font-bold text-xs flex items-center gap-1.5 transition-colors whitespace-nowrap bg-emerald-50/40"
                      >
                        <Compass className="w-4 h-4 text-emerald-600" />
                        <span className="hidden sm:inline">Haritada Gör</span>
                      </button>

                      {/* Advanced Filters Toggle */}
                      <button
                        onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
                        className={`p-3 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition-colors ${
                          showAdvancedFilters || hasActiveFilters
                            ? 'bg-slate-900 text-white border-slate-900'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <SlidersHorizontal className="w-4 h-4" />
                        <span className="hidden sm:inline">Filtreler</span>
                      </button>
                    </div>
                  </div>

                  {/* Expandable Advanced Filters */}
                  {showAdvancedFilters && (
                    <div className="pt-3 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs animate-in fade-in duration-100">
                      <div>
                        <label className="block text-slate-500 font-semibold mb-1">Kategori</label>
                        <select
                          value={selectedCategory}
                          onChange={(e) => {
                            setSelectedCategory(e.target.value);
                            setSelectedSubcategory('all');
                          }}
                          className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                        >
                          <option value="all">Tüm Kategoriler</option>
                          {categories.map((c) => (
                            <option key={c.id} value={c.id}>
                              {c.name}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-slate-500 font-semibold mb-1">İlan Türü</label>
                        <select
                          value={selectedListingType}
                          onChange={(e) => setSelectedListingType(e.target.value)}
                          className="w-full p-2 border border-slate-200 rounded-lg bg-white"
                        >
                          <option value="all">Tümü (Satılık & Kiralık)</option>
                          <option value="satilik">Satılık</option>
                          <option value="kiralik">Kiralık</option>
                          <option value="ikinci-el">İkinci El</option>
                          <option value="sifir">Sıfır</option>
                          <option value="hizmet">Hizmet</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-slate-500 font-semibold mb-1">En Az Fiyat (TL)</label>
                        <input
                          type="text"
                          placeholder="Min TL"
                          value={minPrice}
                          onChange={(e) => setMinPrice(e.target.value)}
                          className="w-full p-2 border border-slate-200 rounded-lg tabular-nums"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-500 font-semibold mb-1">En Çok Fiyat (TL)</label>
                        <input
                          type="text"
                          placeholder="Max TL"
                          value={maxPrice}
                          onChange={(e) => setMaxPrice(e.target.value)}
                          className="w-full p-2 border border-slate-200 rounded-lg tabular-nums"
                        />
                      </div>

                      {hasActiveFilters && (
                        <div className="col-span-2 sm:col-span-4 flex justify-end pt-1">
                          <button
                            onClick={handleResetFilters}
                            className="text-xs text-rose-600 hover:underline flex items-center gap-1 font-semibold"
                          >
                            <RotateCcw className="w-3 h-3" /> Filtreleri Temizle
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Category Navigation Pills Bar */}
                <div className="flex items-center justify-center gap-2 overflow-x-auto pb-1 max-w-full">
                  <button
                    onClick={() => {
                      setSelectedCategory('all');
                      setSelectedSubcategory('all');
                    }}
                    className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                      selectedCategory === 'all'
                        ? 'bg-slate-900 text-white shadow-xs'
                        : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    Tüm İlanlar
                  </button>

                  {categories.map((c) => {
                    const active = selectedCategory === c.id;
                    return (
                      <button
                        key={c.id}
                        onClick={() => {
                          setSelectedCategory(c.id);
                          setSelectedSubcategory('all');
                        }}
                        className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                          active
                            ? 'bg-emerald-600 text-white shadow-xs'
                            : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        {c.id === 'emlak' && <Building2 className="w-3.5 h-3.5" />}
                        {c.id === 'arac' && <Car className="w-3.5 h-3.5" />}
                        {c.id === 'elektronik' && <Smartphone className="w-3.5 h-3.5" />}
                        {c.id === 'ev-yasam' && <Armchair className="w-3.5 h-3.5" />}
                        {c.id === 'tarim' && <Wheat className="w-3.5 h-3.5" />}
                        {c.id === 'is-hizmet' && <Briefcase className="w-3.5 h-3.5" />}
                        <span>{c.name}</span>
                      </button>
                    );
                  })}
                </div>

                {/* Subcategories row when a category is selected */}
                {currentCategoryObj && selectedCategory !== 'all' && (
                  <div className="flex items-center justify-center gap-1.5 flex-wrap pt-1 text-xs">
                    <button
                      onClick={() => setSelectedSubcategory('all')}
                      className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                        selectedSubcategory === 'all'
                          ? 'bg-emerald-100 text-emerald-900 font-bold'
                          : 'text-slate-600 hover:bg-slate-200/60'
                      }`}
                    >
                      Tümü
                    </button>
                    {currentCategoryObj.subcategories.map((sub) => (
                      <button
                        key={sub}
                        onClick={() => setSelectedSubcategory(sub)}
                        className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                          selectedSubcategory === sub
                            ? 'bg-emerald-100 text-emerald-900 font-bold'
                            : 'text-slate-600 hover:bg-slate-200/60'
                        }`}
                      >
                        {sub}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </section>

            {/* FEATURED / VITRIN SECTION */}
            {selectedCategory === 'all' && !searchQuery && featuredListings.length > 0 && (
              <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <div className="p-1 rounded bg-amber-500 text-white">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div>
                      <h2 className="text-base sm:text-lg font-extrabold text-slate-900">
                        Turgutlu Vitrin İlanları
                      </h2>
                      <p className="text-xs text-slate-500">Öne çıkan gayrimenkul ve fırsat ürünleri</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setIsMapModalOpen(true)}
                    className="text-xs font-semibold text-emerald-700 hover:underline flex items-center gap-1"
                  >
                    <Compass className="w-3.5 h-3.5" /> Haritada İncele
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                  {featuredListings.slice(0, 3).map((listing) => (
                    <ListingCard
                      key={`feat-${listing.id}`}
                      listing={listing}
                      isFavorite={favorites.includes(listing.id)}
                      onToggleFavorite={handleToggleFavorite}
                      onClick={handleOpenDetail}
                    />
                  ))}
                </div>
              </section>
            )}

            {/* MAIN LISTINGS SECTION */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
              {/* Section Header with Sort Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200">
                <div>
                  <h2 className="text-lg font-bold text-slate-900">
                    {selectedCategory === 'all'
                      ? 'Güncel Turgutlu İlanları'
                      : `${currentCategoryObj?.name} İlanları`}
                    {selectedNeighborhood !== 'all' && ` · ${selectedNeighborhood} Mah.`}
                  </h2>
                  <span className="text-xs text-slate-500 font-medium">
                    {filteredListings.length} ilan bulundu
                  </span>
                </div>

                {/* Sorting Controls */}
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500 font-medium hidden sm:inline">Sıralama:</span>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 bg-white"
                  >
                    <option value="recommended">Önerilen İlanlar</option>
                    <option value="newest">En Yeni İlanlar</option>
                    <option value="price-asc">Fiyat (Önce En Düşük)</option>
                    <option value="price-desc">Fiyat (Önce En Yüksek)</option>
                    <option value="popular">En Çok Görüntülenen</option>
                  </select>
                </div>
              </div>

              {/* Listings Grid */}
              {filteredListings.length === 0 ? (
                <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
                  <Search className="w-12 h-12 text-slate-300 mx-auto" />
                  <h3 className="font-bold text-slate-800 text-base">Aradığınız kriterlere uygun ilan bulunamadı</h3>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    Filtreleri temizleyerek veya daha genel bir arama terimi kullanarak tekrar deneyebilirsiniz.
                  </p>
                  <button
                    onClick={handleResetFilters}
                    className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold"
                  >
                    Tüm Filtreleri Temizle
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                  {filteredListings.map((listing) => (
                    <ListingCard
                      key={listing.id}
                      listing={listing}
                      isFavorite={favorites.includes(listing.id)}
                      onToggleFavorite={handleToggleFavorite}
                      onClick={handleOpenDetail}
                    />
                  ))}
                </div>
              )}
            </section>
          </div>
        )}
      </main>

      {/* Footer */}
      <Footer
        onSelectNeighborhoodFilter={(nh) => {
          setActiveView('home');
          setSelectedNeighborhood(nh);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onSelectCategoryFilter={(cat) => {
          setActiveView('home');
          setSelectedCategory(cat);
          setSelectedSubcategory('all');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Mobile Sticky Bottom Nav Bar */}
      <MobileNav
        activeScreen={activeView}
        onNavigateHome={() => setActiveView('home')}
        onOpenCategories={() => setActiveView('categories')}
        onOpenPostListing={handleOpenPostListingGuard}
        onOpenMessages={() => {
          setActiveView('dashboard');
          setDashboardTab('mesajlarim');
        }}
        onOpenProfile={() => {
          setActiveView('dashboard');
          setDashboardTab('profil');
        }}
      />

      {/* MODALS */}
      {/* 1. Listing Detail Modal */}
      <ListingDetailModal
        listing={selectedListing}
        isOpen={!!selectedListing}
        onClose={() => setSelectedListing(null)}
        isFavorite={selectedListing ? favorites.includes(selectedListing.id) : false}
        onToggleFavorite={handleToggleFavorite}
        onOpenOfferModal={handleOpenOfferModalGuard}
        onOpenMessageModal={handleOpenMessageModalGuard}
        onOpenReportModal={handleOpenReportModal}
        onOpenAiValuation={(listing) => {
          setAiAssistantListingContext(listing);
          setIsAiAssistantOpen(true);
        }}
        currentUser={currentUser}
        onAdminRemoveListing={(listingId) => {
          StorageService.deleteListing(listingId);
          refreshData();
          setSelectedListing(null);
        }}
        onAdminTogglePassive={(listingId, currentStatus) => {
          const next = currentStatus === 'active' ? 'passive' : 'active';
          StorageService.updateListing(listingId, { status: next });
          refreshData();
          if (selectedListing && selectedListing.id === listingId) {
            setSelectedListing({ ...selectedListing, status: next });
          }
        }}
        onFilterBySeller={(sellerId) => {
          const seller = StorageService.getUsers().find((u) => u.id === sellerId);
          if (seller?.role === 'realtor') {
            setActiveView('realtor-portal');
          } else {
            setSearchQuery(seller?.name || '');
          }
        }}
      />

      {/* 2. 9-Step Post Listing Wizard */}
      <PostListingWizard
        isOpen={isPostListingOpen}
        onClose={() => setIsPostListingOpen(false)}
        currentUser={currentUser}
        onSuccess={(newListing) => {
          refreshData();
          handleOpenDetail(newListing);
        }}
      />

      {/* 3. Bargaining / Offer Modal */}
      <OfferModal
        listing={offerTargetListing}
        isOpen={isOfferModalOpen}
        onClose={() => {
          setIsOfferModalOpen(false);
          setOfferTargetListing(null);
        }}
        currentUser={currentUser}
        onSuccess={refreshData}
      />

      {/* 4. Report / Complaint Modal */}
      <ReportModal
        listing={reportTargetListing}
        isOpen={isReportModalOpen}
        onClose={() => {
          setIsReportModalOpen(false);
          setReportTargetListing(null);
        }}
      />

      {/* 5. Payment & Doping Modal */}
      <PaymentModal
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        currentUser={currentUser}
        packageName={paymentConfig.packageName}
        amount={paymentConfig.amount}
        onSuccess={refreshData}
      />

      {/* 6. Turgutlu Interactive Map Modal */}
      <TurgutluMapModal
        isOpen={isMapModalOpen}
        onClose={() => setIsMapModalOpen(false)}
        listings={listings.filter((l) => l.status === 'active')}
        onSelectListing={handleOpenDetail}
      />

      {/* 7. Admin Panel */}
      {isAdminOpen && (
        <AdminPanel
          onClose={() => setIsAdminOpen(false)}
          onNavigateToListing={handleOpenDetail}
          onRefreshData={refreshData}
        />
      )}

      {/* 8. Auth Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        currentUser={currentUser}
        onUserChange={(newUser) => {
          setCurrentUser(newUser);
          refreshData();
        }}
      />

      {/* 9. AI Assistant Modal */}
      <AiAssistantModal
        isOpen={isAiAssistantOpen}
        onClose={() => {
          setIsAiAssistantOpen(false);
          setAiAssistantListingContext(null);
        }}
        listingContext={aiAssistantListingContext}
      />

      {/* Floating AI Helper quick action button */}
      <button
        onClick={() => {
          setAiAssistantListingContext(null);
          setIsAiAssistantOpen(true);
        }}
        className="fixed bottom-20 sm:bottom-6 right-4 sm:right-6 z-30 flex items-center gap-2 bg-gradient-to-r from-indigo-600 via-indigo-700 to-emerald-600 hover:from-indigo-700 hover:to-emerald-700 text-white px-4 py-3 rounded-full shadow-xl shadow-indigo-900/30 font-bold text-xs sm:text-sm transition-all hover:scale-105 active:scale-95 group cursor-pointer border border-white/20"
        title="Turgutlu Yapay Zeka Danışmanı"
      >
        <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
        <span className="font-extrabold tracking-tight">AI Danışman</span>
      </button>
    </div>
  );
}
