import React, { useState } from 'react';
import { StorageService } from '../services/storage';
import { Listing, User, Complaint, PaymentRecord } from '../types';
import {
  ShieldAlert,
  Users,
  Package,
  AlertTriangle,
  CreditCard,
  BellRing,
  Trash2,
  CheckCircle,
  XCircle,
  Eye,
  Plus,
  RefreshCw,
  Sparkles
} from 'lucide-react';

interface AdminPanelProps {
  onClose: () => void;
  onNavigateToListing: (listing: Listing) => void;
  onRefreshData?: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  onClose,
  onNavigateToListing,
  onRefreshData
}) => {
  const [activeTab, setActiveTab] = useState<'listings' | 'users' | 'complaints' | 'categories' | 'payments' | 'announcement'>('listings');
  const [version, setVersion] = useState(0);
  const reload = () => setVersion((v) => v + 1);

  const [announcementText, setAnnouncementText] = useState(StorageService.getAnnouncement());
  const [newCatName, setNewCatName] = useState('');
  const [newSubcats, setNewSubcats] = useState('');

  const listings = StorageService.getListings();
  const users = StorageService.getUsers();
  const complaints = StorageService.getComplaints();
  const payments = StorageService.getPayments();
  const categories = StorageService.getCategories();

  // Metrics
  const totalListings = listings.length;
  const activeListings = listings.filter((l) => l.status === 'active').length;
  const pendingListings = listings.filter((l) => l.status === 'pending').length;
  const totalUsers = users.length;
  const totalRevenue = payments.reduce((acc, curr) => acc + curr.amount, 0);

  const handleToggleListingStatus = (id: string, current: string) => {
    StorageService.updateListing(id, {
      status: current === 'active' ? 'passive' : 'active'
    });
    onRefreshData?.();
    reload();
  };

  const handleDeleteListing = (id: string) => {
    if (window.confirm('Bu ilanı sistemden ve veritabanından kalıcı olarak silmek istediğinize emin misiniz?')) {
      StorageService.deleteListing(id);
      onRefreshData?.();
      reload();
    }
  };

  const handleToggleUserRole = (user: User) => {
    const nextRole = user.role === 'realtor' ? 'user' : 'realtor';
    StorageService.updateUser({
      id: user.id,
      role: nextRole,
      companyName: nextRole === 'realtor' ? `${user.name} Emlak Ofisi` : undefined
    });
    reload();
  };

  const handleResolveComplaint = (id: string, action: 'dismiss' | 'remove_listing' | 'make_passive') => {
    if (action === 'remove_listing') {
      if (window.confirm('Şikayet edilen bu ilanı yayından kalıcı olarak kaldırmak ve silmek istediğinize emin misiniz?')) {
        StorageService.resolveComplaint(id, 'remove_listing');
        onRefreshData?.();
        reload();
      }
    } else if (action === 'make_passive') {
      const complaint = complaints.find(c => c.id === id);
      if (complaint) {
        StorageService.updateListing(complaint.listingId, { status: 'passive' });
        StorageService.resolveComplaint(id, 'dismiss');
        onRefreshData?.();
        reload();
      }
    } else {
      StorageService.resolveComplaint(id, 'dismiss');
      onRefreshData?.();
      reload();
    }
  };

  const handleSaveAnnouncement = () => {
    StorageService.setAnnouncement(announcementText);
    alert('Sistem duyurusu güncellendi!');
  };

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    const subs = newSubcats
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    StorageService.addCategory(newCatName, subs.length > 0 ? subs : ['Genel']);
    setNewCatName('');
    setNewSubcats('');
    reload();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
      <div className="relative w-full max-w-5xl bg-white rounded-2xl shadow-2xl overflow-hidden my-auto flex flex-col max-h-[92vh]">
        {/* Admin Header */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold">TurgutluPazar Yönetim Konsolu (Admin)</h2>
              <p className="text-xs text-slate-400">
                Manisa Turgutlu Bölge Denetim, Güvenlik ve İlan Onay Merkezi
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300"
          >
            Konsolu Kapat
          </button>
        </div>

        {/* Admin KPI Ribbon */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 p-4 bg-slate-50 border-b border-slate-200 text-xs shrink-0">
          <div className="p-2.5 bg-white rounded-lg border border-slate-200">
            <span className="text-slate-400 block text-[10px]">Toplam Kullanıcı</span>
            <span className="font-extrabold text-slate-900 text-base tabular-nums">{totalUsers}</span>
          </div>
          <div className="p-2.5 bg-white rounded-lg border border-slate-200">
            <span className="text-slate-400 block text-[10px]">Toplam İlan</span>
            <span className="font-extrabold text-slate-900 text-base tabular-nums">{totalListings}</span>
          </div>
          <div className="p-2.5 bg-white rounded-lg border border-slate-200">
            <span className="text-slate-400 block text-[10px]">Aktif Yayında</span>
            <span className="font-extrabold text-emerald-700 text-base tabular-nums">{activeListings}</span>
          </div>
          <div className="p-2.5 bg-white rounded-lg border border-slate-200">
            <span className="text-slate-400 block text-[10px]">Şikayetler</span>
            <span className="font-extrabold text-rose-600 text-base tabular-nums">{complaints.length}</span>
          </div>
          <div className="p-2.5 bg-white rounded-lg border border-slate-200">
            <span className="text-slate-400 block text-[10px]">Toplam Hacim</span>
            <span className="font-extrabold text-indigo-700 text-base tabular-nums">{totalRevenue} TL</span>
          </div>
        </div>

        {/* Admin Tab Switcher */}
        <div className="flex items-center gap-1 px-6 border-b border-slate-200 bg-white overflow-x-auto shrink-0">
          {[
            { id: 'listings', label: 'İlanlar', icon: Package },
            { id: 'users', label: 'Kullanıcılar', icon: Users },
            { id: 'complaints', label: 'Şikayet İhbarları', icon: AlertTriangle, badge: complaints.length },
            { id: 'categories', label: 'Kategoriler', icon: Plus },
            { id: 'payments', label: 'Ödemeler', icon: CreditCard },
            { id: 'announcement', label: 'Duyuru Yayını', icon: BellRing }
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3 px-3.5 text-xs font-semibold flex items-center gap-2 border-b-2 transition-colors whitespace-nowrap ${
                  active
                    ? 'border-emerald-600 text-emerald-700'
                    : 'border-transparent text-slate-600 hover:text-slate-900'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
                {tab.badge ? (
                  <span className="bg-rose-500 text-white text-[10px] px-1.5 py-0.2 rounded-full">
                    {tab.badge}
                  </span>
                ) : null}
              </button>
            );
          })}
        </div>

        {/* Content Area */}
        <div className="p-6 overflow-y-auto flex-1">
          {/* TAB: LISTINGS */}
          {activeTab === 'listings' && (
            <div className="space-y-3">
              <div className="text-xs font-semibold text-slate-500 mb-2">
                Turgutlu Genelindeki Tüm İlanlar ({listings.length})
              </div>
              <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden bg-white text-xs">
                {listings.map((l) => (
                  <div key={l.id} className="p-3.5 flex items-center justify-between gap-3 hover:bg-slate-50">
                    <div
                      onClick={() => onNavigateToListing(l)}
                      className="flex items-center gap-3 cursor-pointer flex-1 min-w-0"
                    >
                      <img src={l.images[0]} alt="" className="w-12 h-10 object-cover rounded shrink-0" />
                      <div className="min-w-0">
                        <span className="font-bold text-slate-900 truncate block">{l.title}</span>
                        <span className="text-[11px] text-slate-500">
                          {l.neighborhood} Mah. · {l.sellerName} · {l.price.toLocaleString('tr-TR')} TL
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => handleToggleListingStatus(l.id, l.status)}
                        className={`px-2.5 py-1 rounded text-[11px] font-bold ${
                          l.status === 'active'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-slate-100 text-slate-600'
                        }`}
                      >
                        {l.status === 'active' ? 'Yayında' : 'Pasif'}
                      </button>
                      <button
                        onClick={() => handleDeleteListing(l.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded transition-colors"
                        title="İlanı Sil"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: USERS */}
          {activeTab === 'users' && (
            <div className="space-y-3">
              <div className="text-xs font-semibold text-slate-500 mb-2">Kayıtlı Kullanıcılar</div>
              <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden bg-white text-xs">
                {users.map((u) => (
                  <div key={u.id} className="p-3.5 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <img src={u.avatarUrl} alt="" className="w-10 h-10 rounded-full object-cover" />
                      <div>
                        <div className="font-bold text-slate-900 flex items-center gap-1.5">
                          {u.name}
                          <span
                            className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                              u.role === 'admin'
                                ? 'bg-purple-100 text-purple-800'
                                : u.role === 'realtor'
                                ? 'bg-indigo-100 text-indigo-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {u.role.toUpperCase()}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {u.phone} · {u.email}
                        </div>
                      </div>
                    </div>

                    {u.role !== 'admin' && (
                      <button
                        onClick={() => handleToggleUserRole(u)}
                        className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-semibold hover:bg-slate-50"
                      >
                        {u.role === 'realtor' ? 'Bireysele Çevir' : 'Kurumsal Emlakçı Yetkisi Ver'}
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: COMPLAINTS */}
          {activeTab === 'complaints' && (
            <div className="space-y-3">
              <div className="text-xs font-semibold text-slate-500 mb-2">Şikayet ve Bildirimler</div>
              {complaints.length === 0 ? (
                <div className="p-8 text-center text-slate-500 text-xs">
                  Bekleyen herhangi bir şikayet ihbarı bulunmuyor.
                </div>
              ) : (
                <div className="space-y-3">
                  {complaints.map((c) => (
                    <div key={c.id} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
                      <div className="flex items-center justify-between font-bold text-slate-900">
                        <span>İlan: {c.listingTitle}</span>
                        <span className="text-rose-600 bg-rose-50 px-2 py-0.5 rounded">{c.reason}</span>
                      </div>
                      <p className="text-slate-600">"{c.details}"</p>
                      <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                        <span className="text-slate-400">Bildiren: {c.reporterName}</span>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              const found = listings.find((l) => l.id === c.listingId);
                              if (found) onNavigateToListing(found);
                            }}
                            className="px-2.5 py-1 bg-white border border-slate-300 hover:bg-slate-50 rounded text-slate-700 font-semibold cursor-pointer"
                          >
                            İlanı İncele
                          </button>
                          <button
                            type="button"
                            onClick={() => handleResolveComplaint(c.id, 'dismiss')}
                            className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded font-semibold cursor-pointer"
                          >
                            Gözardı Et
                          </button>
                          <button
                            type="button"
                            onClick={() => handleResolveComplaint(c.id, 'make_passive')}
                            className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 rounded font-semibold cursor-pointer"
                          >
                            Pasife Al
                          </button>
                          <button
                            type="button"
                            onClick={() => handleResolveComplaint(c.id, 'remove_listing')}
                            className="px-3 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded font-bold cursor-pointer transition-colors shadow-2xs"
                          >
                            Yayından Kaldır & Sil
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB: CATEGORIES */}
          {activeTab === 'categories' && (
            <div className="space-y-6">
              <form onSubmit={handleAddCategory} className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <h4 className="font-bold text-slate-900 text-xs">Yeni Kategori Ekle</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Kategori Adı</label>
                    <input
                      type="text"
                      placeholder="Örn: Sanayi & Yedek Parça"
                      value={newCatName}
                      onChange={(e) => setNewCatName(e.target.value)}
                      className="w-full p-2 border border-slate-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Alt Kategoriler (virgülle ayırın)</label>
                    <input
                      type="text"
                      placeholder="Örn: Cıvata, Rulman, Hidrolik"
                      value={newSubcats}
                      onChange={(e) => setNewSubcats(e.target.value)}
                      className="w-full p-2 border border-slate-300 rounded-lg"
                    />
                  </div>
                </div>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 text-white font-bold rounded-lg text-xs"
                >
                  Kategoriyi Sisteme Ekle
                </button>
              </form>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {categories.map((c) => (
                  <div key={c.id} className="p-3 bg-white border border-slate-200 rounded-xl text-xs">
                    <span className="font-bold text-slate-900 block">{c.name}</span>
                    <span className="text-slate-400 text-[11px]">{c.subcategories.length} alt başlık</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: PAYMENTS */}
          {activeTab === 'payments' && (
            <div className="space-y-3">
              <div className="text-xs font-semibold text-slate-500 mb-2">TurgutluPazar Finans & Sipariş Kayıtları</div>
              <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden bg-white text-xs">
                {payments.map((p) => (
                  <div key={p.id} className="p-3.5 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-slate-900 block">{p.userName}</span>
                      <span className="text-slate-500 text-[11px]">{p.packageName}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-slate-900 tabular-nums block">{p.amount} TL</span>
                      <span className="text-emerald-700 text-[10px] font-semibold">Ödendi · {p.date}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: ANNOUNCEMENT */}
          {activeTab === 'announcement' && (
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3 text-xs">
              <h4 className="font-bold text-slate-900">Ana Sayfa Üst Bant Duyurusu</h4>
              <textarea
                rows={3}
                value={announcementText}
                onChange={(e) => setAnnouncementText(e.target.value)}
                className="w-full p-2.5 border border-slate-300 rounded-lg text-xs"
              />
              <button
                onClick={handleSaveAnnouncement}
                className="px-4 py-2 bg-emerald-600 text-white font-bold rounded-lg"
              >
                Duyuruyu Yayınla
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
