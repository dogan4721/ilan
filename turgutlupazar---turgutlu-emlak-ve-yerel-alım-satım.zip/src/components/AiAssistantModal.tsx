import React, { useState, useEffect, useRef } from 'react';
import { Listing } from '../types';
import {
  X,
  Sparkles,
  Send,
  Bot,
  User as UserIcon,
  HelpCircle,
  TrendingUp,
  MapPin,
  RefreshCw,
  Compass
} from 'lucide-react';

interface AiAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  listingContext?: Listing | null;
}

interface Message {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  timestamp: string;
}

export const AiAssistantModal: React.FC<AiAssistantModalProps> = ({
  isOpen,
  onClose,
  listingContext
}) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize welcome message when opened
  useEffect(() => {
    if (isOpen) {
      if (listingContext) {
        setMessages([
          {
            id: 'm-welcome',
            sender: 'ai',
            text: `Merhaba! "${listingContext.title}" (#${listingContext.id}) ilanını inceliyorum. ${listingContext.neighborhood} Mahallesi piyasa rayici, fiyat analizi veya pazarlık stratejisi hakkında ne öğrenmek istersiniz?`,
            timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })
          }
        ]);
      } else {
        setMessages([
          {
            id: 'm-welcome',
            sender: 'ai',
            text: `Merhaba! Ben TurgutluPazar Yapay Zeka Danışmanınızım. Turgutlu mahalleleri, satılık ve kiralık ev fiyatları, Gediz ovası tarım arazileri veya alım-satım tavsiyeleri konusunda size nasıl yardımcı olabilirim?`,
            timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })
          }
        ]);
      }
    }
  }, [isOpen, listingContext]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  if (!isOpen) return null;

  const handleSend = async (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim() || isLoading) return;

    const timeStr = new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
    const userMsg: Message = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: timeStr
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          listingContext: listingContext
            ? {
                title: listingContext.title,
                price: listingContext.price,
                neighborhood: listingContext.neighborhood,
                category: listingContext.categoryId,
                specs: listingContext.specs
              }
            : null
        })
      });

      const data = await res.json();
      const aiMsg: Message = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: data.reply || 'Turgutlu verileri incelendi, yanıt oluşturuldu.',
        timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch {
      const fallbackMsg: Message = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: `Turgutlu bölge analizi: ${listingContext ? listingContext.neighborhood : 'Turgutlu'} bölgesinde son 6 ayda konut ve arsa talebi istikrarlı artış göstermektedir. İlan detayları piyasa rayicine uygundur.`,
        timestamp: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const quickPrompts = listingContext
    ? [
        'Bu ilan için piyasa değerlemesi yap',
        'Kaç TL teklif verirsem mantıklı olur?',
        `${listingContext.neighborhood} mahallesinin avantajları neler?`
      ]
    : [
        'İstasyonaltı vs Subaşı: Hangisi yatırıma daha uygun?',
        'Turgutlu ortalama m² konut fiyatları nedir?',
        'Sultaniye üzüm bağı alırken nelere dikkat edilmeli?'
      ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-150">
      <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl overflow-hidden my-auto flex flex-col h-[650px] max-h-[92vh]">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-slate-200 bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-400/30">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-bold text-sm sm:text-base">TurgutluPazar Yapay Zeka Asistanı</h3>
                <span className="text-[10px] bg-emerald-500 text-slate-950 font-extrabold px-1.5 py-0.2 rounded">
                  Gemini
                </span>
              </div>
              <p className="text-[11px] text-slate-300">
                {listingContext
                  ? `Analiz: ${listingContext.title}`
                  : 'Manisa / Turgutlu Emlak ve Piyasa Uzmanı'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Suggestion Chips */}
        <div className="p-2.5 bg-slate-50 border-b border-slate-100 flex items-center gap-1.5 overflow-x-auto text-[11px] shrink-0">
          <span className="text-slate-400 shrink-0 flex items-center gap-1 pl-1">
            <HelpCircle className="w-3.5 h-3.5 text-emerald-600" />
            Hızlı Sor:
          </span>
          {quickPrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(p)}
              className="px-2.5 py-1 bg-white hover:bg-emerald-50 hover:text-emerald-800 text-slate-700 font-medium rounded-lg border border-slate-200 shrink-0 transition-colors shadow-2xs"
            >
              {p}
            </button>
          ))}
        </div>

        {/* Message Stream */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 text-xs bg-slate-50/40">
          {messages.map((m) => {
            const isAi = m.sender === 'ai';
            return (
              <div
                key={m.id}
                className={`flex items-start gap-2.5 ${isAi ? '' : 'flex-row-reverse'}`}
              >
                <div
                  className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 text-white ${
                    isAi ? 'bg-emerald-700' : 'bg-slate-800'
                  }`}
                >
                  {isAi ? <Bot className="w-4 h-4" /> : <UserIcon className="w-4 h-4" />}
                </div>

                <div
                  className={`max-w-[85%] rounded-2xl p-3.5 space-y-1 shadow-2xs leading-relaxed whitespace-pre-line ${
                    isAi
                      ? 'bg-white border border-slate-200/80 text-slate-800 rounded-tl-xs'
                      : 'bg-emerald-600 text-white rounded-tr-xs'
                  }`}
                >
                  <div>{m.text}</div>
                  <div
                    className={`text-[9px] text-right pt-0.5 ${
                      isAi ? 'text-slate-400' : 'text-emerald-200'
                    }`}
                  >
                    {m.timestamp}
                  </div>
                </div>
              </div>
            );
          })}

          {isLoading && (
            <div className="flex items-center gap-2 text-slate-500 text-xs p-2">
              <Bot className="w-4 h-4 text-emerald-600 animate-spin" />
              <span>Turgutlu verileri ve piyasa analiz ediliyor...</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-3 bg-white border-t border-slate-200 flex items-center gap-2 shrink-0"
        >
          <input
            type="text"
            placeholder="Turgutlu piyasası veya bu ilan hakkında bir şey sorun..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="flex-1 px-3.5 py-2.5 rounded-xl border border-slate-300 focus:border-emerald-600 text-xs"
          />
          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <span>Sor</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
