import React, { useState } from 'react';
import { X, Flame, Shield, Database, Lock, Key, Check, Copy } from 'lucide-react';
import firebaseConfig from '../../firebase-applet-config.json';

interface FirebaseGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  isLive: boolean;
}

export const FirebaseGuideModal: React.FC<FirebaseGuideModalProps> = ({
  isOpen,
  onClose,
  isLive
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const copyConfig = () => {
    navigator.clipboard.writeText(JSON.stringify(firebaseConfig, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-600">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                Firebase Altyapı ve Kurulum Kılavuzu
              </h3>
              <p className="text-[11px] text-slate-500">
                TurgutluPazar Firebase Authentication, Cloud Firestore & Storage
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-slate-700">
          {/* Status Box */}
          <div
            className={`p-4 rounded-xl border flex items-center justify-between ${
              isLive
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-amber-50 border-amber-200 text-amber-900'
            }`}
          >
            <div className="flex items-center gap-3">
              <span
                className={`w-3 h-3 rounded-full ${
                  isLive ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'
                }`}
              />
              <div>
                <span className="font-bold block">
                  {isLive ? 'Firebase Bağlantısı Aktif (Canlı Mod)' : 'Demo Modunda Çalışıyorsunuz'}
                </span>
                <span className="text-[11px] opacity-80">
                  {isLive
                    ? `Proje ID: ${firebaseConfig.projectId} · Veritabanı: ${firebaseConfig.firestoreDatabaseId}`
                    : 'Firebase yapılandırması bulunamadığında LocalStorage ile kesintisiz çalışır.'}
                </span>
              </div>
            </div>
          </div>

          {/* Section 1: Services */}
          <div>
            <h4 className="font-bold text-slate-900 text-sm mb-2 flex items-center gap-1.5">
              <Database className="w-4 h-4 text-emerald-600" /> 1. Aktif Firebase Servisleri
            </h4>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
              <li className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
                <strong>Firebase Authentication:</strong> E-posta/Şifre ve Google Girişi ile güvenli kullanıcı yönetimi.
              </li>
              <li className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
                <strong>Cloud Firestore:</strong> İlanlar, teklifler, mesajlar ve favoriler için gerçek zamanlı NoSQL veritabanı.
              </li>
              <li className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
                <strong>Firebase Storage:</strong> İlan fotoğrafları için güvenli ve WebP optimize dosya depolama.
              </li>
              <li className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg">
                <strong>Security Rules:</strong> Attribute-Based Access Control (ABAC) ve Zero-Trust güvenlik kuralları.
              </li>
            </ul>
          </div>

          {/* Section 2: Config file */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <h4 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                <Key className="w-4 h-4 text-indigo-600" /> 2. firebase-applet-config.json Yapılandırması
              </h4>
              <button
                onClick={copyConfig}
                className="text-emerald-700 hover:underline flex items-center gap-1 text-[11px] font-semibold"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Kopyalandı' : 'JSON Kopyala'}</span>
              </button>
            </div>
            <pre className="p-3 bg-slate-900 text-emerald-400 font-mono text-[11px] rounded-xl overflow-x-auto max-h-36">
              {JSON.stringify(firebaseConfig, null, 2)}
            </pre>
          </div>

          {/* Section 3: Security Rules */}
          <div>
            <h4 className="font-bold text-slate-900 text-sm mb-1.5 flex items-center gap-1.5">
              <Shield className="w-4 h-4 text-emerald-600" /> 3. Firestore Güvenlik Kuralları (firestore.rules)
            </h4>
            <p className="text-slate-600 text-[11px] mb-2">
              Kullanıcılar yalnızca kendi ilanlarını düzenleyip silebilir. Admin tüm ilan ve kullanıcıları yönetebilir. Favori ve bildirimler kişiye özel alt koleksiyonlarda saklanır.
            </p>
            <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-900 text-[11px] font-medium">
              ✓ Kurallar `deploy_firebase` aracıyla Firebase projenize başarıyla canlı olarak dağıtılmıştır.
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-100 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs"
          >
            Kapat
          </button>
        </div>
      </div>
    </div>
  );
};
