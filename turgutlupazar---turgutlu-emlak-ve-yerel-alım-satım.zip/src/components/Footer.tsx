import React from 'react';
import { TURGUTLU_NEIGHBORHOODS } from '../data/turgutluData';
import { StorageService } from '../services/storage';
import { ShieldCheck, RotateCcw } from 'lucide-react';

interface FooterProps {
  onSelectNeighborhoodFilter: (nh: string) => void;
  onSelectCategoryFilter: (cat: string) => void;
}

export const Footer: React.FC<FooterProps> = ({
  onSelectNeighborhoodFilter,
  onSelectCategoryFilter
}) => {
  return (
    <footer className="bg-slate-900 text-slate-400 text-xs border-t border-slate-800 pt-12 pb-24 lg:pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        {/* Top 4 Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Info */}
          <div className="space-y-3">
            <a href="/" className="text-lg font-bold text-white tracking-tight flex items-center gap-1.5">
              <span>Turgutlu</span>
              <span className="text-emerald-500">Pazar</span>
            </a>
            <p className="text-slate-400 text-xs leading-relaxed">
              Manisa / Turgutlu bölgesine özel, güvenli ve modern yerel alım-satım ve emlak platformu. Gediz Ovası tarımından, merkez konutlarına kadar tüm ilanlar.
            </p>
            <div className="flex items-center gap-2 text-emerald-400 font-semibold pt-1">
              <ShieldCheck className="w-4 h-4" />
              <span>Doğrulanmış Yerel Ticaret</span>
            </div>
          </div>

          {/* Popular Categories */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm">Popüler Kategoriler</h4>
            <ul className="space-y-1.5">
              <li>
                <button
                  onClick={() => onSelectCategoryFilter('emlak')}
                  className="hover:text-white transition-colors"
                >
                  Turgutlu Satılık Daire
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategoryFilter('emlak')}
                  className="hover:text-white transition-colors"
                >
                  Turgutlu Kiralık Ev
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategoryFilter('emlak')}
                  className="hover:text-white transition-colors"
                >
                  Turgutlu Satılık Bağ & Tarla
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategoryFilter('tarim')}
                  className="hover:text-white transition-colors"
                >
                  Satılık Traktör & Tarım Makineleri
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategoryFilter('arac')}
                  className="hover:text-white transition-colors"
                >
                  Turgutlu İkinci El Otomobil
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectCategoryFilter('is-hizmet')}
                  className="hover:text-white transition-colors"
                >
                  Usta & Nakliye Hizmetleri
                </button>
              </li>
            </ul>
          </div>

          {/* Neighborhoods (Turgutlu Focus) */}
          <div className="space-y-3 lg:col-span-2">
            <h4 className="text-white font-bold text-sm">Turgutlu Mahalleleri</h4>
            <div className="flex flex-wrap gap-1.5">
              {TURGUTLU_NEIGHBORHOODS.map((nh) => (
                <button
                  key={nh}
                  onClick={() => onSelectNeighborhoodFilter(nh)}
                  className="px-2 py-1 bg-slate-800 hover:bg-emerald-900/60 hover:text-emerald-300 text-slate-300 rounded text-[11px] transition-colors"
                >
                  {nh} Mah.
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Bar & Reset Data Action */}
        <div className="pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <p>© {new Date().getFullYear()} TurgutluPazar.com · Manisa / Turgutlu Tüm Hakları Saklıdır.</p>

          <div className="flex items-center gap-4">
            <span>Sürüm 1.0 (Demo Prototip)</span>
            <button
              onClick={() => StorageService.resetToDefault()}
              className="text-slate-400 hover:text-rose-400 flex items-center gap-1 transition-colors"
              title="Demo verileri sıfırla"
            >
              <RotateCcw className="w-3 h-3" /> Verileri Sıfırla
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
