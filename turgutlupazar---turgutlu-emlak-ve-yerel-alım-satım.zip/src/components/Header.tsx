import React, { useState } from 'react';
import { User, Notification } from '../types';
import { StorageService } from '../services/storage';
import {
  Plus,
  Bell,
  User as UserIcon,
  Building2,
  Shield,
  MapPin,
  Menu,
  X,
  Compass,
  Sparkles
} from 'lucide-react';
import { NotificationDropdown } from './NotificationDropdown';

interface HeaderProps {
  currentUser: User;
  onOpenPostListing: () => void;
  onOpenDashboard: (tab?: string) => void;
  onOpenAdmin: () => void;
  onOpenRealtorPortal: () => void;
  onOpenMap: () => void;
  onOpenAuth: () => void;
  onSelectCategoryFilter: (catId: string) => void;
  onOpenAiAssistant?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onOpenPostListing,
  onOpenDashboard,
  onOpenAdmin,
  onOpenRealtorPortal,
  onOpenMap,
  onOpenAuth,
  onSelectCategoryFilter,
  onOpenAiAssistant
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const notifications = StorageService.getNotifications();
  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Zone 1: Single Text Element Wordmark */}
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              onSelectCategoryFilter('all');
            }}
            className="text-xl font-extrabold tracking-tight text-slate-900 flex items-center gap-1.5 shrink-0 hover:opacity-90"
          >
            <span>Turgutlu</span>
            <span className="text-emerald-600">Pazar</span>
          </a>

          {/* Zone 2: 4-6 Clean Text Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 text-sm font-semibold text-slate-600">
            <button
              onClick={() => onSelectCategoryFilter('all')}
              className="hover:text-slate-900 transition-colors"
            >
              Tüm İlanlar
            </button>
            <button
              onClick={() => onSelectCategoryFilter('emlak')}
              className="hover:text-slate-900 transition-colors"
            >
              Emlak
            </button>
            <button
              onClick={() => onSelectCategoryFilter('arac')}
              className="hover:text-slate-900 transition-colors"
            >
              Araç
            </button>
            <button
              onClick={() => onSelectCategoryFilter('tarim')}
              className="hover:text-slate-900 transition-colors"
            >
              Tarım
            </button>
            <button
              onClick={onOpenRealtorPortal}
              className="hover:text-slate-900 transition-colors"
            >
              Emlakçı Rehberi
            </button>
            <button
              onClick={onOpenMap}
              className="hover:text-emerald-700 flex items-center gap-1 text-emerald-600 transition-colors"
            >
              <Compass className="w-4 h-4" />
              <span>Harita</span>
            </button>
            {onOpenAiAssistant && (
              <button
                onClick={onOpenAiAssistant}
                className="hover:bg-indigo-100 flex items-center gap-1 text-indigo-700 bg-indigo-50 border border-indigo-200/80 px-2.5 py-1 rounded-lg text-xs font-bold transition-all shadow-2xs"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                <span>AI Danışman</span>
              </button>
            )}
          </nav>

          {/* Zone 3: 1-2 Primary Actions + Notifications & User Avatar */}
          <div className="flex items-center gap-2.5">
            {/* Post Listing Action Button */}
            <button
              onClick={onOpenPostListing}
              className="px-4 py-2 text-xs sm:text-sm font-bold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 transition-all shadow-xs flex items-center gap-1.5 whitespace-nowrap active:scale-98"
            >
              <Plus className="w-4 h-4" />
              <span>İlan Ver</span>
            </button>

            {/* Notifications Popover */}
            <div className="relative">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors relative"
                aria-label="Bildirimler"
              >
                <Bell className="w-5 h-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white" />
                )}
              </button>

              <NotificationDropdown
                isOpen={showNotifications}
                onClose={() => setShowNotifications(false)}
                onOpenDashboardTab={(tab) => onOpenDashboard(tab)}
              />
            </div>

            {/* User Profile Button & Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center gap-2 p-1.5 rounded-xl hover:bg-slate-100 transition-colors"
              >
                <img
                  src={currentUser.avatarUrl}
                  alt={currentUser.name}
                  className="w-8 h-8 rounded-full object-cover border border-slate-200"
                />
                <span className="hidden md:inline text-xs font-bold text-slate-800 max-w-[100px] truncate">
                  {currentUser.name}
                </span>
              </button>

              {showUserMenu && (
                <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-200 py-1.5 z-50 text-xs animate-in fade-in duration-100">
                  <div className="px-4 py-2 border-b border-slate-100">
                    <p className="font-bold text-slate-900 truncate">{currentUser.name}</p>
                    <p className="text-slate-400 text-[11px] truncate">{currentUser.email}</p>
                  </div>

                  <button
                    onClick={() => {
                      onOpenDashboard('ilanlarim');
                      setShowUserMenu(false);
                    }}
                    className="w-full px-4 py-2 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2 font-medium"
                  >
                    <span>Kullanıcı Paneli</span>
                  </button>

                  <button
                    onClick={() => {
                      onOpenDashboard('mesajlarim');
                      setShowUserMenu(false);
                    }}
                    className="w-full px-4 py-2 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2 font-medium"
                  >
                    <span>Mesajlarım</span>
                  </button>

                  <button
                    onClick={() => {
                      onOpenDashboard('tekliflerim');
                      setShowUserMenu(false);
                    }}
                    className="w-full px-4 py-2 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2 font-medium"
                  >
                    <span>Tekliflerim</span>
                  </button>

                  <button
                    onClick={() => {
                      onOpenDashboard('favorilerim');
                      setShowUserMenu(false);
                    }}
                    className="w-full px-4 py-2 text-left text-slate-700 hover:bg-slate-50 flex items-center gap-2 font-medium"
                  >
                    <span>Favorilerim</span>
                  </button>

                  {currentUser.role === 'realtor' && (
                    <button
                      onClick={() => {
                        onOpenRealtorPortal();
                        setShowUserMenu(false);
                      }}
                      className="w-full px-4 py-2 text-left text-indigo-700 hover:bg-indigo-50 flex items-center gap-2 font-semibold"
                    >
                      <Building2 className="w-3.5 h-3.5" />
                      <span>Emlakçı Sayfam</span>
                    </button>
                  )}

                  <button
                    onClick={() => {
                      onOpenAdmin();
                      setShowUserMenu(false);
                    }}
                    className="w-full px-4 py-2 text-left text-purple-700 hover:bg-purple-50 flex items-center gap-2 font-semibold"
                  >
                    <Shield className="w-3.5 h-3.5" />
                    <span>Yönetim Konsolu (Admin)</span>
                  </button>

                  <div className="border-t border-slate-100 my-1" />

                  <button
                    onClick={() => {
                      onOpenAuth();
                      setShowUserMenu(false);
                    }}
                    className="w-full px-4 py-2 text-left text-emerald-700 hover:bg-emerald-50 flex items-center gap-2 font-bold cursor-pointer"
                  >
                    <span>Giriş Yap / Kayıt Ol</span>
                  </button>
                </div>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg"
              aria-label="Menü"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 py-4 space-y-3">
          <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
            <button
              onClick={() => {
                onSelectCategoryFilter('all');
                setMobileMenuOpen(false);
              }}
              className="p-2.5 bg-slate-50 rounded-lg text-left"
            >
              Tüm İlanlar
            </button>
            <button
              onClick={() => {
                onSelectCategoryFilter('emlak');
                setMobileMenuOpen(false);
              }}
              className="p-2.5 bg-slate-50 rounded-lg text-left"
            >
              Emlak İlanları
            </button>
            <button
              onClick={() => {
                onSelectCategoryFilter('arac');
                setMobileMenuOpen(false);
              }}
              className="p-2.5 bg-slate-50 rounded-lg text-left"
            >
              Araç & Vasıta
            </button>
            <button
              onClick={() => {
                onSelectCategoryFilter('tarim');
                setMobileMenuOpen(false);
              }}
              className="p-2.5 bg-slate-50 rounded-lg text-left"
            >
              Tarım & Traktör
            </button>
            <button
              onClick={() => {
                onOpenRealtorPortal();
                setMobileMenuOpen(false);
              }}
              className="p-2.5 bg-slate-50 rounded-lg text-left"
            >
              Emlakçı Rehberi
            </button>
            <button
              onClick={() => {
                onOpenMap();
                setMobileMenuOpen(false);
              }}
              className="p-2.5 bg-emerald-50 text-emerald-800 rounded-lg text-left font-bold"
            >
              Turgutlu Haritası
            </button>
            {onOpenAiAssistant && (
              <button
                onClick={() => {
                  onOpenAiAssistant();
                  setMobileMenuOpen(false);
                }}
                className="p-2.5 bg-indigo-50 text-indigo-800 rounded-lg text-left font-bold flex items-center gap-1.5 col-span-2"
              >
                <Sparkles className="w-4 h-4 text-indigo-600" />
                <span>Yapay Zeka Piyasa Danışmanı</span>
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
