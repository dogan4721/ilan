import React, { useState } from 'react';
import { Listing } from '../types';
import { Heart, MapPin, Eye, BadgeCheck, Sparkles, Building2, User as UserIcon } from 'lucide-react';

interface ListingCardProps {
  listing: Listing;
  isFavorite: boolean;
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
  onClick: (listing: Listing) => void;
}

export const ListingCard: React.FC<ListingCardProps> = ({
  listing,
  isFavorite,
  onToggleFavorite,
  onClick
}) => {
  const [imgError, setImgError] = useState(false);

  // Formatting price
  const formattedPrice = listing.price.toLocaleString('tr-TR');

  // Specs snippet depending on category
  const getSpecsSnippet = () => {
    if (listing.categoryId === 'emlak') {
      const parts = [];
      if (listing.specs.roomCount) parts.push(listing.specs.roomCount);
      if (listing.specs.m2Net || listing.specs.m2Gross) {
        parts.push(`${listing.specs.m2Net || listing.specs.m2Gross} m²`);
      }
      if (listing.specs.floor) parts.push(listing.specs.floor);
      return parts.join(' · ');
    }
    if (listing.categoryId === 'tarim' || listing.categoryId === 'arac') {
      const parts = [];
      if (listing.specs.brand) parts.push(listing.specs.brand);
      if (listing.specs.year) parts.push(listing.specs.year.toString());
      if (listing.specs.km) parts.push(`${listing.specs.km.toLocaleString('tr-TR')} km`);
      if (listing.specs.engineHours) parts.push(`${listing.specs.engineHours} saat`);
      return parts.join(' · ');
    }
    return listing.subcategory;
  };

  const timeAgo = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 3600 * 24));
    if (diffDays <= 0) return 'Bugün';
    if (diffDays === 1) return 'Dün';
    return `${diffDays} gün önce`;
  };

  return (
    <article
      onClick={() => onClick(listing)}
      className="group relative flex flex-col bg-white rounded-xl border border-slate-200/80 shadow-xs hover:shadow-md hover:border-slate-300 transition-all duration-200 cursor-pointer overflow-hidden"
    >
      {/* Image Container with 4:3 Aspect Ratio */}
      <div className="relative aspect-4/3 w-full bg-slate-100 overflow-hidden">
        {!imgError && listing.images?.[0] ? (
          <img
            src={listing.images[0]}
            alt={listing.title}
            loading="lazy"
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-300 ease-out"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-slate-100 to-slate-200 text-slate-400 p-4 text-center">
            <Building2 className="w-8 h-8 mb-1 text-slate-300" />
            <span className="text-xs font-medium text-slate-500">{listing.subcategory}</span>
          </div>
        )}

        {/* Featured / Doping indicator */}
        <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 z-10">
          {listing.isFeatured && (
            <span className="inline-flex items-center gap-1 bg-amber-500 text-white text-[11px] font-semibold px-2 py-0.5 rounded-sm shadow-xs">
              <Sparkles className="w-3 h-3" /> Vitrin
            </span>
          )}
          {listing.isDoping && (
            <span className="inline-flex items-center bg-rose-600 text-white text-[11px] font-semibold px-2 py-0.5 rounded-sm shadow-xs">
              Fırsat
            </span>
          )}
        </div>

        {/* Favorite Button */}
        <button
          type="button"
          onClick={(e) => onToggleFavorite(listing.id, e)}
          aria-label={isFavorite ? "Favorilerden kaldır" : "Favorilere ekle"}
          className={`absolute top-2.5 right-2.5 p-2 rounded-full transition-all duration-150 z-10 ${
            isFavorite
              ? 'bg-rose-50 text-rose-600 shadow-sm'
              : 'bg-white/80 hover:bg-white text-slate-600 hover:text-rose-600 shadow-xs backdrop-blur-xs'
          }`}
        >
          <Heart
            className={`w-4 h-4 transition-transform active:scale-125 ${
              isFavorite ? 'fill-rose-600 stroke-rose-600' : ''
            }`}
          />
        </button>

        {/* Bottom subtle gradient for image stats */}
        <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-slate-900/60 to-transparent p-2 flex items-center justify-between text-[11px] text-white/90">
          <span className="font-medium flex items-center gap-1">
            <MapPin className="w-3 h-3 text-emerald-400" /> {listing.neighborhood}
          </span>
          <span className="flex items-center gap-1 opacity-80">
            <Eye className="w-3 h-3" /> {listing.viewCount}
          </span>
        </div>
      </div>

      {/* Card Content */}
      <div className="p-3.5 flex flex-col flex-1 justify-between gap-2">
        {/* Title */}
        <div>
          <h3 className="text-sm font-semibold text-slate-900 line-clamp-2 leading-snug group-hover:text-emerald-700 transition-colors">
            {listing.title}
          </h3>
          
          {/* Metadata: Zero-pill discipline */}
          <div className="mt-1 flex items-center gap-1.5 text-xs text-slate-500 font-normal">
            <span>{getSpecsSnippet()}</span>
            <span aria-hidden="true">·</span>
            <span>{timeAgo(listing.createdAt)}</span>
          </div>
        </div>

        {/* Price & Seller Info */}
        <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
          <div>
            <div className="text-base font-bold text-slate-900 tabular-nums tracking-tight">
              {formattedPrice} <span className="text-xs font-semibold text-emerald-700">TL</span>
            </div>
            {listing.priceHistory && listing.priceHistory.length > 1 && (
              <span className="text-[10px] text-rose-600 font-medium line-through">
                {listing.priceHistory[0].price.toLocaleString('tr-TR')} TL
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-600 max-w-[130px] truncate" title={listing.sellerName}>
            {listing.sellerType === 'kurumsal' ? (
              <Building2 className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
            ) : (
              <UserIcon className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            )}
            <span className="truncate">{listing.sellerName}</span>
            {listing.isVerifiedSeller && (
              <span title="Doğrulanmış Satıcı" className="inline-flex shrink-0">
                <BadgeCheck className="w-3.5 h-3.5 text-emerald-600" />
              </span>
            )}
          </div>
        </div>
      </div>
    </article>
  );
};
