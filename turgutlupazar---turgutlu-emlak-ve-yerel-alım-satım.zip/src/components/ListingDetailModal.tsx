import React, { useState } from 'react';
import { Listing } from '../types';
import { PriceTrendChart } from './PriceTrendChart';
import {
  X,
  Heart,
  Share2,
  MapPin,
  Calendar,
  Eye,
  CheckCircle2,
  Phone,
  MessageSquare,
  BadgeCheck,
  Building2,
  Send,
  Flag,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Check,
  Sparkles
} from 'lucide-react';

interface ListingDetailModalProps {
  listing: Listing | null;
  isOpen: boolean;
  onClose: () => void;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onOpenOfferModal: (listing: Listing) => void;
  onOpenMessageModal: (listing: Listing) => void;
  onOpenReportModal: (listing: Listing) => void;
  onFilterBySeller?: (sellerId: string) => void;
  onOpenAiValuation?: (listing: Listing) => void;
  currentUser?: { role?: string; name?: string; email?: string } | null;
  onAdminRemoveListing?: (listingId: string) => void;
  onAdminTogglePassive?: (listingId: string, currentStatus: string) => void;
}

export const ListingDetailModal: React.FC<ListingDetailModalProps> = ({
  listing,
  isOpen,
  onClose,
  isFavorite,
  onToggleFavorite,
  onOpenOfferModal,
  onOpenMessageModal,
  onOpenReportModal,
  onFilterBySeller,
  onOpenAiValuation,
  currentUser,
  onAdminRemoveListing,
  onAdminTogglePassive
}) => {
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [showPhone, setShowPhone] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen || !listing) return null;

  const images = listing.images && listing.images.length > 0 ? listing.images : [];

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: listing.title,
        text: `${listing.title} - TurgutluPazar`,
        url: window.location.href
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const handleWhatsApp = () => {
    const cleanPhone = listing.sellerPhone.replace(/[^0-9]/g, '');
    const phoneWithCountry = cleanPhone.startsWith('0') ? `90${cleanPhone.slice(1)}` : cleanPhone;
    const msg = encodeURIComponent(
      `Merhaba, TurgutluPazar üzerindeki "${listing.title}" (#${listing.id}) ilanınız için yazıyorum. Bilgi alabilir miyim?`
    );
    window.open(`https://wa.me/${phoneWithCountry}?text=${msg}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-5xl bg-white rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between bg-white z-10 shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
            <span className="text-slate-900 font-semibold">{listing.district}, Manisa</span>
            <span>/</span>
            <span>{listing.neighborhood} Mahallesi</span>
            <span>/</span>
            <span className="text-slate-400">İlan No: #{listing.id.toUpperCase()}</span>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handleShare}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-1.5 text-xs font-medium"
              title="İlanı Paylaş"
            >
              {copiedLink ? <Check className="w-4 h-4 text-emerald-600" /> : <Share2 className="w-4 h-4" />}
              <span className="hidden sm:inline">{copiedLink ? 'Kopyalandı' : 'Paylaş'}</span>
            </button>
            <button
              onClick={() => onToggleFavorite(listing.id)}
              className={`p-2 rounded-lg transition-colors flex items-center gap-1.5 text-xs font-medium ${
                isFavorite
                  ? 'text-rose-600 bg-rose-50'
                  : 'text-slate-600 hover:text-rose-600 hover:bg-slate-100'
              }`}
              title="Favorilere Ekle"
            >
              <Heart className={`w-4 h-4 ${isFavorite ? 'fill-rose-600' : ''}`} />
              <span className="hidden sm:inline">Favori</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
              aria-label="Kapat"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="overflow-y-auto p-4 sm:p-6 space-y-6 flex-1">
          {/* Admin Quick Moderation Ribbon */}
          {currentUser?.role === 'admin' && (
            <div className="bg-purple-950 text-purple-100 p-3.5 rounded-xl border border-purple-800 flex flex-wrap items-center justify-between gap-3 text-xs shadow-md">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-purple-400 shrink-0" />
                <div>
                  <span className="font-bold text-white block">Yönetici (Admin) Denetim Çubuğu</span>
                  <span className="text-[11px] text-purple-300">
                    Durum: <strong className={listing.status === 'active' ? 'text-emerald-400' : 'text-amber-400'}>
                      {listing.status === 'active' ? 'Yayında (Aktif)' : 'Yayından Kaldırılmış (Pasif)'}
                    </strong>
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => onAdminTogglePassive?.(listing.id, listing.status)}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all shadow-xs cursor-pointer ${
                    listing.status === 'active'
                      ? 'bg-amber-600 hover:bg-amber-700 text-white'
                      : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                  }`}
                >
                  {listing.status === 'active' ? 'İlanı Yayından Kaldır (Pasife Al)' : 'Yeniden Yayına Al'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (window.confirm(`"${listing.title}" ilanını kalıcı olarak silmek ve yayından tamamen kaldırmak istiyor musunuz?`)) {
                      onAdminRemoveListing?.(listing.id);
                      onClose();
                    }
                  }}
                  className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg transition-all shadow-xs cursor-pointer"
                >
                  İlanı Tamamen Sil
                </button>
              </div>
            </div>
          )}

          {/* Main Top Grid: Gallery & Right Purchase/Seller Bar */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Gallery Column (7 cols) */}
            <div className="lg:col-span-7 flex flex-col gap-3">
              {/* Main Photo */}
              <div className="relative aspect-16/10 sm:aspect-16/11 w-full bg-slate-900 rounded-xl overflow-hidden group">
                {images[activeImageIndex] ? (
                  <img
                    src={images[activeImageIndex]}
                    alt={listing.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-400">
                    Görsel bulunamadı
                  </div>
                )}

                {/* Left/Right arrow controls */}
                {images.length > 1 && (
                  <>
                    <button
                      onClick={() => setActiveImageIndex((prev) => (prev > 0 ? prev - 1 : images.length - 1))}
                      className="absolute left-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/40 hover:bg-black/70 text-white backdrop-blur-xs transition-opacity opacity-0 group-hover:opacity-100"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button
                      onClick={() => setActiveImageIndex((prev) => (prev < images.length - 1 ? prev + 1 : 0))}
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/40 hover:bg-black/70 text-white backdrop-blur-xs transition-opacity opacity-0 group-hover:opacity-100"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </>
                )}

                <div className="absolute bottom-2.5 right-3 px-2 py-1 rounded bg-black/60 text-white text-xs font-medium backdrop-blur-xs">
                  {activeImageIndex + 1} / {images.length || 1}
                </div>
              </div>

              {/* Thumbnails row */}
              {images.length > 1 && (
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImageIndex(idx)}
                      className={`relative w-20 h-14 rounded-lg overflow-hidden shrink-0 border-2 transition-all ${
                        activeImageIndex === idx
                          ? 'border-emerald-600 scale-102 ring-2 ring-emerald-500/20'
                          : 'border-transparent opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Price & Seller Column (5 cols) */}
            <div className="lg:col-span-5 flex flex-col justify-between gap-5 bg-slate-50/70 p-5 rounded-xl border border-slate-200/80">
              <div className="space-y-3">
                {/* Title & Price */}
                <div>
                  <h1 className="text-lg sm:text-xl font-bold text-slate-900 leading-snug">
                    {listing.title}
                  </h1>
                  <div className="mt-2 flex items-baseline gap-2">
                    <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 tabular-nums">
                      {listing.price.toLocaleString('tr-TR')}
                    </span>
                    <span className="text-base font-bold text-emerald-700">TL</span>
                    {listing.listingType === 'kiralik' && (
                      <span className="text-xs text-slate-500 font-medium">/ Aylık</span>
                    )}
                  </div>
                </div>

                {/* Location & Quick Meta */}
                <div className="flex flex-wrap items-center gap-y-1 gap-x-3 text-xs text-slate-600 border-y border-slate-200/60 py-2.5">
                  <span className="flex items-center gap-1 font-medium text-slate-700">
                    <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                    Turgutlu, {listing.neighborhood}
                  </span>
                  <span aria-hidden="true" className="text-slate-300">·</span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    {listing.createdAt}
                  </span>
                  <span aria-hidden="true" className="text-slate-300">·</span>
                  <span className="flex items-center gap-1">
                    <Eye className="w-3.5 h-3.5 text-slate-400" />
                    {listing.viewCount} Görüntülenme
                  </span>
                </div>

                {/* Seller Profile Card */}
                <div className="bg-white p-3.5 rounded-lg border border-slate-200/80 space-y-2.5 shadow-2xs">
                  <div className="flex items-center gap-3">
                    {listing.sellerAvatar ? (
                      <img
                        src={listing.sellerAvatar}
                        alt={listing.sellerName}
                        className="w-12 h-12 rounded-full object-cover border border-slate-200"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-lg">
                        {listing.sellerName.charAt(0)}
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <h4 className="font-semibold text-slate-900 text-sm truncate">
                          {listing.sellerName}
                        </h4>
                        {listing.isVerifiedSeller && (
                          <span title="Doğrulanmış Hesap" className="inline-flex shrink-0">
                            <BadgeCheck className="w-4 h-4 text-emerald-600" />
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-500 flex items-center gap-2">
                        <span>{listing.sellerType === 'kurumsal' ? 'Kurumsal Emlak Ofisi' : 'Bireysel Satıcı'}</span>
                        <span>·</span>
                        <span className="text-amber-600 font-semibold">★ {listing.sellerRating.toFixed(1)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
                    <span className="flex items-center gap-1 text-emerald-700 font-medium">
                      <ShieldCheck className="w-3.5 h-3.5" /> Doğrulanmış Telefon & Kimlik
                    </span>
                    {onFilterBySeller && (
                      <button
                        onClick={() => {
                          onFilterBySeller(listing.sellerId);
                          onClose();
                        }}
                        className="text-emerald-700 hover:underline font-medium"
                      >
                        Diğer İlanları
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Action Buttons: Phone, WhatsApp, Chat, Offer */}
              <div className="space-y-2 pt-2">
                {/* Phone button */}
                <button
                  type="button"
                  onClick={() => setShowPhone(!showPhone)}
                  className="w-full py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-medium text-sm flex items-center justify-center gap-2 transition-colors shadow-xs"
                >
                  <Phone className="w-4 h-4 text-emerald-400" />
                  <span>
                    {showPhone ? listing.sellerPhone : `${listing.sellerPhone.slice(0, 6)} *** ** ${listing.sellerPhone.slice(-2)} (Numarayı Göster)`}
                  </span>
                </button>

                {/* WhatsApp button */}
                <button
                  type="button"
                  onClick={handleWhatsApp}
                  className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-medium text-sm flex items-center justify-center gap-2 transition-colors shadow-xs"
                >
                  <span className="font-bold">WhatsApp</span> ile İletişime Geç
                </button>

                <div className="grid grid-cols-2 gap-2">
                  {/* Chat button */}
                  <button
                    type="button"
                    onClick={() => {
                      onOpenMessageModal(listing);
                      onClose();
                    }}
                    className="py-2 px-3 border border-slate-300 hover:bg-white bg-white/70 text-slate-700 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <MessageSquare className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Mesaj Gönder</span>
                  </button>

                  {/* Make Offer button */}
                  <button
                    type="button"
                    onClick={() => {
                      onOpenOfferModal(listing);
                    }}
                    className="py-2 px-3 border border-amber-300 bg-amber-50 hover:bg-amber-100 text-amber-900 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Send className="w-3.5 h-3.5 text-amber-700" />
                    <span>Teklif Ver</span>
                  </button>
                </div>

                {/* AI Valuation button */}
                {onOpenAiValuation && (
                  <button
                    type="button"
                    onClick={() => onOpenAiValuation(listing)}
                    className="w-full py-2.5 px-3 bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 hover:from-emerald-700 hover:to-indigo-700 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all shadow-xs active:scale-98"
                  >
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>Yapay Zeka ile İlanı Değerle & Fiyat Analizi Al</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Section 2: Specifications Table (Emlak / Vasıta / Tarım) */}
          <div className="border-t border-slate-200 pt-5">
            <h3 className="text-base font-bold text-slate-900 mb-3">İlan Özellikleri</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5 text-xs">
              {listing.specs.m2Gross && (
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-slate-400 block text-[11px]">m² (Brüt)</span>
                  <span className="font-semibold text-slate-800 tabular-nums">{listing.specs.m2Gross} m²</span>
                </div>
              )}
              {listing.specs.m2Net && (
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-slate-400 block text-[11px]">m² (Net)</span>
                  <span className="font-semibold text-slate-800 tabular-nums">{listing.specs.m2Net} m²</span>
                </div>
              )}
              {listing.specs.roomCount && (
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-slate-400 block text-[11px]">Oda Sayısı</span>
                  <span className="font-semibold text-slate-800">{listing.specs.roomCount}</span>
                </div>
              )}
              {listing.specs.buildingAge && (
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-slate-400 block text-[11px]">Bina Yaşı</span>
                  <span className="font-semibold text-slate-800">{listing.specs.buildingAge}</span>
                </div>
              )}
              {listing.specs.floor && (
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-slate-400 block text-[11px]">Bulunduğu Kat</span>
                  <span className="font-semibold text-slate-800">{listing.specs.floor}</span>
                </div>
              )}
              {listing.specs.heating && (
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-slate-400 block text-[11px]">Isıtma</span>
                  <span className="font-semibold text-slate-800">{listing.specs.heating}</span>
                </div>
              )}
              {listing.specs.deedStatus && (
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-slate-400 block text-[11px]">Tapu Durumu</span>
                  <span className="font-semibold text-slate-800">{listing.specs.deedStatus}</span>
                </div>
              )}
              {listing.specs.zoningStatus && (
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-slate-400 block text-[11px]">İmar Durumu</span>
                  <span className="font-semibold text-slate-800">{listing.specs.zoningStatus}</span>
                </div>
              )}
              {listing.specs.creditEligible !== undefined && (
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-slate-400 block text-[11px]">Krediye Uygunluk</span>
                  <span className="font-semibold text-slate-800">
                    {listing.specs.creditEligible ? 'Evet (Uygun)' : 'Hayır'}
                  </span>
                </div>
              )}
              {listing.specs.elevator !== undefined && (
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-slate-400 block text-[11px]">Asansör</span>
                  <span className="font-semibold text-slate-800">{listing.specs.elevator ? 'Var' : 'Yok'}</span>
                </div>
              )}
              {listing.specs.parking !== undefined && (
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-slate-400 block text-[11px]">Otopark</span>
                  <span className="font-semibold text-slate-800">{listing.specs.parking ? 'Var' : 'Yok'}</span>
                </div>
              )}
              {listing.specs.balcony !== undefined && (
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-slate-400 block text-[11px]">Balkon</span>
                  <span className="font-semibold text-slate-800">{listing.specs.balcony ? 'Var' : 'Yok'}</span>
                </div>
              )}
              {/* Araç & Tarım Spesifikasyonları */}
              {listing.specs.brand && (
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-slate-400 block text-[11px]">Marka</span>
                  <span className="font-semibold text-slate-800">{listing.specs.brand}</span>
                </div>
              )}
              {listing.specs.model && (
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-slate-400 block text-[11px]">Model</span>
                  <span className="font-semibold text-slate-800">{listing.specs.model}</span>
                </div>
              )}
              {listing.specs.year && (
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-slate-400 block text-[11px]">Model Yılı</span>
                  <span className="font-semibold text-slate-800 tabular-nums">{listing.specs.year}</span>
                </div>
              )}
              {listing.specs.km !== undefined && (
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-slate-400 block text-[11px]">Kilometre</span>
                  <span className="font-semibold text-slate-800 tabular-nums">
                    {listing.specs.km.toLocaleString('tr-TR')} km
                  </span>
                </div>
              )}
              {listing.specs.engineHours !== undefined && (
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100">
                  <span className="text-slate-400 block text-[11px]">Çalışma Saati</span>
                  <span className="font-semibold text-slate-800 tabular-nums">{listing.specs.engineHours} saat</span>
                </div>
              )}
            </div>
          </div>

          {/* Section 2.5: Recharts Price Trend Chart for this listing */}
          <div className="border-t border-slate-200 pt-5">
            <PriceTrendChart listing={listing} />
          </div>

          {/* Section 3: Description */}
          <div className="border-t border-slate-200 pt-5">
            <h3 className="text-base font-bold text-slate-900 mb-2">Açıklama</h3>
            <p className="text-slate-700 text-sm leading-relaxed whitespace-pre-line bg-white p-4 rounded-xl border border-slate-100">
              {listing.description}
            </p>
          </div>

          {/* Section 4: Turgutlu Location & Trust Info */}
          <div className="border-t border-slate-200 pt-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-bold text-slate-900">Konum & Çevre Bilgisi</h3>
              <span className="text-xs text-slate-500">Manisa / Turgutlu / {listing.neighborhood}</span>
            </div>
            
            {/* Styled Map Placeholder with Turgutlu context */}
            <div className="relative h-48 w-full rounded-xl overflow-hidden border border-slate-200 bg-slate-100 flex items-center justify-center">
              <div className="absolute inset-0 opacity-40 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:16px_16px]"></div>
              <div className="relative text-center p-4">
                <div className="w-10 h-10 mx-auto mb-2 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-lg animate-bounce">
                  <MapPin className="w-5 h-5" />
                </div>
                <h4 className="font-bold text-slate-800 text-sm">
                  {listing.neighborhood} Mahallesi, Turgutlu
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Gediz Ovası & Turgutlu İlçe Merkez Lokasyonu
                </p>
              </div>
            </div>
          </div>

          {/* Section 5: Complaint footer button */}
          <div className="border-t border-slate-100 pt-4 flex items-center justify-between text-xs text-slate-400">
            <span>TurgutluPazar Güvenli Ticaret Protokolü ile korunmaktadır.</span>
            <button
              onClick={() => onOpenReportModal(listing)}
              className="text-slate-500 hover:text-rose-600 flex items-center gap-1 font-medium transition-colors"
            >
              <Flag className="w-3.5 h-3.5" /> İlanı Şikayet Et
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
