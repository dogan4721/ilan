import React from 'react';
import { Home, Grid, PlusCircle, MessageSquare, User } from 'lucide-react';
import { StorageService } from '../services/storage';

interface MobileNavProps {
  activeScreen: string;
  onNavigateHome: () => void;
  onOpenCategories: () => void;
  onOpenPostListing: () => void;
  onOpenMessages: () => void;
  onOpenProfile: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  activeScreen,
  onNavigateHome,
  onOpenCategories,
  onOpenPostListing,
  onOpenMessages,
  onOpenProfile
}) => {
  const conversations = StorageService.getConversations();
  const unreadMessages = conversations.reduce((acc, curr) => acc + (curr.unreadCount || 0), 0);

  return (
    <nav className="fixed bottom-0 inset-x-0 bg-white/95 backdrop-blur-md border-t border-slate-200 z-40 lg:hidden px-2 py-1 shadow-lg">
      <div className="grid grid-cols-5 items-center">
        <button
          onClick={onNavigateHome}
          className={`flex flex-col items-center justify-center py-1.5 transition-colors ${
            activeScreen === 'home' ? 'text-emerald-700' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-medium mt-0.5">Ana Sayfa</span>
        </button>

        <button
          onClick={onOpenCategories}
          className={`flex flex-col items-center justify-center py-1.5 transition-colors ${
            activeScreen === 'categories' ? 'text-emerald-700' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <Grid className="w-5 h-5" />
          <span className="text-[10px] font-medium mt-0.5">Kategoriler</span>
        </button>

        <button
          onClick={onOpenPostListing}
          className="flex flex-col items-center justify-center py-1 -mt-4"
        >
          <div className="w-12 h-12 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-lg active:scale-95 transition-transform">
            <PlusCircle className="w-6 h-6" />
          </div>
          <span className="text-[10px] font-bold text-emerald-800 mt-0.5">İlan Ver</span>
        </button>

        <button
          onClick={onOpenMessages}
          className={`flex flex-col items-center justify-center py-1.5 transition-colors relative ${
            activeScreen === 'messages' ? 'text-emerald-700' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <div className="relative">
            <MessageSquare className="w-5 h-5" />
            {unreadMessages > 0 && (
              <span className="absolute -top-1 -right-1.5 w-4 h-4 bg-emerald-600 text-white rounded-full text-[9px] font-bold flex items-center justify-center">
                {unreadMessages}
              </span>
            )}
          </div>
          <span className="text-[10px] font-medium mt-0.5">Mesajlar</span>
        </button>

        <button
          onClick={onOpenProfile}
          className={`flex flex-col items-center justify-center py-1.5 transition-colors ${
            activeScreen === 'dashboard' ? 'text-emerald-700' : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <User className="w-5 h-5" />
          <span className="text-[10px] font-medium mt-0.5">Profil</span>
        </button>
      </div>
    </nav>
  );
};
