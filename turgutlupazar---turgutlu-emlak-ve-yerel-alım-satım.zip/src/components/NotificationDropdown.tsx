import React from 'react';
import { StorageService } from '../services/storage';
import { Notification } from '../types';
import { Bell, Check, TrendingDown, Send, MessageSquare, AlertCircle } from 'lucide-react';

interface NotificationDropdownProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenDashboardTab?: (tab: string) => void;
}

export const NotificationDropdown: React.FC<NotificationDropdownProps> = ({
  isOpen,
  onClose,
  onOpenDashboardTab
}) => {
  if (!isOpen) return null;

  const notifications = StorageService.getNotifications();

  const handleMarkAllRead = () => {
    StorageService.markNotificationsRead();
  };

  const handleClickItem = (item: Notification) => {
    if (item.type === 'offer' && onOpenDashboardTab) {
      onOpenDashboardTab('tekliflerim');
    } else if (item.type === 'message' && onOpenDashboardTab) {
      onOpenDashboardTab('mesajlarim');
    } else if (item.type === 'price_drop' && onOpenDashboardTab) {
      onOpenDashboardTab('favorilerim');
    }
    onClose();
  };

  return (
    <div className="absolute right-0 top-full mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden z-50 animate-in fade-in duration-150">
      <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50">
        <div className="flex items-center gap-2">
          <Bell className="w-4 h-4 text-emerald-600" />
          <span className="font-bold text-slate-900 text-xs sm:text-sm">Bildirimler</span>
        </div>
        <button
          onClick={handleMarkAllRead}
          className="text-[11px] font-semibold text-emerald-700 hover:underline"
        >
          Tümünü Okundu Say
        </button>
      </div>

      <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 text-xs">
        {notifications.length === 0 ? (
          <div className="p-6 text-center text-slate-400">Yeni bildiriminiz yok.</div>
        ) : (
          notifications.map((n) => (
            <div
              key={n.id}
              onClick={() => handleClickItem(n)}
              className={`p-3.5 hover:bg-slate-50 cursor-pointer transition-colors flex items-start gap-3 ${
                !n.isRead ? 'bg-emerald-50/40' : ''
              }`}
            >
              <div className="p-2 rounded-xl bg-white border border-slate-200 shrink-0 text-emerald-600 shadow-2xs">
                {n.type === 'offer' && <Send className="w-3.5 h-3.5 text-amber-600" />}
                {n.type === 'price_drop' && <TrendingDown className="w-3.5 h-3.5 text-rose-600" />}
                {n.type === 'message' && <MessageSquare className="w-3.5 h-3.5 text-indigo-600" />}
                {n.type === 'status' && <Check className="w-3.5 h-3.5 text-emerald-600" />}
                {n.type === 'system' && <AlertCircle className="w-3.5 h-3.5 text-slate-600" />}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 truncate">{n.title}</span>
                  <span className="text-[10px] text-slate-400 shrink-0">{n.timestamp}</span>
                </div>
                <p className="text-slate-600 text-[11px] mt-0.5 line-clamp-2 leading-relaxed">
                  {n.message}
                </p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
