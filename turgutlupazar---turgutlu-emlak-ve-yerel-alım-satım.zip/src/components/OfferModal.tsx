import React, { useState } from 'react';
import { Listing, User } from '../types';
import { StorageService } from '../services/storage';
import { X, Send, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface OfferModalProps {
  listing: Listing | null;
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onSuccess: () => void;
}

export const OfferModal: React.FC<OfferModalProps> = ({
  listing,
  isOpen,
  onClose,
  currentUser,
  onSuccess
}) => {
  const [offerPrice, setOfferPrice] = useState('');
  const [note, setNote] = useState('');
  const [isSent, setIsSent] = useState(false);

  if (!isOpen || !listing) return null;

  const defaultSuggested = Math.round(listing.price * 0.93);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const priceNum = parseFloat(offerPrice.replace(/[^0-9]/g, '')) || defaultSuggested;
    StorageService.createOffer({
      listingId: listing.id,
      offeredPrice: priceNum,
      message: note
    });

    setIsSent(true);
    setTimeout(() => {
      setIsSent(false);
      onSuccess();
      onClose();
    }, 1400);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden my-auto">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <Send className="w-4 h-4 text-emerald-600" />
            <h3 className="font-bold text-slate-900 text-sm">Fiyat Teklifi Gönder</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-700 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSent ? (
          <div className="p-8 text-center space-y-2">
            <CheckCircle2 className="w-14 h-14 text-emerald-600 mx-auto" />
            <h4 className="font-bold text-slate-900 text-base">Teklifiniz Satıcıya İletildi!</h4>
            <p className="text-xs text-slate-500">
              Satıcı yanıt verdiğinde panelinize bildirim gelecektir.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
            {/* Listing snippet */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center gap-3">
              <img
                src={listing.images[0]}
                alt=""
                className="w-14 h-12 rounded-lg object-cover shrink-0"
              />
              <div className="min-w-0">
                <span className="font-semibold text-slate-900 line-clamp-1">{listing.title}</span>
                <span className="text-slate-500 text-[11px] block">
                  Satıcı Fiyatı:{' '}
                  <strong className="text-slate-800 tabular-nums">
                    {listing.price.toLocaleString('tr-TR')} TL
                  </strong>
                </span>
              </div>
            </div>

            {/* Offer Input */}
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Teklif Ettiğiniz Tutar (TL) <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                placeholder={defaultSuggested.toLocaleString('tr-TR')}
                value={offerPrice}
                onChange={(e) => setOfferPrice(e.target.value)}
                className="w-full p-3 border border-slate-300 rounded-xl text-base font-bold tabular-nums text-slate-900 focus:border-emerald-600"
                autoFocus
              />
              <div className="flex items-center gap-1.5 mt-1.5">
                <span className="text-slate-400 text-[10px]">Hızlı Öneri:</span>
                <button
                  type="button"
                  onClick={() => setOfferPrice(Math.round(listing.price * 0.95).toString())}
                  className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-[10px] text-slate-700 font-medium"
                >
                  %5 İndirim
                </button>
                <button
                  type="button"
                  onClick={() => setOfferPrice(Math.round(listing.price * 0.9).toString())}
                  className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 rounded text-[10px] text-slate-700 font-medium"
                >
                  %10 İndirim
                </button>
              </div>
            </div>

            {/* Note */}
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                Satıcıya Not (İsteğe Bağlı)
              </label>
              <textarea
                rows={3}
                placeholder="Nakit ödeme yapabilirim, tapu devrini hemen gerçekleştirebiliriz..."
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="w-full p-2.5 border border-slate-300 rounded-xl text-xs"
              />
            </div>

            <div className="p-2.5 bg-emerald-50 rounded-xl text-emerald-800 text-[11px] flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                Teklifiniz satıcıyı bağlamaz. Satıcı kabul ettiğinde veya karşı teklif verdiğinde görüşebilirsiniz.
              </span>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition-colors"
            >
              Teklifi Gönder
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
