import React, { useState } from 'react';
import { StorageService } from '../services/storage';
import { User } from '../types';
import {
  X,
  CreditCard,
  Building,
  ShieldCheck,
  CheckCircle2,
  Lock,
  Sparkles,
  ArrowRight
} from 'lucide-react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  packageName?: string;
  amount?: number;
  onSuccess: () => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  packageName = 'Ana Sayfa Vitrin Paketi (30 Gün)',
  amount = 299,
  onSuccess
}) => {
  const [method, setMethod] = useState<'card' | 'bank_transfer' | 'secure_pay'>('card');
  const [cardNumber, setCardNumber] = useState('4543 •••• •••• 1289');
  const [cardHolder, setCardHolder] = useState(currentUser.name);
  const [expiry, setExpiry] = useState('12/28');
  const [cvv, setCvv] = useState('842');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showOtp, setShowOtp] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const commission = 0;
  const kdv = Math.round(amount * 0.2);
  const total = amount;

  const handleStartPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (method === 'card') {
      setIsProcessing(true);
      setTimeout(() => {
        setIsProcessing(false);
        setShowOtp(true);
      }, 700);
    } else {
      finalizePayment();
    }
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    finalizePayment();
  };

  const finalizePayment = () => {
    setIsProcessing(true);
    setTimeout(() => {
      StorageService.recordPayment({
        userId: currentUser.id,
        userName: currentUser.companyName || currentUser.name,
        packageName,
        amount: total,
        method,
        status: 'completed'
      });
      setIsProcessing(false);
      setIsSuccess(true);
      setTimeout(() => {
        setIsSuccess(false);
        setShowOtp(false);
        onSuccess();
        onClose();
      }, 1500);
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="relative w-full max-w-xl bg-white rounded-2xl shadow-2xl overflow-hidden my-auto flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-600 text-white">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Güvenli Ödeme Ekranı</h2>
              <p className="text-[11px] text-slate-500">256-Bit SSL Şifreli Güvenli Altyapı</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success Screen */}
        {isSuccess ? (
          <div className="p-8 text-center space-y-3">
            <CheckCircle2 className="w-16 h-16 text-emerald-600 mx-auto animate-bounce" />
            <h3 className="text-lg font-bold text-slate-900">Ödemeniz Başarıyla Alındı!</h3>
            <p className="text-xs text-slate-500">
              {packageName} paketiniz aktif edildi. İlanınız Turgutlu vitrininde öne çıkarıldı.
            </p>
          </div>
        ) : showOtp ? (
          /* 3D Secure Simulation */
          <div className="p-6 space-y-4">
            <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 text-xs text-emerald-900">
              <h4 className="font-bold flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-600" /> BKM Express / 3D Secure Test Doğrulaması
              </h4>
              <p className="mt-1 text-emerald-800">
                {currentUser.phone} numaralı telefonunuza gönderilen 6 haneli test SMS onay kodunu giriniz (Demo kodu: <strong>123456</strong>).
              </p>
            </div>

            <form onSubmit={handleVerifyOtp} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Doğrulama Kodu</label>
                <input
                  type="text"
                  placeholder="123456"
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value)}
                  className="w-full text-center tracking-widest text-lg font-bold p-3 border border-slate-300 rounded-xl"
                  autoFocus
                />
              </div>
              <button
                type="submit"
                disabled={isProcessing}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-bold shadow-md"
              >
                {isProcessing ? 'Onaylanıyor...' : 'Ödemeyi Tamamla ve Onayla'}
              </button>
            </form>
          </div>
        ) : (
          /* Main Checkout Form */
          <div className="p-6 space-y-5">
            {/* Order Summary Box */}
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/80 space-y-2 text-xs">
              <div className="flex items-center justify-between font-semibold text-slate-800">
                <span>{packageName}</span>
                <span className="tabular-nums font-bold">{amount} TL</span>
              </div>
              <div className="flex items-center justify-between text-slate-500 text-[11px]">
                <span>Platform İşlem Komisyonu</span>
                <span className="text-emerald-700 font-bold">0 TL (Ücretsiz)</span>
              </div>
              <div className="flex items-center justify-between text-slate-500 text-[11px]">
                <span>KDV (%20 Dahil)</span>
                <span>{kdv} TL</span>
              </div>
              <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-sm font-bold text-slate-900">
                <span>Toplam Ödenecek Tutar</span>
                <span className="text-lg text-emerald-700 tabular-nums">{total} TL</span>
              </div>
            </div>

            {/* Payment Method Switcher */}
            <div className="grid grid-cols-3 gap-2 text-xs">
              <button
                type="button"
                onClick={() => setMethod('card')}
                className={`p-2.5 rounded-xl border font-semibold flex flex-col items-center gap-1 transition-all ${
                  method === 'card'
                    ? 'border-emerald-600 bg-emerald-50/50 text-emerald-800 ring-2 ring-emerald-500/20'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <CreditCard className="w-4 h-4" />
                <span>Kredi Kartı</span>
              </button>
              <button
                type="button"
                onClick={() => setMethod('bank_transfer')}
                className={`p-2.5 rounded-xl border font-semibold flex flex-col items-center gap-1 transition-all ${
                  method === 'bank_transfer'
                    ? 'border-emerald-600 bg-emerald-50/50 text-emerald-800 ring-2 ring-emerald-500/20'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <Building className="w-4 h-4" />
                <span>Havale / EFT</span>
              </button>
              <button
                type="button"
                onClick={() => setMethod('secure_pay')}
                className={`p-2.5 rounded-xl border font-semibold flex flex-col items-center gap-1 transition-all ${
                  method === 'secure_pay'
                    ? 'border-emerald-600 bg-emerald-50/50 text-emerald-800 ring-2 ring-emerald-500/20'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Güvenli Havuz</span>
              </button>
            </div>

            {/* Credit Card Inputs */}
            {method === 'card' && (
              <form onSubmit={handleStartPayment} className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Kart Numarası</label>
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    className="w-full p-2.5 border border-slate-300 rounded-lg tabular-nums text-sm font-medium"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Kart Üzerindeki İsim</label>
                  <input
                    type="text"
                    value={cardHolder}
                    onChange={(e) => setCardHolder(e.target.value)}
                    className="w-full p-2.5 border border-slate-300 rounded-lg text-sm"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">Son Kullanma (AA/YY)</label>
                    <input
                      type="text"
                      value={expiry}
                      onChange={(e) => setExpiry(e.target.value)}
                      className="w-full p-2.5 border border-slate-300 rounded-lg text-sm tabular-nums"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">CVV / Güvenlik Kodu</label>
                    <input
                      type="password"
                      maxLength={4}
                      value={cvv}
                      onChange={(e) => setCvv(e.target.value)}
                      className="w-full p-2.5 border border-slate-300 rounded-lg text-sm tabular-nums"
                    />
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={isProcessing}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-bold shadow-md transition-all active:scale-98 flex items-center justify-center gap-2"
                  >
                    <span>{isProcessing ? 'İşleniyor...' : `${total} TL Güvenli Ödeme Yap`}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}

            {/* Bank Transfer Info */}
            {method === 'bank_transfer' && (
              <div className="space-y-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
                  <span className="font-bold text-slate-800 block">Ziraat Bankası Turgutlu Şubesi</span>
                  <div className="text-slate-500 font-mono select-all">TR45 0001 0002 4500 1289 0001</div>
                  <div className="text-[11px] text-slate-400">Alıcı: TurgutluPazar Bilişim Hizmetleri</div>
                </div>
                <button
                  type="button"
                  onClick={finalizePayment}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-bold shadow-md"
                >
                  Havale Bildiriminde Bulun
                </button>
              </div>
            )}

            {/* Secure Pool Info */}
            {method === 'secure_pay' && (
              <div className="space-y-3 text-xs">
                <p className="text-slate-600">
                  Güvenli Havuz Sistemi: Paranızı havuza alıyoruz, ilan onayı ve teslimatı teyit edildikten sonra satıcıya aktarılır.
                </p>
                <button
                  type="button"
                  onClick={finalizePayment}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-bold shadow-md"
                >
                  Güvenli Havuz ile Tamamla ({total} TL)
                </button>
              </div>
            )}

            {/* Trust disclaimer */}
            <p className="text-[10px] text-slate-400 text-center">
              Frontend prototip aşamasında gerçek kredi kartı çekimi yapılmaz; test simülasyonu çalışmaktadır.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
