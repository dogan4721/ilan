import React, { useState, useRef } from 'react';
import { CategoryId, ListingType, ListingSpecs, User, Listing } from '../types';
import { TURGUTLU_NEIGHBORHOODS } from '../data/turgutluData';
import { StorageService } from '../services/storage';
import { FirestoreService } from '../firebase/firestoreService';
import { FirebaseStorageService } from '../firebase/storageService';
import { isConnected } from '../firebase/config';
import {
  X,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Upload,
  Sparkles,
  MapPin,
  Image as ImageIcon,
  Check,
  Building2,
  Car,
  Smartphone,
  Armchair,
  Wheat,
  Briefcase
} from 'lucide-react';

interface PostListingWizardProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onSuccess: (newListing: Listing) => void;
}

const PRESET_SAMPLE_PHOTOS: { category: CategoryId; title: string; url: string }[] = [
  {
    category: 'emlak',
    title: 'Modern Daire Salonu',
    url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=80'
  },
  {
    category: 'emlak',
    title: 'Açık Mutfak & Balkon',
    url: 'https://images.unsplash.com/photo-1600565193348-f74bd3c7ccdf?auto=format&fit=crop&w=1000&q=80'
  },
  {
    category: 'emlak',
    title: 'Müstakil Bahçeli Ev',
    url: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=1000&q=80'
  },
  {
    category: 'emlak',
    title: 'Gediz Ovası Bağ & Tarla',
    url: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1000&q=80'
  },
  {
    category: 'tarim',
    title: 'Bahçe Traktörü',
    url: 'https://images.unsplash.com/photo-1592861956120-e524fc739696?auto=format&fit=crop&w=1000&q=80'
  },
  {
    category: 'arac',
    title: 'Otomobil Dış Görünüm',
    url: 'https://images.unsplash.com/photo-1590362891991-f776e747a588?auto=format&fit=crop&w=1000&q=80'
  },
  {
    category: 'elektronik',
    title: 'Akıllı Telefon & Aksesuar',
    url: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=1000&q=80'
  },
  {
    category: 'ev-yasam',
    title: 'Koltuk Takımı',
    url: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1000&q=80'
  }
];

export const PostListingWizard: React.FC<PostListingWizardProps> = ({
  isOpen,
  onClose,
  currentUser,
  onSuccess
}) => {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const totalSteps = 9;

  // Form State
  const [categoryId, setCategoryId] = useState<CategoryId>('emlak');
  const [subcategory, setSubcategory] = useState<string>('Satılık Daire');
  const [listingType, setListingType] = useState<ListingType>('satilik');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState<string>('');
  const [neighborhood, setNeighborhood] = useState<string>('İstasyonaltı');
  const [street, setStreet] = useState('');
  const [images, setImages] = useState<string[]>([
    'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=80'
  ]);
  const [specs, setSpecs] = useState<ListingSpecs>({
    m2Gross: 135,
    m2Net: 120,
    roomCount: '3+1',
    buildingAge: '0 (Yeni)',
    floor: '2. Kat',
    heating: 'Doğalgaz (Kombi)',
    bathroomCount: 2,
    balcony: true,
    parking: true,
    elevator: true,
    deedStatus: 'Kat Mülkiyeti',
    zoningStatus: 'Konut',
    creditEligible: true
  });
  const [addDoping, setAddDoping] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isAiGenerating, setIsAiGenerating] = useState(false);
  const [aiTitleSuggestions, setAiTitleSuggestions] = useState<string[]>([]);
  const [aiPriceEstimate, setAiPriceEstimate] = useState<{
    suggestedPrice: number;
    minPrice: number;
    maxPrice: number;
    m2Price: number;
    marketAnalysis: string;
  } | null>(null);
  const [aiStatusMessage, setAiStatusMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleGenerateAiDescription = async () => {
    setIsAiGenerating(true);
    setAiStatusMessage(null);
    try {
      const res = await fetch('/api/ai/generate-listing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'description',
          categoryId,
          subcategory,
          neighborhood,
          listingType,
          specs,
          currentTitle: title
        })
      });
      const data = await res.json();
      if (data.description) {
        setDescription(data.description);
        if (data.titles && data.titles.length > 0) {
          setAiTitleSuggestions(data.titles);
          if (!title) {
            setTitle(data.titles[0]);
          }
        }
        setAiStatusMessage('Yapay zeka başlık ve profesyonel ilan açıklamasını başarıyla oluşturdu!');
      }
    } catch {
      setAiStatusMessage('Yapay zeka önerisi alınırken bir sorun oluştu.');
    } finally {
      setIsAiGenerating(false);
    }
  };

  const handleGenerateAiPrice = async () => {
    setIsAiGenerating(true);
    setAiStatusMessage(null);
    try {
      const res = await fetch('/api/ai/generate-listing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'pricing',
          categoryId,
          subcategory,
          neighborhood,
          listingType,
          specs
        })
      });
      const data = await res.json();
      if (data.suggestedPrice) {
        setAiPriceEstimate(data);
        setAiStatusMessage(`Turgutlu ${neighborhood} mevkiine göre piyasa değerlemesi hazırlandı.`);
      }
    } catch {
      setAiStatusMessage('Fiyat analizi alınırken bir sorun oluştu.');
    } finally {
      setIsAiGenerating(false);
    }
  };

  if (!isOpen) return null;

  const categories = StorageService.getCategories();
  const selectedCat = categories.find((c) => c.id === categoryId) || categories[0];

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentStep > 1) {
      setCurrentStep((prev) => prev - 1);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setUploadError(null);
    setIsUploadingPhoto(true);

    try {
      const newUrls: string[] = [];
      const dummyListingId = `draft-${Date.now()}`;
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const uploadedUrl = await FirebaseStorageService.uploadListingImage(file, dummyListingId);
        newUrls.push(uploadedUrl);
      }
      setImages([...images, ...newUrls]);
    } catch (err: any) {
      setUploadError(err.message || 'Fotoğraf yüklenemedi.');
    } finally {
      setIsUploadingPhoto(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handlePublish = async () => {
    setIsSubmitting(true);
    try {
      const numPrice = parseFloat(price.replace(/[^0-9]/g, '')) || 1000000;
      const listingData = {
        title: title || `${neighborhood} Mahallesinde ${subcategory}`,
        description:
          description ||
          `Turgutlu ${neighborhood} mahallesinde bulunan bu ilanımız merkezi konumdadır. Detaylı bilgi için lütfen iletişime geçiniz.`,
        price: numPrice,
        categoryId,
        subcategory,
        listingType,
        city: 'Manisa',
        district: 'Turgutlu',
        neighborhood,
        street,
        images: images.length > 0 ? images : [PRESET_SAMPLE_PHOTOS[0].url],
        specs,
        sellerId: currentUser.id,
        sellerName: currentUser.companyName || currentUser.name,
        sellerType: currentUser.role === 'realtor' ? ('kurumsal' as const) : ('bireysel' as const),
        sellerPhone: currentUser.phone,
        sellerAvatar: currentUser.avatarUrl,
        sellerRating: currentUser.rating,
        isVerifiedSeller: currentUser.verifiedPhone,
        status: 'active' as const,
        isFeatured: addDoping,
        isDoping: addDoping
      };

      let newListing: Listing;
      if (isConnected) {
        try {
          newListing = await FirestoreService.createListing(listingData);
        } catch {
          newListing = StorageService.addListing(listingData);
        }
      } else {
        newListing = StorageService.addListing(listingData);
      }

      if (addDoping) {
        const payData = {
          userId: currentUser.id,
          userName: currentUser.name,
          packageName: 'Vitrin & Acil Doping Paketi (30 Gün)',
          amount: 299,
          method: 'card' as const,
          status: 'completed' as const
        };
        if (isConnected) {
          await FirestoreService.recordPayment(payData).catch(() => StorageService.recordPayment(payData));
        } else {
          StorageService.recordPayment(payData);
        }
      }

      onSuccess(newListing);
      onClose();
    } catch (err: any) {
      alert(err.message || 'İlan kaydedilirken hata oluştu.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const addPresetImage = (url: string) => {
    if (!images.includes(url)) {
      setImages([...images, url]);
    }
  };

  const removeImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
      <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl overflow-hidden my-auto flex flex-col max-h-[92vh]">
        {/* Header with Progress Steps */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/60 shrink-0">
          <div>
            <div className="text-[11px] font-semibold tracking-wider text-emerald-700 uppercase">
              Adım {currentStep} / {totalSteps}
            </div>
            <h2 className="text-base font-bold text-slate-900">
              {currentStep === 1 && 'Adım 1: Kategori Seçimi'}
              {currentStep === 2 && 'Adım 2: İlan Türü'}
              {currentStep === 3 && 'Adım 3: Başlık & Açıklama'}
              {currentStep === 4 && 'Adım 4: Fiyat Belirleme'}
              {currentStep === 5 && 'Adım 5: Konum (Turgutlu / Mahalle)'}
              {currentStep === 6 && 'Adım 6: Fotoğraf Ekleme'}
              {currentStep === 7 && 'Adım 7: İlan Özellikleri'}
              {currentStep === 8 && 'Adım 8: İlan Önizleme'}
              {currentStep === 9 && 'Adım 9: Yayınlama & Öne Çıkar'}
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Linear Progress Bar */}
        <div className="w-full bg-slate-100 h-1.5">
          <div
            className="bg-emerald-600 h-full transition-all duration-300 ease-out"
            style={{ width: `${(currentStep / totalSteps) * 100}%` }}
          />
        </div>

        {/* Wizard Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* STEP 1: KATEGORİ SEÇİMİ */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <p className="text-sm text-slate-600">
                İlanınızın yer alacağı ana kategoriyi seçiniz:
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => {
                      setCategoryId(cat.id);
                      setSubcategory(cat.subcategories[0]);
                    }}
                    className={`p-4 rounded-xl border text-left transition-all flex flex-col justify-between h-28 ${
                      categoryId === cat.id
                        ? 'border-emerald-600 bg-emerald-50/50 ring-2 ring-emerald-500/20 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <div className="text-emerald-700">
                      {cat.id === 'emlak' && <Building2 className="w-6 h-6" />}
                      {cat.id === 'arac' && <Car className="w-6 h-6" />}
                      {cat.id === 'elektronik' && <Smartphone className="w-6 h-6" />}
                      {cat.id === 'ev-yasam' && <Armchair className="w-6 h-6" />}
                      {cat.id === 'tarim' && <Wheat className="w-6 h-6" />}
                      {cat.id === 'is-hizmet' && <Briefcase className="w-6 h-6" />}
                    </div>
                    <div>
                      <div className="font-semibold text-slate-900 text-sm">{cat.name}</div>
                      <div className="text-[11px] text-slate-500">{cat.subcategories.length} alt kategori</div>
                    </div>
                  </button>
                ))}
              </div>

              {/* Subcategories */}
              <div className="pt-3">
                <label className="block text-xs font-semibold text-slate-700 mb-2">
                  Alt Kategori Seçiniz
                </label>
                <div className="flex flex-wrap gap-2">
                  {selectedCat.subcategories.map((sub) => (
                    <button
                      key={sub}
                      type="button"
                      onClick={() => setSubcategory(sub)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                        subcategory === sub
                          ? 'border-emerald-600 bg-emerald-600 text-white shadow-xs'
                          : 'border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {sub}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: İLAN TÜRÜ */}
          {currentStep === 2 && (
            <div className="space-y-4">
              <p className="text-sm text-slate-600">İlanınızın türünü belirleyiniz:</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {[
                  { id: 'satilik', label: 'Satılık', desc: 'Mülk veya eşya satışı' },
                  { id: 'kiralik', label: 'Kiralık', desc: 'Aylık / dönemsel kiralama' },
                  { id: 'ikinci-el', label: 'İkinci El', desc: 'Kullanılmış araç/ürün' },
                  { id: 'sifir', label: 'Sıfır Ürün', desc: 'Kullanılmamış / kapalı kutu' },
                  { id: 'hizmet', label: 'Hizmet / Usta', desc: 'İş veya hizmet ilanı' }
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setListingType(item.id as ListingType)}
                    className={`p-4 rounded-xl border text-left transition-all ${
                      listingType === item.id
                        ? 'border-emerald-600 bg-emerald-50/40 ring-2 ring-emerald-500/20'
                        : 'border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="font-bold text-slate-900 text-sm">{item.label}</div>
                    <div className="text-xs text-slate-500 mt-1">{item.desc}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* STEP 3: BAŞLIK & AÇIKLAMA */}
          {currentStep === 3 && (
            <div className="space-y-4">
              {/* AI Helper Banner */}
              <div className="p-3.5 bg-gradient-to-r from-indigo-50 via-emerald-50 to-indigo-50 border border-indigo-200/80 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-900">
                    <Sparkles className="w-4 h-4 text-indigo-600 animate-pulse" />
                    <span>Yapay Zeka İlan Asistanı (Turgutlu)</span>
                  </div>
                  <button
                    type="button"
                    onClick={handleGenerateAiDescription}
                    disabled={isAiGenerating}
                    className="px-3 py-1.5 bg-gradient-to-r from-indigo-600 to-emerald-600 hover:from-indigo-700 hover:to-emerald-700 text-white rounded-lg text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 active:scale-98 disabled:opacity-50"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    <span>{isAiGenerating ? 'Oluşturuluyor...' : '✨ AI ile Başlık ve Açıklama Yaz'}</span>
                  </button>
                </div>
                <p className="text-[11px] text-slate-600">
                  Seçtiğiniz kategori ({subcategory}), {neighborhood} mahallesi ve özelliklere göre satıcıyı yormayan profesyonel metin hazırlar.
                </p>

                {aiStatusMessage && (
                  <div className="text-[11px] font-semibold text-emerald-800 bg-emerald-100/70 p-2 rounded-lg flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>{aiStatusMessage}</span>
                  </div>
                )}

                {aiTitleSuggestions.length > 0 && (
                  <div className="pt-1 space-y-1">
                    <span className="text-[10px] font-bold text-indigo-900 block">AI Başlık Önerileri (Tıklayarak Seçin):</span>
                    <div className="flex flex-wrap gap-1.5">
                      {aiTitleSuggestions.map((t, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setTitle(t)}
                          className="px-2.5 py-1 bg-white hover:bg-indigo-50 text-slate-700 hover:text-indigo-900 border border-indigo-200 rounded-lg text-xs font-medium text-left transition-colors"
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  İlan Başlığı <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="Örn: Subaşı Mahallesi 3+1 Sıfır Daire Kombili Otoparklı"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 text-sm"
                />
                <span className="text-[11px] text-slate-500 mt-1 block">
                  Dikkat çekici ve mahalle ismini içeren bir başlık yazın.
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Detaylı Açıklama <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={7}
                  placeholder="İlan hakkında detaylı bilgi verin. Ulaşım, lokasyon, tapu durumu, takas imkanı vb..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 text-sm leading-relaxed"
                />
              </div>
            </div>
          )}

          {/* STEP 4: FİYAT */}
          {currentStep === 4 && (
            <div className="space-y-4 max-w-lg">
              {/* AI Price Assistant Button & Box */}
              <div className="p-3.5 bg-gradient-to-r from-emerald-50 via-teal-50 to-indigo-50 border border-emerald-200/80 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-900">
                    <Sparkles className="w-4 h-4 text-emerald-600" />
                    <span>Yapay Zeka Piyasa Fiyat Analizi</span>
                  </div>
                  <button
                    type="button"
                    onClick={handleGenerateAiPrice}
                    disabled={isAiGenerating}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 active:scale-98 disabled:opacity-50"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                    <span>{isAiGenerating ? 'Hesaplanıyor...' : '✨ Rayiç & Fiyat Tahmini Al'}</span>
                  </button>
                </div>
                <p className="text-[11px] text-slate-600">
                  Turgutlu {neighborhood} bölgesi ve emsal {subcategory} ilanlarına göre önerilen piyasa fiyatını hesaplar.
                </p>

                {aiPriceEstimate && (
                  <div className="p-3 bg-white rounded-xl border border-emerald-200/90 shadow-2xs space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Önerilen Piyasa Fiyatı:</span>
                      <span className="text-base font-extrabold text-emerald-700 tabular-nums">
                        {aiPriceEstimate.suggestedPrice.toLocaleString('tr-TR')} TL
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-600">
                      <span>Makul Değer Aralığı:</span>
                      <span className="font-semibold tabular-nums">
                        {aiPriceEstimate.minPrice.toLocaleString('tr-TR')} TL - {aiPriceEstimate.maxPrice.toLocaleString('tr-TR')} TL
                      </span>
                    </div>
                    {aiPriceEstimate.m2Price && (
                      <div className="flex items-center justify-between text-[11px] text-slate-600">
                        <span>Bölge m² Rayici:</span>
                        <span className="font-semibold tabular-nums">
                          {aiPriceEstimate.m2Price.toLocaleString('tr-TR')} TL / m²
                        </span>
                      </div>
                    )}
                    <p className="text-[11px] text-slate-500 pt-1 border-t border-slate-100">
                      {aiPriceEstimate.marketAnalysis}
                    </p>
                    <button
                      type="button"
                      onClick={() => setPrice(aiPriceEstimate.suggestedPrice.toString())}
                      className="w-full mt-1 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-lg text-xs font-bold transition-colors text-center"
                    >
                      Bu Fiyatı Uygula ({aiPriceEstimate.suggestedPrice.toLocaleString('tr-TR')} TL)
                    </button>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Fiyat (Türk Lirası) <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Örn: 3.450.000"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full pl-4 pr-12 py-3 rounded-lg border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 text-lg font-bold tabular-nums text-slate-900"
                  />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 font-bold text-sm">
                    TL
                  </span>
                </div>
              </div>

              <div className="p-3 bg-emerald-50 rounded-lg text-xs text-emerald-800 flex items-start gap-2">
                <Sparkles className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
                <span>
                  TurgutluPazar alıcıları teklif gönderebilir. Fiyatı piyasa rayicine uygun tutmanız hızlı satılmasını sağlar.
                </span>
              </div>
            </div>
          )}

          {/* STEP 5: KONUM */}
          {currentStep === 5 && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">İl</label>
                  <input
                    type="text"
                    disabled
                    value="Manisa"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-slate-100 border border-slate-200 text-slate-600 text-sm cursor-not-allowed"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">İlçe</label>
                  <input
                    type="text"
                    disabled
                    value="Turgutlu"
                    className="w-full px-3.5 py-2.5 rounded-lg bg-slate-100 border border-slate-200 text-slate-600 text-sm cursor-not-allowed"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Turgutlu Mahallesi <span className="text-rose-500">*</span>
                </label>
                <select
                  value={neighborhood}
                  onChange={(e) => setNeighborhood(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 text-sm font-medium bg-white"
                >
                  {TURGUTLU_NEIGHBORHOODS.map((nh) => (
                    <option key={nh} value={nh}>
                      {nh} Mahallesi
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Cadde / Sokak / Mevkii (İsteğe Bağlı)
                </label>
                <input
                  type="text"
                  placeholder="Örn: Atatürk Bulvarı veya Gazi Osman Paşa Cad."
                  value={street}
                  onChange={(e) => setStreet(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/20 text-sm"
                />
              </div>
            </div>
          )}

          {/* STEP 6: FOTOĞRAF YÜKLEME */}
          {currentStep === 6 && (
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2">
                  İlan Fotoğrafları ({images.length} adet seçildi)
                </label>

                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  multiple
                  accept="image/jpeg,image/png,image/webp"
                  className="hidden"
                />

                {/* Upload drag-and-drop placeholder */}
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-slate-300 hover:border-emerald-600 rounded-xl p-6 text-center hover:bg-slate-50 transition-colors cursor-pointer flex flex-col items-center"
                >
                  <Upload className="w-8 h-8 text-emerald-600 mb-2" />
                  <p className="text-sm font-semibold text-slate-800">
                    {isUploadingPhoto ? 'Fotoğraflar işleniyor ve yükleniyor...' : 'Fotoğraf seçmek için tıklayın'}
                  </p>
                  <p className="text-xs text-slate-400 mt-1">
                    PNG, JPG veya WEBP (Otomatik WebP optimizasyonu, Max 5MB)
                  </p>
                </div>

                {uploadError && (
                  <p className="text-xs text-rose-600 font-semibold mt-1.5">{uploadError}</p>
                )}
              </div>

              {/* Uploaded images gallery list */}
              {images.length > 0 && (
                <div className="space-y-2">
                  <span className="text-xs font-semibold text-slate-600">Yüklü Fotoğraflar:</span>
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                    {images.map((img, i) => (
                      <div
                        key={i}
                        className="relative aspect-4/3 rounded-lg overflow-hidden border border-slate-200 group"
                      >
                        <img src={img} alt="" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => removeImage(i)}
                          className="absolute top-1 right-1 p-1 bg-black/60 hover:bg-rose-600 text-white rounded-full transition-colors"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                        {i === 0 && (
                          <span className="absolute bottom-1 left-1 bg-emerald-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded">
                            Kapak
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Sample Preset Photos for testing */}
              <div className="pt-2 border-t border-slate-100">
                <span className="text-xs font-semibold text-slate-600 block mb-2">
                  Veya Demo Hazır Fotoğraflardan Seçin (Tıkla ve Ekle):
                </span>
                <div className="grid grid-cols-4 gap-2">
                  {PRESET_SAMPLE_PHOTOS.map((sample, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => addPresetImage(sample.url)}
                      className="group relative aspect-4/3 rounded-lg overflow-hidden border border-slate-200 hover:border-emerald-600 transition-all text-left"
                    >
                      <img src={sample.url} alt={sample.title} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 flex items-end p-1 transition-colors">
                        <span className="text-[10px] text-white font-medium truncate">{sample.title}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* STEP 7: İLAN ÖZELLİKLERİ */}
          {currentStep === 7 && (
            <div className="space-y-4">
              <p className="text-sm text-slate-600">
                {categoryId === 'emlak'
                  ? 'Gayrimenkul teknik detaylarını giriniz:'
                  : 'Ürün veya vasıta teknik özelliklerini giriniz:'}
              </p>

              {categoryId === 'emlak' ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">m² (Brüt)</label>
                    <input
                      type="number"
                      value={specs.m2Gross || ''}
                      onChange={(e) => setSpecs({ ...specs, m2Gross: Number(e.target.value) })}
                      className="w-full p-2 border border-slate-300 rounded-lg text-sm"
                    />
                  </div>
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Oda Sayısı</label>
                    <select
                      value={specs.roomCount || '3+1'}
                      onChange={(e) => setSpecs({ ...specs, roomCount: e.target.value })}
                      className="w-full p-2 border border-slate-300 rounded-lg text-sm bg-white"
                    >
                      <option value="1+1">1+1</option>
                      <option value="2+1">2+1</option>
                      <option value="3+1">3+1</option>
                      <option value="4+1">4+1</option>
                      <option value="Müstakil / Dubleks">Müstakil / Dubleks</option>
                    </select>
                  </div>
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Bina Yaşı</label>
                    <select
                      value={specs.buildingAge || '0 (Yeni)'}
                      onChange={(e) => setSpecs({ ...specs, buildingAge: e.target.value })}
                      className="w-full p-2 border border-slate-300 rounded-lg text-sm bg-white"
                    >
                      <option value="0 (Yeni)">0 (Yeni)</option>
                      <option value="1-5">1-5 Yaşında</option>
                      <option value="5-10">5-10 Yaşında</option>
                      <option value="10+">10+ Yaşında</option>
                    </select>
                  </div>
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Isıtma</label>
                    <select
                      value={specs.heating || 'Doğalgaz (Kombi)'}
                      onChange={(e) => setSpecs({ ...specs, heating: e.target.value })}
                      className="w-full p-2 border border-slate-300 rounded-lg text-sm bg-white"
                    >
                      <option value="Doğalgaz (Kombi)">Doğalgaz (Kombi)</option>
                      <option value="Yerden Isıtma">Yerden Isıtma</option>
                      <option value="Klima">Klima</option>
                      <option value="Soba">Soba</option>
                    </select>
                  </div>
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Tapu Durumu</label>
                    <select
                      value={specs.deedStatus || 'Kat Mülkiyeti'}
                      onChange={(e) => setSpecs({ ...specs, deedStatus: e.target.value })}
                      className="w-full p-2 border border-slate-300 rounded-lg text-sm bg-white"
                    >
                      <option value="Kat Mülkiyeti">Kat Mülkiyeti</option>
                      <option value="Kat İrtifakı">Kat İrtifakı</option>
                      <option value="Müstakil Parsel">Müstakil Parsel</option>
                      <option value="Hisseli Tapu">Hisseli Tapu</option>
                    </select>
                  </div>
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Krediye Uygunluk</label>
                    <select
                      value={specs.creditEligible ? 'evet' : 'hayir'}
                      onChange={(e) => setSpecs({ ...specs, creditEligible: e.target.value === 'evet' })}
                      className="w-full p-2 border border-slate-300 rounded-lg text-sm bg-white"
                    >
                      <option value="evet">Evet (Krediye Uygun)</option>
                      <option value="hayir">Hayır</option>
                    </select>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Marka</label>
                    <input
                      type="text"
                      placeholder="Örn: New Holland / Toyota"
                      value={specs.brand || ''}
                      onChange={(e) => setSpecs({ ...specs, brand: e.target.value })}
                      className="w-full p-2 border border-slate-300 rounded-lg text-sm"
                    />
                  </div>
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Model / Tip</label>
                    <input
                      type="text"
                      placeholder="Örn: T580B / Corolla"
                      value={specs.model || ''}
                      onChange={(e) => setSpecs({ ...specs, model: e.target.value })}
                      className="w-full p-2 border border-slate-300 rounded-lg text-sm"
                    />
                  </div>
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">Yıl</label>
                    <input
                      type="number"
                      placeholder="2023"
                      value={specs.year || ''}
                      onChange={(e) => setSpecs({ ...specs, year: Number(e.target.value) })}
                      className="w-full p-2 border border-slate-300 rounded-lg text-sm"
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* STEP 8: İLAN ÖNİZLEME */}
          {currentStep === 8 && (
            <div className="space-y-4">
              <p className="text-sm text-slate-600">
                Yayınlamadan önce ilanınızın alıcılara nasıl görüneceğini inceleyin:
              </p>
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
                <div className="flex gap-4">
                  <div className="w-32 h-24 rounded-lg overflow-hidden shrink-0 bg-slate-200">
                    <img
                      src={images[0] || PRESET_SAMPLE_PHOTOS[0].url}
                      alt="Önizleme"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <div className="text-xs text-emerald-700 font-semibold uppercase">
                      {subcategory} · {neighborhood} Mahallesi, Turgutlu
                    </div>
                    <h3 className="font-bold text-slate-900 text-base leading-tight mt-0.5">
                      {title || 'Başlık Belirtilmedi'}
                    </h3>
                    <div className="text-lg font-extrabold text-slate-900 mt-1 tabular-nums">
                      {price ? `${price} TL` : 'Fiyat Belirtilmedi'}
                    </div>
                  </div>
                </div>

                <div className="text-xs text-slate-600 line-clamp-3 bg-white p-3 rounded-lg border border-slate-200">
                  {description || 'Açıklama girilmedi.'}
                </div>
              </div>
            </div>
          )}

          {/* STEP 9: YAYINLAMA & ÖNE ÇIKAR */}
          {currentStep === 9 && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/50 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-emerald-900 text-sm">İlanınız Yayınlanmaya Hazır!</h4>
                  <p className="text-xs text-emerald-700 mt-0.5">
                    İlanınız TurgutluPazar'da anında yayına alınacaktır.
                  </p>
                </div>
              </div>

              {/* Doping / Premium Option */}
              <div
                onClick={() => setAddDoping(!addDoping)}
                className={`p-4 rounded-xl border-2 cursor-pointer transition-all flex items-center justify-between ${
                  addDoping
                    ? 'border-amber-500 bg-amber-50/40 ring-2 ring-amber-500/20'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-amber-500 text-white mt-0.5">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 text-sm">
                        Ana Sayfa Vitrin Paketi (30 Gün)
                      </span>
                      <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded">
                        5 Kat Hızlı Satış
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      İlanınız Turgutlu vitrininde en üstte sabitlenir ve sarı rozet alır.
                    </p>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-base font-bold text-slate-900 tabular-nums">299 TL</div>
                  <div
                    className={`text-xs font-semibold mt-1 ${
                      addDoping ? 'text-amber-700' : 'text-slate-400'
                    }`}
                  >
                    {addDoping ? '✓ Seçildi' : '+ Ekle'}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Wizard Footer Controls */}
        <div className="px-6 py-4 border-t border-slate-100 flex items-center justify-between bg-slate-50/60 shrink-0">
          <button
            type="button"
            onClick={handlePrev}
            disabled={currentStep === 1 || isSubmitting}
            className={`px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
              currentStep === 1
                ? 'opacity-40 cursor-not-allowed text-slate-400'
                : 'text-slate-700 hover:bg-slate-200/70'
            }`}
          >
            <ArrowLeft className="w-4 h-4" /> Geri
          </button>

          {currentStep < totalSteps ? (
            <button
              type="button"
              onClick={handleNext}
              className="px-5 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
            >
              Devam Et <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={handlePublish}
              disabled={isSubmitting}
              className="px-6 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold flex items-center gap-2 transition-all shadow-sm active:scale-98"
            >
              {isSubmitting ? (
                <span>Yayınlanıyor...</span>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>{addDoping ? 'Ödeme Yap & İlanı Yayınla (299 TL)' : 'Ücretsiz İlanı Yayınla'}</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
