import React, { useState } from 'react';
import { StorageService } from '../services/storage';
import { Listing, User } from '../types';
import {
  Building2,
  Phone,
  MapPin,
  Clock,
  BadgeCheck,
  Globe,
  Share2,
  Eye,
  Send,
  MessageSquare,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { ListingCard } from './ListingCard';

interface RealtorPortalProps {
  onNavigateToListing: (listing: Listing) => void;
  onOpenOfferModal: (listing: Listing) => void;
  onOpenMessageModal: (listing: Listing) => void;
}

export const RealtorPortal: React.FC<RealtorPortalProps> = ({
  onNavigateToListing,
  onOpenOfferModal,
  onOpenMessageModal
}) => {
  const users = StorageService.getUsers();
  const realtors = users.filter((u) => u.role === 'realtor');
  const [selectedRealtorId, setSelectedRealtorId] = useState<string>(realtors[0]?.id || 'user-gediz-emlak');

  const activeRealtor = realtors.find((r) => r.id === selectedRealtorId) || realtors[0];
  const allListings = StorageService.getListings();
  const realtorListings = allListings.filter((l) => l.sellerId === activeRealtor?.id);
  const favorites = StorageService.getFavorites();

  const [version, setVersion] = useState(0);
  const handleToggleFavorite = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    StorageService.toggleFavorite(id);
    setVersion((v) => v + 1);
  };

  if (!activeRealtor) {
    return <div className="p-8 text-center text-slate-500">Kayıtlı emlak ofisi bulunamadı.</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-150">
      {/* Realtor Office Showcase Banner */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden">
        <div className="h-32 sm:h-44 bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 relative">
          <div className="absolute top-4 right-4 bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs px-3 py-1 rounded-full font-bold flex items-center gap-1.5 backdrop-blur-xs">
            <BadgeCheck className="w-4 h-4 text-emerald-400" /> T.C. Taşınmaz Ticareti Yetki Belgeli
          </div>
        </div>

        <div className="px-6 pb-6 pt-0 relative flex flex-col md:flex-row md:items-end justify-between gap-6 -mt-16 sm:-mt-20">
          <div className="flex flex-col sm:flex-row items-start sm:items-end gap-4">
            <img
              src={activeRealtor.avatarUrl}
              alt={activeRealtor.companyName || activeRealtor.name}
              className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl border-4 border-white shadow-md object-cover bg-white shrink-0"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
                  {activeRealtor.companyName || activeRealtor.name}
                </h1>
                <BadgeCheck className="w-5 h-5 text-emerald-600 shrink-0" />
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Yetki Belgesi No: <strong className="text-slate-700">{activeRealtor.authorizedDocNo || 'YB-4500128'}</strong> · Manisa Ticaret İl Müdürlüğü Onaylı
              </p>
              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600 mt-2 font-medium">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                  {activeRealtor.address || 'Atatürk Bulvarı No: 142/A, Turgutlu / Manisa'}
                </span>
                <span>·</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-slate-400" /> Hafta İçi: 09:00 - 19:00
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={`tel:${activeRealtor.phone}`}
              className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-colors shadow-xs"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-400" />
              <span>{activeRealtor.phone}</span>
            </a>
            <a
              href={`https://wa.me/90${activeRealtor.phone.replace(/[^0-9]/g, '').slice(1)}`}
              target="_blank"
              rel="noreferrer"
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-colors shadow-xs"
            >
              <span>WhatsApp</span>
            </a>
          </div>
        </div>

        {/* Office Performance Ribbon */}
        <div className="grid grid-cols-2 sm:grid-cols-4 border-t border-slate-100 bg-slate-50/70 p-4 text-xs">
          <div className="text-center p-2">
            <span className="text-slate-400 block text-[11px]">Aktif Portföy</span>
            <span className="text-lg font-bold text-slate-900 tabular-nums">{realtorListings.length} İlan</span>
          </div>
          <div className="text-center p-2 border-l border-slate-200">
            <span className="text-slate-400 block text-[11px]">Toplam Görüntülenme</span>
            <span className="text-lg font-bold text-slate-900 tabular-nums">1.450+</span>
          </div>
          <div className="text-center p-2 border-l border-slate-200">
            <span className="text-slate-400 block text-[11px]">Müşteri Memnuniyeti</span>
            <span className="text-lg font-bold text-amber-600 tabular-nums">★ 5.0 / 5.0</span>
          </div>
          <div className="text-center p-2 border-l border-slate-200">
            <span className="text-slate-400 block text-[11px]">Bölge Uzmanlığı</span>
            <span className="text-lg font-bold text-emerald-700">Turgutlu & Gediz Ovası</span>
          </div>
        </div>
      </div>

      {/* Office Listings Portfolio */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              {activeRealtor.companyName || activeRealtor.name} Gayrimenkul Portföyü
            </h2>
            <p className="text-xs text-slate-500">Turgutlu merkez ve çevre mahallelerdeki güncel gayrimenkuller</p>
          </div>
          <span className="text-xs font-semibold text-slate-600">{realtorListings.length} ilan listeleniyor</span>
        </div>

        {realtorListings.length === 0 ? (
          <div className="bg-white p-8 rounded-xl border border-slate-200 text-center text-slate-500 text-sm">
            Bu ofise ait aktif ilan bulunmamaktadır.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {realtorListings.map((listing) => (
              <ListingCard
                key={listing.id}
                listing={listing}
                isFavorite={favorites.includes(listing.id)}
                onToggleFavorite={handleToggleFavorite}
                onClick={onNavigateToListing}
              />
            ))}
          </div>
        )}
      </div>

      {/* Trust & Legal Compliance Note */}
      <div className="p-4 bg-emerald-50/60 border border-emerald-200/80 rounded-xl text-xs text-emerald-900 flex items-start gap-3">
        <BadgeCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
        <div>
          <h4 className="font-bold">Turgutlu Emlak Danışmanları Güvencesi</h4>
          <p className="mt-0.5 text-emerald-800 leading-relaxed">
            TurgutluPazar'da yer alan kurumsal emlak ofisleri, Ticaret Bakanlığı Taşınmaz Ticareti Hakkında Yönetmelik kapsamında yetkilendirilmiş resmi gayrimenkul işletmeleridir. Sahte ve yanıltıcı ilanlara karşı düzenli denetim yapılmaktadır.
          </p>
        </div>
      </div>
    </div>
  );
};
