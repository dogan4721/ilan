import React, { useState } from 'react';
import { Listing } from '../types';
import { StorageService } from '../services/storage';
import { X, Flag, CheckCircle2 } from 'lucide-react';

interface ReportModalProps {
  listing: Listing | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ReportModal: React.FC<ReportModalProps> = ({
  listing,
  isOpen,
  onClose
}) => {
  const [reason, setReason] = useState('Yanıltıcı / Gerçek Dışı Fiyat');
  const [details, setDetails] = useState('');
  const [isSent, setIsSent] = useState(false);

  if (!isOpen || !listing) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    StorageService.submitComplaint({
      listingId: listing.id,
      listingTitle: listing.title,
      reason,
      details: details || 'Kullanıcı ihbarı bildirildi.'
    });

    setIsSent(true);
    setTimeout(() => {
      setIsSent(false);
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden my-auto">
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2 text-rose-600">
            <Flag className="w-4 h-4" />
            <h3 className="font-bold text-slate-900 text-sm">İlanı Şikayet Et</h3>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-700 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSent ? (
          <div className="p-8 text-center space-y-2">
            <CheckCircle2 className="w-14 h-14 text-emerald-600 mx-auto" />
            <h4 className="font-bold text-slate-900 text-base">Şikayetiniz Alındı</h4>
            <p className="text-xs text-slate-500">
              Yöneticilerimiz ilan detayını inceleyip gerekli tedbirleri alacaktır.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
            <div>
              <span className="text-slate-500 block mb-1">Şikayet Edilen İlan:</span>
              <strong className="text-slate-900 text-sm line-clamp-1">{listing.title}</strong>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Şikayet Sebebi</label>
              <select
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full p-2.5 border border-slate-300 rounded-xl bg-white font-medium text-xs"
              >
                <option value="Yanıltıcı / Gerçek Dışı Fiyat">Yanıltıcı / Gerçek Dışı Fiyat</option>
                <option value="Satılmış / Kiralanmış İlan">Satılmış / Kiralanmış İlan</option>
                <option value="Yanlış Konum / Mahalle">Yanlış Konum / Mahalle</option>
                <option value="Ulaşılamayan Telefon / Satıcı">Ulaşılamayan Telefon / Satıcı</option>
                <option value="Telif veya Sahte Fotoğraf">Telif veya Sahte Fotoğraf</option>
                <option value="Uygunsuz İçerik / Hakaret">Uygunsuz İçerik / Hakaret</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Açıklama</label>
              <textarea
                rows={3}
                placeholder="Lütfen durumu kısaca açıklayınız..."
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                className="w-full p-2.5 border border-slate-300 rounded-xl text-xs"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-xs transition-colors"
            >
              Şikayeti Yetkiliye İlet
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
