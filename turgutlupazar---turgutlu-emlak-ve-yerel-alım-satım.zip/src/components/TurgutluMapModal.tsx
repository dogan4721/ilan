import React, { useState } from 'react';
import { Listing } from '../types';
import { X, MapPin, Building2, Eye, Heart, ArrowRight } from 'lucide-react';

interface TurgutluMapModalProps {
  isOpen: boolean;
  onClose: () => void;
  listings: Listing[];
  onSelectListing: (listing: Listing) => void;
}

// Neighborhood coordinates mapped to a responsive SVG coordinate space
const NEIGHBORHOOD_PIN_MAP: Record<string, { x: number; y: number }> = {
  'İstasyonaltı': { x: 42, y: 52 },
  'Subaşı': { x: 34, y: 44 },
  'Ergenekon': { x: 68, y: 36 },
  'Selvilitepe': { x: 50, y: 64 },
  'Atatürk': { x: 48, y: 46 },
  'Cumhuriyet': { x: 54, y: 48 },
  'Yılmazlar': { x: 45, y: 40 },
  'Turan': { x: 52, y: 56 },
  'Urganlı': { x: 82, y: 60 },
  'Yeni Mahalle': { x: 38, y: 58 },
  'Şehitler': { x: 58, y: 42 }
};

export const TurgutluMapModal: React.FC<TurgutluMapModalProps> = ({
  isOpen,
  onClose,
  listings,
  onSelectListing
}) => {
  const [selectedListing, setSelectedListing] = useState<Listing | null>(listings[0] || null);
  const [selectedNeighborhood, setSelectedNeighborhood] = useState<string>('all');

  if (!isOpen) return null;

  const filteredListings =
    selectedNeighborhood === 'all'
      ? listings
      : listings.filter((l) => l.neighborhood === selectedNeighborhood);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-150">
      <div className="relative w-full max-w-5xl bg-white rounded-2xl shadow-2xl overflow-hidden my-auto flex flex-col h-[85vh]">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between bg-white z-10 shrink-0">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-emerald-600 text-white">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-slate-900">
                Turgutlu İnteraktif İlan Haritası
              </h2>
              <p className="text-[11px] text-slate-500">
                Manisa / Turgutlu mahallelerine göre konumlandırılmış güncel ilanlar
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Filter by neighborhood */}
            <select
              value={selectedNeighborhood}
              onChange={(e) => setSelectedNeighborhood(e.target.value)}
              className="px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs bg-white font-medium text-slate-700 hidden sm:block"
            >
              <option value="all">Tüm Turgutlu Mahalleleri</option>
              {Object.keys(NEIGHBORHOOD_PIN_MAP).map((nh) => (
                <option key={nh} value={nh}>
                  {nh} Mahallesi
                </option>
              ))}
            </select>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Map Canvas and Card Sidebar */}
        <div className="flex-1 relative flex flex-col md:flex-row overflow-hidden bg-slate-100">
          {/* Stylized Vector Map of Turgutlu */}
          <div className="flex-1 relative overflow-hidden bg-[#e8ecf1] flex items-center justify-center select-none">
            {/* Grid Pattern */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#cbd5e1_1px,transparent_1px),linear-gradient(to_bottom,#cbd5e1_1px,transparent_1px)] bg-[size:40px_40px] opacity-40" />

            {/* Gediz Valley & Mountain Contour Vector */}
            <svg
              className="absolute inset-0 w-full h-full pointer-events-none opacity-20"
              viewBox="0 0 1000 600"
              preserveAspectRatio="none"
            >
              <path
                d="M 0,200 Q 250,180 500,240 T 1000,190 L 1000,600 L 0,600 Z"
                fill="#10b981"
              />
              <path
                d="M 0,100 Q 300,50 600,120 T 1000,80 L 1000,300 L 0,300 Z"
                fill="#059669"
              />
            </svg>

            {/* Turgutlu Road Arteries (E96 İzmir - Ankara Karayolu) */}
            <div className="absolute top-1/2 left-0 right-0 h-3 bg-amber-400/80 -translate-y-1/2 shadow-xs rotate-[-3deg] flex items-center justify-end pr-8">
              <span className="text-[10px] font-bold text-amber-950 uppercase tracking-widest bg-amber-200/90 px-2 py-0.5 rounded">
                D300 / E96 İzmir - Ankara Karayolu
              </span>
            </div>

            {/* Secondary Avenue (Atatürk Bulvarı) */}
            <div className="absolute top-0 bottom-0 left-[48%] w-2.5 bg-slate-300 shadow-xs rotate-[10deg] flex items-end pb-8">
              <span className="text-[9px] font-bold text-slate-700 bg-white/90 px-1 py-0.5 rounded rotate-[-90deg]">
                Atatürk Bulvarı
              </span>
            </div>

            {/* Neighborhood Labels on Map */}
            {Object.entries(NEIGHBORHOOD_PIN_MAP).map(([name, pos]) => (
              <div
                key={name}
                className="absolute text-slate-500 font-bold text-[11px] pointer-events-none drop-shadow-xs"
                style={{ left: `${pos.x}%`, top: `${pos.y + 4}%` }}
              >
                {name}
              </div>
            ))}

            {/* Listing Pins */}
            {filteredListings.map((listing) => {
              const pos = NEIGHBORHOOD_PIN_MAP[listing.neighborhood] || { x: 50, y: 50 };
              const isSelected = selectedListing?.id === listing.id;

              return (
                <button
                  key={listing.id}
                  onClick={() => setSelectedListing(listing)}
                  style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
                  className={`absolute -translate-x-1/2 -translate-y-full z-20 group transition-all duration-200 ${
                    isSelected ? 'scale-125 z-30' : 'hover:scale-110'
                  }`}
                >
                  <div
                    className={`px-2 py-1 rounded-full text-[11px] font-bold shadow-md flex items-center gap-1 border ${
                      isSelected
                        ? 'bg-slate-900 text-white border-emerald-400 ring-4 ring-emerald-500/30'
                        : 'bg-white text-slate-900 border-slate-300 hover:border-emerald-600'
                    }`}
                  >
                    <span className="tabular-nums">
                      {(listing.price / 1000).toFixed(0)}k TL
                    </span>
                  </div>
                  {/* Pin tail */}
                  <div
                    className={`w-2 h-2 mx-auto rotate-45 -mt-1 ${
                      isSelected ? 'bg-slate-900' : 'bg-white'
                    }`}
                  />
                </button>
              );
            })}
          </div>

          {/* Right / Bottom Card Drawer for Selected Listing */}
          {selectedListing && (
            <div className="w-full md:w-80 bg-white border-t md:border-t-0 md:border-l border-slate-200 p-4 flex flex-col justify-between shrink-0 shadow-lg z-30">
              <div className="space-y-3">
                <div className="aspect-16/10 rounded-xl overflow-hidden bg-slate-100 relative">
                  <img
                    src={selectedListing.images[0]}
                    alt={selectedListing.title}
                    className="w-full h-full object-cover"
                  />
                  <span className="absolute top-2 left-2 bg-emerald-600 text-white text-[10px] font-bold px-2 py-0.5 rounded">
                    {selectedListing.neighborhood} Mah.
                  </span>
                </div>

                <div>
                  <h3 className="font-bold text-slate-900 text-sm line-clamp-2 leading-snug">
                    {selectedListing.title}
                  </h3>
                  <div className="mt-1 text-base font-extrabold text-slate-900 tabular-nums">
                    {selectedListing.price.toLocaleString('tr-TR')} <span className="text-xs text-emerald-700">TL</span>
                  </div>
                  <div className="text-xs text-slate-500 mt-1">
                    {selectedListing.specs.roomCount || selectedListing.subcategory} · {selectedListing.sellerName}
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center gap-2">
                <button
                  onClick={() => {
                    onSelectListing(selectedListing);
                    onClose();
                  }}
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                >
                  <span>İlan Detayını Aç</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
