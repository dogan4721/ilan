import React, { useState } from 'react';
import { User, Listing, Offer, Conversation } from '../types';
import { StorageService } from '../services/storage';
import {
  Building2,
  Package,
  Heart,
  MessageSquare,
  BadgeCheck,
  Send,
  CreditCard,
  Settings,
  Shield,
  Trash2,
  Edit3,
  Eye,
  Sparkles,
  TrendingUp,
  Clock,
  CheckCircle,
  XCircle,
  Phone,
  Mail,
  Lock,
  ExternalLink,
  ChevronRight
} from 'lucide-react';

interface UserDashboardProps {
  currentUser: User;
  onNavigateToListing: (listing: Listing) => void;
  onOpenPaymentModal: (pkgName: string, amount: number) => void;
  onOpenPostListing: () => void;
  initialTab?: string;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({
  currentUser,
  onNavigateToListing,
  onOpenPaymentModal,
  onOpenPostListing,
  initialTab = 'ilanlarim'
}) => {
  const [activeTab, setActiveTab] = useState<string>(initialTab);
  const [editingListing, setEditingListing] = useState<Listing | null>(null);
  const [editPrice, setEditPrice] = useState('');
  const [editTitle, setEditTitle] = useState('');

  // Counter offer state
  const [counterOfferId, setCounterOfferId] = useState<string | null>(null);
  const [counterPrice, setCounterPrice] = useState('');

  // Chat conversation state
  const [selectedConvId, setSelectedConvId] = useState<string | null>(null);
  const [chatInput, setChatInput] = useState('');

  // Refresh trigger
  const [version, setVersion] = useState(0);
  const reload = () => setVersion((v) => v + 1);

  const listings = StorageService.getListings().filter(
    (l) => l.sellerId === currentUser.id || currentUser.role === 'admin'
  );
  const allFavorites = StorageService.getFavorites();
  const favoriteListings = StorageService.getListings().filter((l) =>
    allFavorites.includes(l.id)
  );
  const offers = StorageService.getOffers().filter(
    (o) => o.sellerId === currentUser.id || o.buyerId === currentUser.id
  );
  const conversations = StorageService.getConversations().filter(
    (c) => c.buyerId === currentUser.id || c.sellerId === currentUser.id
  );
  const payments = StorageService.getPayments().filter(
    (p) => p.userId === currentUser.id
  );

  // Statistics
  const totalListings = listings.length;
  const activeListings = listings.filter((l) => l.status === 'active').length;
  const totalViews = listings.reduce((acc, curr) => acc + (curr.viewCount || 0), 0);
  const totalFavs = listings.reduce((acc, curr) => acc + (curr.favoriteCount || 0), 0);

  // Handlers for Listings
  const handleToggleStatus = (id: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'active' ? 'passive' : 'active';
    StorageService.updateListing(id, { status: nextStatus as any });
    reload();
  };

  const handleDeleteListing = (id: string) => {
    if (window.confirm('Bu ilanı silmek istediğinize emin misiniz?')) {
      StorageService.deleteListing(id);
      reload();
    }
  };

  const handleSaveListingEdit = () => {
    if (!editingListing) return;
    StorageService.updateListing(editingListing.id, {
      title: editTitle || editingListing.title,
      price: parseFloat(editPrice.replace(/[^0-9]/g, '')) || editingListing.price
    });
    setEditingListing(null);
    reload();
  };

  // Handlers for Offers
  const handleAcceptOffer = (offerId: string) => {
    StorageService.respondToOffer(offerId, 'accept');
    reload();
  };

  const handleRejectOffer = (offerId: string) => {
    StorageService.respondToOffer(offerId, 'reject');
    reload();
  };

  const handleSendCounterOffer = (offerId: string) => {
    const priceNum = parseFloat(counterPrice.replace(/[^0-9]/g, ''));
    if (priceNum > 0) {
      StorageService.respondToOffer(offerId, 'counter', priceNum);
      setCounterOfferId(null);
      setCounterPrice('');
      reload();
    }
  };

  // Handlers for Chat
  const selectedConv = conversations.find((c) => c.id === selectedConvId) || conversations[0];

  const handleSendChatMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !selectedConv) return;
    StorageService.sendMessage({
      listingId: selectedConv.listingId,
      text: chatInput
    });
    setChatInput('');
    reload();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-in fade-in duration-150">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white p-6 sm:p-8 rounded-2xl shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight">
              Hoş geldin, {currentUser.name}
            </h1>
            {currentUser.verifiedIdentity && (
              <span title="Doğrulanmış Hesap" className="inline-flex">
                <BadgeCheck className="w-5 h-5 text-emerald-400" />
              </span>
            )}
          </div>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            {currentUser.role === 'realtor'
              ? 'Turgutlu Kurumsal Emlakçı Paneli · Yetki Belgesi: ' + (currentUser.authorizedDocNo || '4500128')
              : 'Turgutlu Bireysel Alım-Satım & İlan Yönetimi'}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenPostListing}
            className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs sm:text-sm transition-all shadow-md active:scale-98 flex items-center gap-2"
          >
            <span>+ Yeni İlan Ver</span>
          </button>
        </div>
      </div>

      {/* 4 Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 sm:p-5 rounded-xl border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Toplam İlan</span>
            <Package className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2 tabular-nums">
            {totalListings}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Portföyünüzdeki tüm ilanlar</div>
        </div>

        <div className="bg-white p-4 sm:p-5 rounded-xl border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Yayındaki İlanlar</span>
            <CheckCircle className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-emerald-700 mt-2 tabular-nums">
            {activeListings}
          </div>
          <div className="text-[11px] text-emerald-600/80 mt-1">Alıcılara açık ve aktif</div>
        </div>

        <div className="bg-white p-4 sm:p-5 rounded-xl border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Toplam Görüntülenme</span>
            <Eye className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2 tabular-nums">
            {totalViews}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <TrendingUp className="w-3 h-3 text-emerald-600" /> Son 7 günde +%18 artış
          </div>
        </div>

        <div className="bg-white p-4 sm:p-5 rounded-xl border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 text-xs font-medium">
            <span>Favoriye Eklenme</span>
            <Heart className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2 tabular-nums">
            {totalFavs}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Takip eden potansiyel alıcı</div>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-px">
        {[
          { id: 'ilanlarim', label: 'İlanlarım', icon: Package, badge: totalListings },
          { id: 'tekliflerim', label: 'Tekliflerim', icon: Send, badge: offers.length },
          { id: 'mesajlarim', label: 'Mesajlarım', icon: MessageSquare, badge: conversations.length },
          { id: 'favorilerim', label: 'Favorilerim', icon: Heart, badge: favoriteListings.length },
          { id: 'odeme', label: 'Ödeme & Doping', icon: CreditCard },
          { id: 'profil', label: 'Profil & Doğrulama', icon: Shield }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-3 text-xs sm:text-sm font-semibold flex items-center gap-2 border-b-2 whitespace-nowrap transition-colors ${
                isActive
                  ? 'border-emerald-600 text-emerald-700 bg-emerald-50/20'
                  : 'border-transparent text-slate-600 hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
              {tab.badge !== undefined && (
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold tabular-nums ${
                    isActive ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB CONTENT 1: İLANLARIM */}
      {activeTab === 'ilanlarim' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">İlan Yönetimi</h3>
            <button
              onClick={onOpenPostListing}
              className="text-xs font-semibold text-emerald-700 hover:underline"
            >
              + Yeni İlan Ekle
            </button>
          </div>

          {listings.length === 0 ? (
            <div className="bg-white p-8 rounded-xl border border-slate-200 text-center">
              <Package className="w-12 h-12 text-slate-300 mx-auto mb-2" />
              <p className="text-slate-600 text-sm">Henüz bir ilan eklemediniz.</p>
              <button
                onClick={onOpenPostListing}
                className="mt-3 px-4 py-2 bg-emerald-600 text-white rounded-lg text-xs font-semibold"
              >
                Hemen İlan Ver
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {listings.map((item) => (
                <div
                  key={item.id}
                  className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:border-slate-300 transition-all shadow-2xs"
                >
                  <div
                    onClick={() => onNavigateToListing(item)}
                    className="flex items-center gap-3.5 cursor-pointer flex-1 min-w-0"
                  >
                    <div className="w-20 h-16 rounded-lg bg-slate-100 overflow-hidden shrink-0 border border-slate-200">
                      <img
                        src={item.images[0]}
                        alt={item.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            item.status === 'active'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {item.status === 'active' ? 'Yayında' : 'Pasif'}
                        </span>
                        {item.isFeatured && (
                          <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded">
                            Vitrin
                          </span>
                        )}
                        <span className="text-xs text-slate-400">#{item.id}</span>
                      </div>
                      <h4 className="font-semibold text-slate-900 text-sm truncate mt-0.5 hover:text-emerald-700">
                        {item.title}
                      </h4>
                      <div className="text-xs text-slate-500 flex items-center gap-3 mt-1">
                        <span className="font-bold text-slate-900 tabular-nums">
                          {item.price.toLocaleString('tr-TR')} TL
                        </span>
                        <span>·</span>
                        <span className="flex items-center gap-1">
                          <Eye className="w-3 h-3" /> {item.viewCount}
                        </span>
                        <span>·</span>
                        <span className="flex items-center gap-1">
                          <Heart className="w-3 h-3 text-rose-500" /> {item.favoriteCount}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Actions for this listing */}
                  <div className="flex items-center gap-1.5 w-full sm:w-auto justify-end border-t sm:border-t-0 pt-2 sm:pt-0">
                    <button
                      onClick={() => {
                        setEditingListing(item);
                        setEditTitle(item.title);
                        setEditPrice(item.price.toString());
                      }}
                      className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg text-xs font-medium flex items-center gap-1"
                      title="Düzenle"
                    >
                      <Edit3 className="w-4 h-4" />
                      <span className="hidden md:inline">Düzenle</span>
                    </button>

                    <button
                      onClick={() => handleToggleStatus(item.id, item.status)}
                      className="px-2.5 py-1.5 border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-lg text-xs font-medium"
                    >
                      {item.status === 'active' ? 'Pasife Al' : 'Yayına Al'}
                    </button>

                    {!item.isFeatured && (
                      <button
                        onClick={() =>
                          onOpenPaymentModal('Ana Sayfa Vitrin Paketi (30 Gün)', 299)
                        }
                        className="px-2.5 py-1.5 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1 shadow-2xs"
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>Öne Çıkar</span>
                      </button>
                    )}

                    <button
                      onClick={() => handleDeleteListing(item.id)}
                      className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                      title="Sil"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Edit Listing Modal */}
          {editingListing && (
            <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl max-w-md w-full p-6 space-y-4 shadow-2xl">
                <h3 className="text-base font-bold text-slate-900">İlanı Düzenle</h3>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Başlık</label>
                  <input
                    type="text"
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    className="w-full p-2.5 border border-slate-300 rounded-lg text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">
                    Fiyat (TL)
                  </label>
                  <input
                    type="text"
                    value={editPrice}
                    onChange={(e) => setEditPrice(e.target.value)}
                    className="w-full p-2.5 border border-slate-300 rounded-lg text-sm font-bold tabular-nums"
                  />
                </div>
                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    onClick={() => setEditingListing(null)}
                    className="px-4 py-2 border rounded-lg text-xs font-medium text-slate-700"
                  >
                    Vazgeç
                  </button>
                  <button
                    onClick={handleSaveListingEdit}
                    className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-xs font-bold"
                  >
                    Değişiklikleri Kaydet
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT 2: TEKLİFLERİM */}
      {activeTab === 'tekliflerim' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">Alım-Satım Teklifleri</h3>
            <span className="text-xs text-slate-500">Güvenli Pazarlık ve Teklif Takibi</span>
          </div>

          {offers.length === 0 ? (
            <div className="bg-white p-8 rounded-xl border border-slate-200 text-center">
              <Send className="w-12 h-12 text-slate-300 mx-auto mb-2" />
              <p className="text-slate-600 text-sm">Henüz bir teklif geçmişiniz bulunmuyor.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {offers.map((offer) => {
                const isSeller = offer.sellerId === currentUser.id;
                return (
                  <div
                    key={offer.id}
                    className="bg-white p-4 rounded-xl border border-slate-200 space-y-3 shadow-2xs"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-2">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            offer.status === 'accepted'
                              ? 'bg-emerald-100 text-emerald-800'
                              : offer.status === 'rejected'
                              ? 'bg-rose-100 text-rose-800'
                              : offer.status === 'countered'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-blue-100 text-blue-800'
                          }`}
                        >
                          {offer.status === 'accepted' && 'Kabul Edildi'}
                          {offer.status === 'rejected' && 'Reddedildi'}
                          {offer.status === 'countered' && 'Karşı Teklif Sunuldu'}
                          {offer.status === 'pending' && 'Cevap Bekliyor'}
                        </span>
                        <span className="text-xs text-slate-400">Tarih: {offer.createdAt}</span>
                      </div>
                      <span className="text-xs text-slate-500 font-medium">
                        {isSeller ? `Alıcı: ${offer.buyerName}` : `Satıcı: ${offer.listingTitle}`}
                      </span>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="w-16 h-12 rounded-lg bg-slate-100 overflow-hidden shrink-0">
                        <img
                          src={offer.listingImage}
                          alt=""
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1">
                        <h4 className="text-sm font-semibold text-slate-900 leading-tight">
                          {offer.listingTitle}
                        </h4>
                        <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs">
                          <span className="text-slate-500">
                            İlan Fiyatı: <strong className="text-slate-800">{offer.listingPrice.toLocaleString('tr-TR')} TL</strong>
                          </span>
                          <span className="text-emerald-700 font-bold">
                            Verilen Teklif: {offer.offeredPrice.toLocaleString('tr-TR')} TL
                          </span>
                          {offer.counterPrice && (
                            <span className="text-amber-700 font-bold">
                              Karşı Teklif: {offer.counterPrice.toLocaleString('tr-TR')} TL
                            </span>
                          )}
                        </div>
                        {offer.message && (
                          <p className="mt-1 text-xs text-slate-600 bg-slate-50 p-2 rounded-lg border border-slate-100">
                            "{offer.message}"
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Actions if user is seller and offer is pending */}
                    {isSeller && offer.status === 'pending' && (
                      <div className="pt-2 border-t border-slate-100 flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleRejectOffer(offer.id)}
                          className="px-3 py-1.5 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-semibold"
                        >
                          Reddet
                        </button>
                        <button
                          onClick={() => {
                            setCounterOfferId(offer.id);
                            setCounterPrice(offer.offeredPrice.toString());
                          }}
                          className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-xs font-semibold"
                        >
                          Karşı Teklif Gönder
                        </button>
                        <button
                          onClick={() => handleAcceptOffer(offer.id)}
                          className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold"
                        >
                          Kabul Et
                        </button>
                      </div>
                    )}

                    {/* Counter offer inline input */}
                    {counterOfferId === offer.id && (
                      <div className="pt-3 border-t border-slate-100 flex items-center gap-2">
                        <input
                          type="text"
                          placeholder="Karşı teklif tutarı (TL)"
                          value={counterPrice}
                          onChange={(e) => setCounterPrice(e.target.value)}
                          className="p-2 border border-slate-300 rounded-lg text-xs flex-1 tabular-nums font-bold"
                        />
                        <button
                          onClick={() => handleSendCounterOffer(offer.id)}
                          className="px-3 py-2 bg-amber-600 text-white rounded-lg text-xs font-bold"
                        >
                          Teklifi Gönder
                        </button>
                        <button
                          onClick={() => setCounterOfferId(null)}
                          className="px-3 py-2 border rounded-lg text-xs"
                        >
                          İptal
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT 3: MESAJLARIM (WhatsApp-like) */}
      {activeTab === 'mesajlarim' && (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden grid grid-cols-1 md:grid-cols-12 min-h-[500px]">
          {/* Left: Conversation list (4 cols) */}
          <div className="md:col-span-4 border-r border-slate-200 flex flex-col">
            <div className="p-3.5 border-b border-slate-100 bg-slate-50 font-bold text-slate-800 text-sm">
              Sohbetler ({conversations.length})
            </div>
            <div className="overflow-y-auto flex-1 divide-y divide-slate-100">
              {conversations.map((conv) => {
                const isSelected = conv.id === (selectedConv?.id || '');
                const otherParty =
                  conv.buyerId === currentUser.id ? conv.sellerName : conv.buyerName;
                return (
                  <div
                    key={conv.id}
                    onClick={() => setSelectedConvId(conv.id)}
                    className={`p-3.5 cursor-pointer transition-colors flex items-start gap-3 ${
                      isSelected ? 'bg-emerald-50/60' : 'hover:bg-slate-50'
                    }`}
                  >
                    <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center font-bold text-slate-700 text-sm shrink-0">
                      {otherParty.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-900 text-xs truncate">
                          {otherParty}
                        </span>
                        <span className="text-[10px] text-slate-400">{conv.lastMessageTime}</span>
                      </div>
                      <div className="text-[11px] text-emerald-700 truncate font-medium">
                        {conv.listingTitle}
                      </div>
                      <p className="text-xs text-slate-500 truncate mt-0.5">{conv.lastMessage}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Message Window (8 cols) */}
          <div className="md:col-span-8 flex flex-col bg-slate-50/50">
            {selectedConv ? (
              <>
                {/* Chat Header */}
                <div className="p-3.5 bg-white border-b border-slate-200 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">
                      {(selectedConv.buyerId === currentUser.id
                        ? selectedConv.sellerName
                        : selectedConv.buyerName
                      ).charAt(0)}
                    </div>
                    <div>
                      <div className="font-bold text-slate-900 text-xs sm:text-sm">
                        {selectedConv.buyerId === currentUser.id
                          ? selectedConv.sellerName
                          : selectedConv.buyerName}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate">
                        İlan: {selectedConv.listingTitle} ({selectedConv.listingPrice.toLocaleString('tr-TR')} TL)
                      </div>
                    </div>
                  </div>
                </div>

                {/* Message Bubbles */}
                <div className="flex-1 p-4 overflow-y-auto space-y-3">
                  {selectedConv.messages.map((m) => {
                    const isMe = m.senderId === currentUser.id;
                    return (
                      <div
                        key={m.id}
                        className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                      >
                        <div
                          className={`max-w-[78%] px-3.5 py-2.5 rounded-2xl text-xs leading-relaxed shadow-2xs ${
                            isMe
                              ? 'bg-emerald-600 text-white rounded-tr-xs'
                              : 'bg-white border border-slate-200 text-slate-800 rounded-tl-xs'
                          }`}
                        >
                          {m.text}
                        </div>
                        <span className="text-[10px] text-slate-400 mt-1 px-1">
                          {m.timestamp}
                        </span>
                      </div>
                    );
                  })}
                </div>

                {/* Chat Input */}
                <form
                  onSubmit={handleSendChatMessage}
                  className="p-3 bg-white border-t border-slate-200 flex items-center gap-2"
                >
                  <input
                    type="text"
                    placeholder="Mesajınızı yazınız..."
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    className="flex-1 px-3.5 py-2 rounded-xl border border-slate-300 focus:border-emerald-600 text-xs"
                  />
                  <button
                    type="submit"
                    className="p-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl transition-colors shrink-0"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-slate-400 text-sm">
                Sohbet seçilmedi
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB CONTENT 4: FAVORİLERİM */}
      {activeTab === 'favorilerim' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">Takip Ettiğim İlanlar</h3>
            <span className="text-xs text-slate-500">Fiyat değişimleri anında bildirilir</span>
          </div>

          {favoriteListings.length === 0 ? (
            <div className="bg-white p-8 rounded-xl border border-slate-200 text-center">
              <Heart className="w-12 h-12 text-slate-300 mx-auto mb-2" />
              <p className="text-slate-600 text-sm">Henüz favori ilan eklemediniz.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {favoriteListings.map((fav) => (
                <div
                  key={fav.id}
                  className="bg-white rounded-xl border border-slate-200 p-3 space-y-2 hover:border-slate-300 transition-all flex flex-col justify-between"
                >
                  <div
                    onClick={() => onNavigateToListing(fav)}
                    className="cursor-pointer space-y-2"
                  >
                    <div className="aspect-16/10 rounded-lg overflow-hidden bg-slate-100">
                      <img src={fav.images[0]} alt="" className="w-full h-full object-cover" />
                    </div>
                    <h4 className="font-semibold text-slate-900 text-xs sm:text-sm line-clamp-1">
                      {fav.title}
                    </h4>
                    <div className="text-xs text-slate-500">
                      {fav.district}, {fav.neighborhood} Mahallesi
                    </div>
                    <div className="text-sm font-bold text-slate-900 tabular-nums">
                      {fav.price.toLocaleString('tr-TR')} TL
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-emerald-700 font-medium">Aktif İlan</span>
                    <button
                      onClick={() => {
                        StorageService.toggleFavorite(fav.id);
                        reload();
                      }}
                      className="text-slate-400 hover:text-rose-600 font-medium"
                    >
                      Favoriden Kaldır
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT 5: ÖDEME & DOPİNG İŞLEMLERİ */}
      {activeTab === 'odeme' && (
        <div className="space-y-6">
          <div className="bg-gradient-to-r from-emerald-900 to-slate-900 text-white p-6 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h3 className="text-lg font-bold">TurgutluPazar Vitrin & Doping Paketleri</h3>
              <p className="text-xs text-emerald-200 mt-1">
                İlanlarınızı Turgutlu'da binlerce alıcıya daha hızlı ulaştırın.
              </p>
            </div>
            <button
              onClick={() => onOpenPaymentModal('Ana Sayfa Vitrin Paketi (30 Gün)', 299)}
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs"
            >
              Vitrin Paketi Satın Al (299 TL)
            </button>
          </div>

          <div>
            <h4 className="text-sm font-bold text-slate-900 mb-3">Geçmiş Ödemelerim</h4>
            {payments.length === 0 ? (
              <p className="text-xs text-slate-500">Kayıtlı ödeme işleminiz bulunmamaktadır.</p>
            ) : (
              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden divide-y divide-slate-100 text-xs">
                {payments.map((p) => (
                  <div key={p.id} className="p-3.5 flex items-center justify-between">
                    <div>
                      <span className="font-semibold text-slate-900 block">{p.packageName}</span>
                      <span className="text-slate-400 text-[11px]">İşlem ID: {p.id} · {p.date}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-slate-900 tabular-nums block">
                        {p.amount} TL
                      </span>
                      <span className="text-emerald-700 text-[10px] font-semibold">Başarılı</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB CONTENT 6: PROFİL & DOĞRULAMA */}
      {activeTab === 'profil' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-6">
          <h3 className="text-base font-bold text-slate-900">Hesap Güvenliği ve Doğrulama Rozetleri</h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/50 flex items-start gap-3">
              <Phone className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold text-xs text-slate-900">Telefon Doğrulandı</div>
                <div className="text-[11px] text-slate-500 mt-0.5">{currentUser.phone}</div>
                <span className="inline-block mt-2 text-[10px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
                  ✓ Güvenli
                </span>
              </div>
            </div>

            <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/50 flex items-start gap-3">
              <Mail className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold text-xs text-slate-900">E-Posta Doğrulandı</div>
                <div className="text-[11px] text-slate-500 mt-0.5">{currentUser.email}</div>
                <span className="inline-block mt-2 text-[10px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
                  ✓ Aktif
                </span>
              </div>
            </div>

            <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/50 flex items-start gap-3">
              <Shield className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <div className="font-bold text-xs text-slate-900">Kimlik Onayı</div>
                <div className="text-[11px] text-slate-500 mt-0.5">T.C. Nüfus ve Adres Teyitli</div>
                <span className="inline-block mt-2 text-[10px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
                  ✓ Doğrulanmış Satıcı
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
