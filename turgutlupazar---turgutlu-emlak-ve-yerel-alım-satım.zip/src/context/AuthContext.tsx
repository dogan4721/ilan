import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { FirebaseAuthService, getFriendlyErrorMessage } from '../firebase/authService';
import { StorageService } from '../services/storage';
import { isConnected, testConnection } from '../firebase/config';

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isLiveFirebase: boolean;
  login: (email: string, pass: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  register: (data: {
    name: string;
    email: string;
    password: string;
    phone: string;
    role: 'user' | 'realtor';
    companyName?: string;
  }) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  switchDemoUser: (user: User) => void;
  updateUserProfile: (data: Partial<User>) => Promise<void>;
  errorMessage: string | null;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isLiveFirebase, setIsLiveFirebase] = useState<boolean>(isConnected);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    let unsubscribe = () => {};

    const initAuth = async () => {
      if (isConnected) {
        try {
          await testConnection();
          setIsLiveFirebase(true);

          unsubscribe = FirebaseAuthService.onAuthState(async (fbUser) => {
            if (fbUser) {
              const currentUsers = StorageService.getUsers();
              const matched = currentUsers.find((u) => u.id === fbUser.uid);
              if (matched) {
                setUser(matched);
              } else {
                setUser({
                  id: fbUser.uid,
                  name: fbUser.displayName || 'Kullanıcı',
                  email: fbUser.email || '',
                  phone: fbUser.phoneNumber || '',
                  role: 'user',
                  verifiedPhone: false,
                  verifiedEmail: fbUser.emailVerified,
                  verifiedIdentity: false,
                  rating: 5.0,
                  avatarUrl:
                    fbUser.photoURL ||
                    `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(
                      fbUser.displayName || 'User'
                    )}`,
                  joinedDate: 'Yeni'
                });
              }
            } else {
              // Not signed in with Firebase, fallback to default local storage demo user
              setUser(StorageService.getCurrentUser());
            }
            setIsLoading(false);
          });
        } catch {
          setIsLiveFirebase(false);
          setUser(StorageService.getCurrentUser());
          setIsLoading(false);
        }
      } else {
        setIsLiveFirebase(false);
        setUser(StorageService.getCurrentUser());
        setIsLoading(false);
      }
    };

    initAuth();

    return () => unsubscribe();
  }, []);

  const login = async (email: string, pass: string) => {
    setErrorMessage(null);
    setIsLoading(true);
    try {
      if (isLiveFirebase) {
        const u = await FirebaseAuthService.login(email, pass);
        setUser(u);
      } else {
        // LocalStorage fallback
        const users = StorageService.getUsers();
        const found = users.find((u) => u.email === email);
        if (found) {
          StorageService.setCurrentUser(found.id);
          setUser(found);
        } else {
          throw new Error('E-posta veya şifre hatalı.');
        }
      }
    } catch (err: any) {
      const msg = getFriendlyErrorMessage(err);
      setErrorMessage(msg);
      throw new Error(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithGoogle = async () => {
    setErrorMessage(null);
    setIsLoading(true);
    try {
      if (isLiveFirebase) {
        const u = await FirebaseAuthService.loginWithGoogle();
        setUser(u);
      } else {
        const u = StorageService.getUsers()[0];
        setUser(u);
      }
    } catch (err: any) {
      const msg = getFriendlyErrorMessage(err);
      setErrorMessage(msg);
      throw new Error(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (data: {
    name: string;
    email: string;
    password: string;
    phone: string;
    role: 'user' | 'realtor';
    companyName?: string;
  }) => {
    setErrorMessage(null);
    setIsLoading(true);
    try {
      if (isLiveFirebase) {
        const u = await FirebaseAuthService.register(data);
        setUser(u);
      } else {
        const newUser: User = {
          id: `user-${Date.now()}`,
          name: data.name,
          email: data.email,
          phone: data.phone,
          role: data.role,
          companyName: data.companyName,
          verifiedPhone: Boolean(data.phone),
          verifiedEmail: true,
          verifiedIdentity: false,
          rating: 5.0,
          avatarUrl: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(data.name)}`,
          joinedDate: 'Yeni'
        };
        const all = StorageService.getUsers();
        all.push(newUser);
        localStorage.setItem('tp_users_v1', JSON.stringify(all));
        StorageService.setCurrentUser(newUser.id);
        setUser(newUser);
      }
    } catch (err: any) {
      const msg = getFriendlyErrorMessage(err);
      setErrorMessage(msg);
      throw new Error(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const resetPassword = async (email: string) => {
    setErrorMessage(null);
    try {
      if (isLiveFirebase) {
        await FirebaseAuthService.resetPassword(email);
      } else {
        // Simulated
        await new Promise((r) => setTimeout(r, 600));
      }
    } catch (err: any) {
      const msg = getFriendlyErrorMessage(err);
      setErrorMessage(msg);
      throw new Error(msg);
    }
  };

  const logout = async () => {
    if (isLiveFirebase) {
      await FirebaseAuthService.logout();
    }
    // Set to demo default
    const demoUser = StorageService.getUsers()[0];
    StorageService.setCurrentUser(demoUser.id);
    setUser(demoUser);
  };

  const switchDemoUser = (targetUser: User) => {
    StorageService.setCurrentUser(targetUser.id);
    setUser(targetUser);
  };

  const updateUserProfile = async (data: Partial<User>) => {
    if (!user) return;
    const updated = StorageService.updateUser({ ...data, id: user.id });
    setUser(updated);
    if (isLiveFirebase) {
      await FirebaseAuthService.updateUserProfile(user.id, data).catch(console.warn);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isLiveFirebase,
        login,
        loginWithGoogle,
        register,
        resetPassword,
        logout,
        switchDemoUser,
        updateUserProfile,
        errorMessage,
        clearError: () => setErrorMessage(null)
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
