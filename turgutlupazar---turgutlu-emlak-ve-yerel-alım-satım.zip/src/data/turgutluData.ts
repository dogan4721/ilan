import { Category, Listing, User, Offer, Conversation, Notification, PaymentRecord } from '../types';

export const TURGUTLU_NEIGHBORHOODS = [
  'Atatürk',
  'Cumhuriyet',
  'İstasyonaltı',
  'Subaşı',
  'Yılmazlar',
  'Yeni Mahalle',
  'Selvilitepe',
  'Ergenekon',
  'Şehitler',
  'Mustafa Kemal',
  'Turan',
  'Albayrak',
  'Altay',
  'Acarlar',
  'Urganlı',
  'Derbent',
  'Avşar',
  'Akçapınar',
  'Dalbahçe',
  'Musalaryeniköy',
  'Çampınar'
] as const;

export const CATEGORIES: Category[] = [
  {
    id: 'emlak',
    name: 'Emlak',
    icon: 'Home',
    subcategories: [
      'Satılık Daire',
      'Kiralık Daire',
      'Satılık Villa',
      'Kiralık Villa',
      'Arsa',
      'Tarla',
      'Bağ',
      'Bahçe',
      'İş Yeri',
      'Dükkan',
      'Ofis',
      'Depo',
      'Bina',
      'Yazlık',
      'Diğer'
    ]
  },
  {
    id: 'arac',
    name: 'Araç',
    icon: 'Car',
    subcategories: [
      'Otomobil',
      'Motosiklet',
      'Ticari Araç',
      'Traktör',
      'Tarım Makineleri',
      'Yedek Parça',
      'Diğer'
    ]
  },
  {
    id: 'elektronik',
    name: 'Elektronik',
    icon: 'Smartphone',
    subcategories: [
      'Telefon',
      'Bilgisayar',
      'Tablet',
      'Televizyon',
      'Oyun Konsolu',
      'Elektronik Eşyalar'
    ]
  },
  {
    id: 'ev-yasam',
    name: 'Ev & Yaşam',
    icon: 'Armchair',
    subcategories: [
      'Mobilya',
      'Beyaz Eşya',
      'Ev Dekorasyonu',
      'Bahçe Ürünleri'
    ]
  },
  {
    id: 'tarim',
    name: 'Tarım',
    icon: 'Wheat',
    subcategories: [
      'Tarım Makineleri',
      'Traktör',
      'Hayvan',
      'Tohum',
      'Gübre',
      'Tarım Ürünleri',
      'Sulama Sistemleri'
    ]
  },
  {
    id: 'is-hizmet',
    name: 'İş & Hizmet',
    icon: 'Briefcase',
    subcategories: [
      'İş İlanları',
      'Usta / Hizmet',
      'Nakliye',
      'Temizlik',
      'Özel Ders',
      'Teknik Servis',
      'Diğer'
    ]
  }
];

export const DEMO_USERS: User[] = [
  {
    id: 'user-ahmet',
    name: 'Ahmet Yılmaz',
    email: 'ahmet.yilmaz@turgutlu.net',
    phone: '0532 450 12 34',
    role: 'user',
    verifiedPhone: true,
    verifiedEmail: true,
    verifiedIdentity: true,
    rating: 4.9,
    avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
    joinedDate: 'Mart 2024'
  },
  {
    id: 'user-gediz-emlak',
    name: 'Gediz Gayrimenkul Yatırım',
    email: 'info@gedizemlak.com.tr',
    phone: '0236 313 88 99',
    role: 'realtor',
    companyName: 'Gediz Gayrimenkul Ltd. Şti.',
    companyLogo: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=200&q=80',
    authorizedDocNo: 'YB-4500128',
    address: 'Atatürk Bulvarı No: 142/A, Turgutlu / Manisa',
    verifiedPhone: true,
    verifiedEmail: true,
    verifiedIdentity: true,
    rating: 5.0,
    avatarUrl: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=200&q=80',
    joinedDate: 'Ocak 2022'
  },
  {
    id: 'user-admin',
    name: 'TurgutluPazar Yönetici',
    email: 'admin@turgutlupazar.com',
    phone: '0850 300 45 45',
    role: 'admin',
    verifiedPhone: true,
    verifiedEmail: true,
    verifiedIdentity: true,
    rating: 5.0,
    avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=200&q=80',
    joinedDate: 'Ocak 2021'
  }
];

export const INITIAL_LISTINGS: Listing[] = [
  {
    id: 'tp-101',
    title: 'İstasyonaltı Mahallesi Sıfır Lüks 3+1 Daire (Kombili & Otoparklı)',
    description: 'Turgutlu İstasyonaltı Mahallesinde merkezi konumda, yeni teslim sıfır binada 145 m² geniş 3+1 daire. Ebeveyn banyolu, çift balkonlu, asansörlü ve kapalı otoparklıdır. İlkokul, lise, semt pazarı ve Turgutlu tren garına yürüme mesafesindedir. Krediye uygundur, hemen taşınmaya hazır.',
    price: 3450000,
    categoryId: 'emlak',
    subcategory: 'Satılık Daire',
    listingType: 'satilik',
    city: 'Manisa',
    district: 'Turgutlu',
    neighborhood: 'İstasyonaltı',
    street: 'Gazi Osman Paşa Cad.',
    images: [
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1600565193348-f74bd3c7ccdf?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1000&q=80'
    ],
    specs: {
      m2Gross: 145,
      m2Net: 130,
      roomCount: '3+1',
      buildingAge: '0 (Yeni)',
      floor: '3. Kat (Ara Kat)',
      heating: 'Doğalgaz (Kombi)',
      bathroomCount: 2,
      balcony: true,
      parking: true,
      elevator: true,
      deedStatus: 'Kat Mülkiyeti',
      zoningStatus: 'Konut',
      creditEligible: true
    },
    sellerId: 'user-gediz-emlak',
    sellerName: 'Gediz Gayrimenkul',
    sellerType: 'kurumsal',
    sellerPhone: '0236 313 88 99',
    sellerAvatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=200&q=80',
    sellerRating: 5.0,
    isVerifiedSeller: true,
    createdAt: '2026-09-25',
    viewCount: 412,
    favoriteCount: 28,
    status: 'active',
    isFeatured: true,
    isDoping: true,
    coordinates: { lat: 38.498, lng: 27.702 },
    priceHistory: [
      { date: '2026-09-20', price: 3600000 },
      { date: '2026-09-25', price: 3450000 }
    ]
  },
  {
    id: 'tp-102',
    title: 'Subaşı Mahallesi 2.800 m² Verimli Sultaniye Üzüm Bağı (Müstakil Parsel)',
    description: 'Subaşı mahallesinde yolu açık, elektrik ve kuyu suyu hazır, telli terbiye sistemli çekirdeksiz Sultaniye üzüm bağı. Gediz ovasının en verimli topraklarında yer almaktadır. Traktör girişi müsait, tek müstakil tapudur. Yatırıma ve tarıma son derece uygundur.',
    price: 1850000,
    categoryId: 'emlak',
    subcategory: 'Bağ',
    listingType: 'satilik',
    city: 'Manisa',
    district: 'Turgutlu',
    neighborhood: 'Subaşı',
    street: 'Karpuzkaldıran Mevkii',
    images: [
      'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=1000&q=80'
    ],
    specs: {
      m2Gross: 2800,
      m2Net: 2800,
      deedStatus: 'Müstakil Parsel',
      zoningStatus: 'Tarım',
      creditEligible: true
    },
    sellerId: 'user-ahmet',
    sellerName: 'Ahmet Yılmaz',
    sellerType: 'bireysel',
    sellerPhone: '0532 450 12 34',
    sellerAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
    sellerRating: 4.9,
    isVerifiedSeller: true,
    createdAt: '2026-09-24',
    viewCount: 285,
    favoriteCount: 19,
    status: 'active',
    isFeatured: true,
    coordinates: { lat: 38.505, lng: 27.695 }
  },
  {
    id: 'tp-103',
    title: 'Ergenekon Mahallesinde Özel Havuzlu & Bahçeli Lüks Dubleks Villa',
    description: 'Turgutlu’nun nezih bölgesi Ergenekon Mahallesinde, 450 m² arsa içerisinde 280 m² kullanım alanlı 4+1 müstakil villa. Akıllı ev sistemi, özel yüzme havuzu, yerden ısıtma ve ısı yalıtımı mevcuttur. Turgutlu manzaralı geniş teras ve otomatik kapılı kapalı garaj.',
    price: 9800000,
    categoryId: 'emlak',
    subcategory: 'Satılık Villa',
    listingType: 'satilik',
    city: 'Manisa',
    district: 'Turgutlu',
    neighborhood: 'Ergenekon',
    street: 'Çamlıca Yolu',
    images: [
      'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1000&q=80'
    ],
    specs: {
      m2Gross: 280,
      m2Net: 240,
      roomCount: '4+1',
      buildingAge: '2',
      floor: 'Müstakil 2 Kat',
      heating: 'Yerden Isıtma (Doğalgaz)',
      bathroomCount: 3,
      balcony: true,
      parking: true,
      elevator: false,
      deedStatus: 'Kat Mülkiyeti',
      zoningStatus: 'Konut',
      creditEligible: true
    },
    sellerId: 'user-gediz-emlak',
    sellerName: 'Gediz Gayrimenkul',
    sellerType: 'kurumsal',
    sellerPhone: '0236 313 88 99',
    sellerAvatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=200&q=80',
    sellerRating: 5.0,
    isVerifiedSeller: true,
    createdAt: '2026-09-23',
    viewCount: 650,
    favoriteCount: 54,
    status: 'active',
    isFeatured: true,
    coordinates: { lat: 38.512, lng: 27.715 }
  },
  {
    id: 'tp-104',
    title: 'Selvilitepe Mahallesi Kiralık Geniş 2+1 Daire (Asansörlü & Balkonlu)',
    description: 'Selvilitepe mahallesinde pazaryerine ve sağlık ocağına yakın, ara kat, ferah ve aydınlık daire. Doğalgaz kombisi takılı, laminant parkeli, boyası yeni yapılmıştır. Aile veya memur için idealdir.',
    price: 13500,
    categoryId: 'emlak',
    subcategory: 'Kiralık Daire',
    listingType: 'kiralik',
    city: 'Manisa',
    district: 'Turgutlu',
    neighborhood: 'Selvilitepe',
    street: 'Barış Sokak',
    images: [
      'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1000&q=80'
    ],
    specs: {
      m2Gross: 110,
      m2Net: 95,
      roomCount: '2+1',
      buildingAge: '4',
      floor: '2. Kat',
      heating: 'Doğalgaz (Kombi)',
      bathroomCount: 1,
      balcony: true,
      parking: false,
      elevator: true,
      creditEligible: false
    },
    sellerId: 'user-ahmet',
    sellerName: 'Ahmet Yılmaz',
    sellerType: 'bireysel',
    sellerPhone: '0532 450 12 34',
    sellerAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
    sellerRating: 4.9,
    isVerifiedSeller: true,
    createdAt: '2026-09-26',
    viewCount: 180,
    favoriteCount: 15,
    status: 'active',
    coordinates: { lat: 38.495, lng: 27.710 }
  },
  {
    id: 'tp-105',
    title: '2023 Model New Holland T580B Bahçe Traktörü (Sadece 340 Saatte)',
    description: 'Turgutlu bağ ve bahçelerine uygun kompakt bahçe tipi New Holland T580B. Orijinal 340 çalışma saatinde, servis bakımlı, 4x4 çeker, hidrolik direksiyon, 12 ileri 12 geri şanzıman. Kapalı depoda muhafaza edilmiştir.',
    price: 890000,
    categoryId: 'tarim',
    subcategory: 'Traktör',
    listingType: 'ikinci-el',
    city: 'Manisa',
    district: 'Turgutlu',
    neighborhood: 'Urganlı',
    images: [
      'https://images.unsplash.com/photo-1592861956120-e524fc739696?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1589923188900-85dae523342b?auto=format&fit=crop&w=1000&q=80'
    ],
    specs: {
      brand: 'New Holland',
      model: 'T580B 4WD',
      year: 2023,
      engineHours: 340,
      hp: 55,
      fuelType: 'Dizel',
      condition: 'Hatasız, Orijinal'
    },
    sellerId: 'user-ahmet',
    sellerName: 'Ahmet Yılmaz',
    sellerType: 'bireysel',
    sellerPhone: '0532 450 12 34',
    sellerAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
    sellerRating: 4.9,
    isVerifiedSeller: true,
    createdAt: '2026-09-22',
    viewCount: 520,
    favoriteCount: 42,
    status: 'active',
    isDoping: true,
    coordinates: { lat: 38.480, lng: 27.760 }
  },
  {
    id: 'tp-106',
    title: 'Atatürk Bulvarı Üzerinde Satılık 85 m² Köşe Başı Dükkan & Mağaza',
    description: 'Turgutlu’nun en işlek ana arteri olan Atatürk Bulvarı cepheli, vitrin genişliği 9 metre olan köşe dükkan. Bankalar, kurumsal marketler ve kafelerin yoğun olduğu lokasyonda. Hazır yüksek kira getirili kurumsal kiracılıdır.',
    price: 6250000,
    categoryId: 'emlak',
    subcategory: 'Dükkan',
    listingType: 'satilik',
    city: 'Manisa',
    district: 'Turgutlu',
    neighborhood: 'Atatürk',
    street: 'Atatürk Bulvarı No: 88',
    images: [
      'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1524758631624-e2822e304c36?auto=format&fit=crop&w=1000&q=80'
    ],
    specs: {
      m2Gross: 95,
      m2Net: 85,
      buildingAge: '6',
      floor: 'Giriş Kat',
      heating: 'Klima',
      bathroomCount: 1,
      deedStatus: 'Kat Mülkiyeti',
      zoningStatus: 'Ticari',
      creditEligible: true
    },
    sellerId: 'user-gediz-emlak',
    sellerName: 'Gediz Gayrimenkul',
    sellerType: 'kurumsal',
    sellerPhone: '0236 313 88 99',
    sellerAvatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=200&q=80',
    sellerRating: 5.0,
    isVerifiedSeller: true,
    createdAt: '2026-09-21',
    viewCount: 390,
    favoriteCount: 31,
    status: 'active',
    coordinates: { lat: 38.502, lng: 27.705 }
  },
  {
    id: 'tp-107',
    title: '2021 Toyota Corolla 1.5 Vision Multidrive S (Hatasız & Boyasız)',
    description: 'İlk sahibinden Turgutlu yetkili servis bakımlı. 48.000 km’de, tramer hasar kaydı yoktur, boyasız değişensizdir. Şerit takip, adaptif hız sabitleme, geri görüş kamerası mevcuttur. Yedek anahtarı ve kitapçıkları verilecektir.',
    price: 1120000,
    categoryId: 'arac',
    subcategory: 'Otomobil',
    listingType: 'ikinci-el',
    city: 'Manisa',
    district: 'Turgutlu',
    neighborhood: 'Cumhuriyet',
    images: [
      'https://images.unsplash.com/photo-1590362891991-f776e747a588?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=1000&q=80'
    ],
    specs: {
      brand: 'Toyota',
      model: 'Corolla 1.5 Vision Multidrive S',
      year: 2021,
      km: 48000,
      fuelType: 'Benzin',
      transmission: 'Otomatik',
      hp: 123,
      condition: 'Hatasız, Boyasız'
    },
    sellerId: 'user-ahmet',
    sellerName: 'Ahmet Yılmaz',
    sellerType: 'bireysel',
    sellerPhone: '0532 450 12 34',
    sellerAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
    sellerRating: 4.9,
    isVerifiedSeller: true,
    createdAt: '2026-09-26',
    viewCount: 340,
    favoriteCount: 29,
    status: 'active',
    coordinates: { lat: 38.500, lng: 27.708 }
  },
  {
    id: 'tp-108',
    title: 'Apple iPhone 15 Pro 256GB Natürel Titanyum (Türkiye Cihazı & Faturalı)',
    description: 'Turgutlu içi elden teslim. Apple Türkiye garantisi 14 ay daha devam ediyor. Pil sağlığı %94, kozmetik olarak nokta çiziksizdir. Kutu, fatura ve orijinal şarj kablosu ile teslim edilecektir.',
    price: 64500,
    categoryId: 'elektronik',
    subcategory: 'Telefon',
    listingType: 'ikinci-el',
    city: 'Manisa',
    district: 'Turgutlu',
    neighborhood: 'Yılmazlar',
    images: [
      'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1510557880182-3d4d3cba35a5?auto=format&fit=crop&w=1000&q=80'
    ],
    specs: {
      brand: 'Apple',
      model: 'iPhone 15 Pro 256GB',
      condition: 'Sıfır Ayarında',
      warranty: true
    },
    sellerId: 'user-ahmet',
    sellerName: 'Ahmet Yılmaz',
    sellerType: 'bireysel',
    sellerPhone: '0532 450 12 34',
    sellerAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
    sellerRating: 4.9,
    isVerifiedSeller: true,
    createdAt: '2026-09-25',
    viewCount: 290,
    favoriteCount: 22,
    status: 'active',
    coordinates: { lat: 38.503, lng: 27.701 }
  },
  {
    id: 'tp-109',
    title: 'Turgutlu & Çevre İlçeler Profesyonel Asansörlü Evden Eve Nakliyat',
    description: 'Manisa, Turgutlu, Ahmetli, Salihli ve İzmir geneli sigortalı, marangozlu ve hidrolik asansörlü taşıma hizmeti. Eşyalarınız baloncuklu naylon ve özel kolilerle sarılır. 7/24 usta ekip desteği.',
    price: 8500,
    categoryId: 'is-hizmet',
    subcategory: 'Nakliye',
    listingType: 'hizmet',
    city: 'Manisa',
    district: 'Turgutlu',
    neighborhood: 'Turan',
    images: [
      'https://images.unsplash.com/photo-1600518464441-9154a4dea21b?auto=format&fit=crop&w=1000&q=80'
    ],
    specs: {
      condition: 'Sigortalı & Faturalı Hizmet'
    },
    sellerId: 'user-ahmet',
    sellerName: 'Ahmet Yılmaz',
    sellerType: 'bireysel',
    sellerPhone: '0532 450 12 34',
    sellerAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
    sellerRating: 4.9,
    isVerifiedSeller: true,
    createdAt: '2026-09-20',
    viewCount: 160,
    favoriteCount: 11,
    status: 'active',
    coordinates: { lat: 38.497, lng: 27.706 }
  }
];

export const INITIAL_OFFERS: Offer[] = [
  {
    id: 'off-1',
    listingId: 'tp-101',
    listingTitle: 'İstasyonaltı Mahallesi Sıfır Lüks 3+1 Daire',
    listingPrice: 3450000,
    listingImage: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=600&q=80',
    buyerId: 'user-ahmet',
    buyerName: 'Ahmet Yılmaz',
    sellerId: 'user-gediz-emlak',
    offeredPrice: 3250000,
    message: 'Nakit ödeme yapacağım, tapu masrafları tarafımdan karşılanacaktır. Uygunsa yarın görüşebiliriz.',
    createdAt: '2026-09-26 14:30',
    status: 'pending'
  },
  {
    id: 'off-2',
    listingId: 'tp-105',
    listingTitle: '2023 Model New Holland T580B Bahçe Traktörü',
    listingPrice: 890000,
    listingImage: 'https://images.unsplash.com/photo-1592861956120-e524fc739696?auto=format&fit=crop&w=600&q=80',
    buyerId: 'user-gediz-emlak',
    buyerName: 'Gediz Gayrimenkul',
    sellerId: 'user-ahmet',
    offeredPrice: 840000,
    counterPrice: 865000,
    message: 'Acil bağ işleri için düşünüyoruz.',
    createdAt: '2026-09-25 11:15',
    status: 'countered'
  }
];

export const INITIAL_CONVERSATIONS: Conversation[] = [
  {
    id: 'conv-1',
    listingId: 'tp-101',
    listingTitle: 'İstasyonaltı Mahallesi Sıfır Lüks 3+1 Daire',
    listingImage: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=600&q=80',
    listingPrice: 3450000,
    buyerId: 'user-ahmet',
    buyerName: 'Ahmet Yılmaz',
    sellerId: 'user-gediz-emlak',
    sellerName: 'Gediz Gayrimenkul',
    lastMessage: 'Merhabalar, yarın saat 14:00 gibi daireyi yerinde görebilir miyiz?',
    lastMessageTime: '15:20',
    unreadCount: 1,
    messages: [
      {
        id: 'm1',
        senderId: 'user-ahmet',
        text: 'İyi günler, ilandaki daire için krediye uygunluk durumunu teyit etmek istedim.',
        timestamp: '14:45'
      },
      {
        id: 'm2',
        senderId: 'user-gediz-emlak',
        text: 'Merhaba Ahmet Bey, evet kat mülkiyetli olup ekspertiz bedelinin tamamına yakınına konut kredisi kullanılabilmektedir.',
        timestamp: '15:02'
      },
      {
        id: 'm3',
        senderId: 'user-ahmet',
        text: 'Harika, yarın saat 14:00 gibi daireyi yerinde görebilir miyiz?',
        timestamp: '15:20'
      }
    ]
  }
];

export const INITIAL_NOTIFICATIONS: Notification[] = [
  {
    id: 'notif-1',
    userId: 'user-ahmet',
    title: 'Yeni Teklif Bildirimi',
    message: 'Traktör ilanınıza 840.000 TL teklif geldi.',
    type: 'offer',
    timestamp: '1 saat önce',
    isRead: false
  },
  {
    id: 'notif-2',
    userId: 'user-ahmet',
    title: 'Favori Fiyatı Düştü!',
    message: 'Takip ettiğiniz "İstasyonaltı 3+1 Daire" fiyatı 3.600.000 TL\'den 3.450.000 TL\'ye geriledi.',
    type: 'price_drop',
    timestamp: 'Dün',
    isRead: false
  },
  {
    id: 'notif-3',
    userId: 'user-ahmet',
    title: 'İlanınız Yayında',
    message: 'Urganlı tarla ilanınız editör onayından geçti ve yayına alındı.',
    type: 'status',
    timestamp: '2 gün önce',
    isRead: true
  }
];

export const INITIAL_PAYMENTS: PaymentRecord[] = [
  {
    id: 'pay-901',
    userId: 'user-ahmet',
    userName: 'Ahmet Yılmaz',
    packageName: 'Ana Sayfa Vitrin Paketi (30 Gün)',
    amount: 349,
    date: '2026-09-24',
    method: 'card',
    status: 'completed'
  },
  {
    id: 'pay-902',
    userId: 'user-gediz-emlak',
    userName: 'Gediz Gayrimenkul',
    packageName: 'Kurumsal Emlak Ofisi Yıllık Üyelik',
    amount: 2990,
    date: '2026-09-10',
    method: 'bank_transfer',
    status: 'completed'
  }
];
