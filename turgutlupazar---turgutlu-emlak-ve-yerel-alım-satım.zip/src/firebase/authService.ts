import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  sendPasswordResetEmail,
  updateProfile,
  User as FirebaseUser,
  onAuthStateChanged
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db } from './config';
import { User } from '../types';
import { handleFirestoreError, OperationType } from './errorHandler';

export function getFriendlyErrorMessage(error: any): string {
  if (!error) return 'Beklenmeyen bir hata oluştu.';
  const code = error.code || '';

  switch (code) {
    case 'auth/email-already-in-use':
      return 'Bu e-posta adresi zaten kayıtlı. Lütfen giriş yapınız.';
    case 'auth/invalid-email':
      return 'Lütfen geçerli bir e-posta adresi giriniz.';
    case 'auth/weak-password':
      return 'Şifreniz en az 6 karakter uzunluğunda olmalıdır.';
    case 'auth/user-not-found':
    case 'auth/wrong-password':
    case 'auth/invalid-credential':
      return 'E-posta adresi veya şifre hatalı.';
    case 'auth/network-request-failed':
      return 'İnternet bağlantınızı kontrol ediniz.';
    case 'auth/popup-closed-by-user':
      return 'Google giriş penceresi kapatıldı.';
    case 'auth/too-many-requests':
      return 'Çok fazla başarısız deneme yapıldı. Lütfen biraz bekleyiniz.';
    default:
      return error.message || 'İşlem gerçekleştirilemedi.';
  }
}

export const FirebaseAuthService = {
  async register(params: {
    name: string;
    email: string;
    password: string;
    phone: string;
    role: 'user' | 'realtor';
    companyName?: string;
  }): Promise<User> {
    if (!auth || !db) {
      throw new Error('Firebase hazır değil. Demo modunda çalışıyorsunuz.');
    }

    const cred = await createUserWithEmailAndPassword(auth, params.email, params.password);
    const fbUser = cred.user;

    await updateProfile(fbUser, {
      displayName: params.name
    });

    const userProfile: User = {
      id: fbUser.uid,
      name: params.name,
      email: params.email,
      phone: params.phone || '',
      role: params.role || 'user',
      companyName: params.companyName,
      verifiedPhone: Boolean(params.phone),
      verifiedEmail: fbUser.emailVerified,
      verifiedIdentity: false,
      rating: 5.0,
      avatarUrl: fbUser.photoURL || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(params.name)}`,
      joinedDate: 'Yeni Üye'
    };

    const userDocPath = `users/${fbUser.uid}`;
    try {
      await setDoc(doc(db, 'users', fbUser.uid), userProfile);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, userDocPath);
    }

    return userProfile;
  },

  async login(email: string, password: string): Promise<User> {
    if (!auth || !db) {
      throw new Error('Firebase hazır değil. Demo modunda çalışıyorsunuz.');
    }

    const cred = await signInWithEmailAndPassword(auth, email, password);
    const fbUser = cred.user;

    const userDocPath = `users/${fbUser.uid}`;
    try {
      const snap = await getDoc(doc(db, 'users', fbUser.uid));
      if (snap.exists()) {
        return snap.data() as User;
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, userDocPath);
    }

    // Fallback if firestore document missing
    return {
      id: fbUser.uid,
      name: fbUser.displayName || 'Kullanıcı',
      email: fbUser.email || email,
      phone: fbUser.phoneNumber || '',
      role: 'user',
      verifiedPhone: false,
      verifiedEmail: fbUser.emailVerified,
      verifiedIdentity: false,
      rating: 5.0,
      avatarUrl: fbUser.photoURL || `https://api.dicebear.com/7.x/initials/svg?seed=User`,
      joinedDate: 'Kayıtlı'
    };
  },

  async loginWithGoogle(): Promise<User> {
    if (!auth || !db) {
      throw new Error('Firebase hazır değil. Demo modunda çalışıyorsunuz.');
    }

    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    const cred = await signInWithPopup(auth, provider);
    const fbUser = cred.user;

    const userDocPath = `users/${fbUser.uid}`;
    try {
      const snap = await getDoc(doc(db, 'users', fbUser.uid));
      if (snap.exists()) {
        return snap.data() as User;
      }
    } catch (err) {
      // ignore read if doesn't exist yet
    }

    // Auto-create user profile in Firestore
    const userProfile: User = {
      id: fbUser.uid,
      name: fbUser.displayName || 'Google Kullanıcısı',
      email: fbUser.email || '',
      phone: fbUser.phoneNumber || '',
      role: 'user',
      verifiedPhone: false,
      verifiedEmail: fbUser.emailVerified,
      verifiedIdentity: false,
      rating: 5.0,
      avatarUrl: fbUser.photoURL || `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(fbUser.displayName || 'Google')}`,
      joinedDate: 'Google ile Kayıtlı'
    };

    try {
      await setDoc(doc(db, 'users', fbUser.uid), userProfile);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, userDocPath);
    }

    return userProfile;
  },

  async resetPassword(email: string): Promise<void> {
    if (!auth) {
      throw new Error('Firebase hazır değil.');
    }
    await sendPasswordResetEmail(auth, email);
  },

  async logout(): Promise<void> {
    if (auth) {
      await signOut(auth);
    }
  },

  async updateUserProfile(userId: string, data: Partial<User>): Promise<void> {
    if (!db) return;
    const userDocPath = `users/${userId}`;
    try {
      await updateDoc(doc(db, 'users', userId), data);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, userDocPath);
    }
  },

  onAuthState(callback: (fbUser: FirebaseUser | null) => void) {
    if (!auth) {
      callback(null);
      return () => {};
    }
    return onAuthStateChanged(auth, callback);
  }
};
