import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  limit,
  serverTimestamp,
  increment
} from 'firebase/firestore';
import { db } from './config';
import { Listing, Offer, Conversation, Complaint, PaymentRecord, User } from '../types';
import { handleFirestoreError, OperationType } from './errorHandler';
import { INITIAL_LISTINGS } from '../data/turgutluData';

export const FirestoreService = {
  // --- LISTINGS ---
  subscribeListings(callback: (listings: Listing[]) => void) {
    if (!db) {
      callback(INITIAL_LISTINGS);
      return () => {};
    }

    const path = 'listings';
    const q = query(collection(db, path), orderBy('createdAt', 'desc'));

    return onSnapshot(
      q,
      (snapshot) => {
        if (snapshot.empty) {
          // If Firestore is empty initially, seed with our curated Turgutlu listings
          this.seedInitialListings().catch(console.error);
          callback(INITIAL_LISTINGS);
          return;
        }
        const items = snapshot.docs.map((d) => d.data() as Listing);
        callback(items);
      },
      (error) => {
        console.warn('Firestore listings subscription error (using fallback):', error);
        callback(INITIAL_LISTINGS);
      }
    );
  },

  async seedInitialListings() {
    if (!db) return;
    try {
      for (const item of INITIAL_LISTINGS) {
        await setDoc(doc(db, 'listings', item.id), item);
      }
    } catch (e) {
      console.warn('Could not seed initial listings:', e);
    }
  },

  async createListing(
    listing: Omit<Listing, 'id' | 'createdAt' | 'viewCount' | 'favoriteCount'>
  ): Promise<Listing> {
    if (!db) throw new Error('Firestore hazır değil');
    const newId = `tp-${Date.now().toString().slice(-6)}`;
    const fullListing: Listing = {
      ...listing,
      id: newId,
      createdAt: new Date().toISOString().split('T')[0],
      viewCount: 1,
      favoriteCount: 0,
      status: 'active'
    };

    const path = `listings/${newId}`;
    try {
      await setDoc(doc(db, 'listings', newId), fullListing);
      return fullListing;
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  },

  async updateListing(id: string, updates: Partial<Listing>): Promise<void> {
    if (!db) return;
    const path = `listings/${id}`;
    try {
      await updateDoc(doc(db, 'listings', id), updates);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  },

  async deleteListing(id: string): Promise<void> {
    if (!db) return;
    const path = `listings/${id}`;
    try {
      await deleteDoc(doc(db, 'listings', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  },

  async incrementView(id: string): Promise<void> {
    if (!db) return;
    try {
      await updateDoc(doc(db, 'listings', id), {
        viewCount: increment(1)
      });
    } catch {
      // quiet fail on view count
    }
  },

  // --- FAVORITES ---
  subscribeFavorites(userId: string, callback: (favorites: string[]) => void) {
    if (!db || !userId) {
      callback([]);
      return () => {};
    }

    const path = `users/${userId}/favorites`;
    return onSnapshot(
      collection(db, 'users', userId, 'favorites'),
      (snapshot) => {
        const ids = snapshot.docs.map((d) => d.id);
        callback(ids);
      },
      (error) => {
        console.warn('Favorites sync error:', error);
      }
    );
  },

  async toggleFavorite(userId: string, listingId: string, currentFavs: string[]): Promise<boolean> {
    if (!db || !userId) return false;
    const favRef = doc(db, 'users', userId, 'favorites', listingId);
    const listingRef = doc(db, 'listings', listingId);

    const isFav = currentFavs.includes(listingId);
    try {
      if (isFav) {
        await deleteDoc(favRef);
        await updateDoc(listingRef, { favoriteCount: increment(-1) }).catch(() => {});
        return false;
      } else {
        await setDoc(favRef, { addedAt: new Date().toISOString() });
        await updateDoc(listingRef, { favoriteCount: increment(1) }).catch(() => {});
        return true;
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${userId}/favorites/${listingId}`);
    }
  },

  // --- OFFERS ---
  subscribeOffers(userId: string, callback: (offers: Offer[]) => void) {
    if (!db || !userId) {
      callback([]);
      return () => {};
    }

    const path = 'offers';
    return onSnapshot(
      collection(db, path),
      (snapshot) => {
        const items = snapshot.docs
          .map((d) => d.data() as Offer)
          .filter((o) => o.buyerId === userId || o.sellerId === userId);
        callback(items);
      },
      (error) => {
        console.warn('Offers listener warning:', error);
      }
    );
  },

  async createOffer(offerData: Omit<Offer, 'id' | 'createdAt' | 'status'>): Promise<Offer> {
    if (!db) throw new Error('Firestore hazır değil');
    const newId = `off-${Date.now()}`;
    const newOffer: Offer = {
      ...offerData,
      id: newId,
      createdAt: new Date().toLocaleString('tr-TR', { dateStyle: 'short', timeStyle: 'short' }),
      status: 'pending'
    };

    const path = `offers/${newId}`;
    try {
      await setDoc(doc(db, 'offers', newId), newOffer);
      return newOffer;
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  },

  async respondToOffer(offerId: string, status: 'accepted' | 'rejected' | 'countered', counterPrice?: number): Promise<void> {
    if (!db) return;
    const path = `offers/${offerId}`;
    const updates: Partial<Offer> = { status };
    if (counterPrice) updates.counterPrice = counterPrice;

    try {
      await updateDoc(doc(db, 'offers', offerId), updates);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  },

  // --- CONVERSATIONS ---
  subscribeConversations(userId: string, callback: (conversations: Conversation[]) => void) {
    if (!db || !userId) {
      callback([]);
      return () => {};
    }

    const path = 'conversations';
    return onSnapshot(
      collection(db, path),
      (snapshot) => {
        const items = snapshot.docs
          .map((d) => d.data() as Conversation)
          .filter((c) => c.buyerId === userId || c.sellerId === userId);
        callback(items);
      },
      (error) => {
        console.warn('Conversations listener warning:', error);
      }
    );
  },

  async sendMessage(params: {
    listing: Listing;
    senderId: string;
    text: string;
    currentUser: User;
  }): Promise<void> {
    if (!db) return;

    const convId = `conv-${params.listing.id}-${params.currentUser.id}`;
    const timeStr = new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
    const msgId = `m-${Date.now()}`;

    const newMsg = {
      id: msgId,
      senderId: params.senderId,
      text: params.text,
      timestamp: timeStr
    };

    const convRef = doc(db, 'conversations', convId);
    const snap = await getDoc(convRef);

    if (snap.exists()) {
      const data = snap.data() as Conversation;
      const msgs = [...(data.messages || []), newMsg];
      await updateDoc(convRef, {
        messages: msgs,
        lastMessage: params.text,
        lastMessageTime: timeStr
      });
    } else {
      const newConv: Conversation = {
        id: convId,
        listingId: params.listing.id,
        listingTitle: params.listing.title,
        listingImage: params.listing.images[0] || '',
        listingPrice: params.listing.price,
        buyerId: params.currentUser.id,
        buyerName: params.currentUser.name,
        sellerId: params.listing.sellerId,
        sellerName: params.listing.sellerName,
        messages: [newMsg],
        lastMessage: params.text,
        lastMessageTime: timeStr,
        unreadCount: 1
      };
      await setDoc(convRef, newConv);
    }
  },

  // --- COMPLAINTS ---
  async submitComplaint(data: {
    listingId: string;
    listingTitle: string;
    reporterName: string;
    reason: string;
    details: string;
  }): Promise<void> {
    if (!db) return;
    const newId = `comp-${Date.now()}`;
    const comp: Complaint = {
      id: newId,
      ...data,
      createdAt: new Date().toISOString().split('T')[0],
      status: 'pending'
    };
    try {
      await setDoc(doc(db, 'complaints', newId), comp);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `complaints/${newId}`);
    }
  },

  // --- PAYMENTS ---
  async recordPayment(payment: Omit<PaymentRecord, 'id' | 'date'>): Promise<PaymentRecord> {
    if (!db) throw new Error('Firestore hazır değil');
    const newId = `pay-${Date.now()}`;
    const full: PaymentRecord = {
      ...payment,
      id: newId,
      date: new Date().toISOString().split('T')[0]
    };
    try {
      await setDoc(doc(db, 'payments', newId), full);
      return full;
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `payments/${newId}`);
    }
  }
};
