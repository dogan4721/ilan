import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from './config';

export const FirebaseStorageService = {
  async uploadListingImage(file: File, listingId: string): Promise<string> {
    // 1. File Type and Size Guard
    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
    if (!validTypes.includes(file.type)) {
      throw new Error('Sadece JPG, PNG veya WEBP formatında fotoğraf yükleyebilirsiniz.');
    }

    const maxSizeMB = 5;
    if (file.size > maxSizeMB * 1024 * 1024) {
      throw new Error(`Fotoğraf boyutu en fazla ${maxSizeMB} MB olabilir.`);
    }

    // 2. Client-side Image Optimization to WebP if supported
    const optimizedBlob = await this.optimizeImage(file);

    // 3. Upload to Firebase Storage if available
    if (storage) {
      try {
        const filename = `${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.]/g, '_')}`;
        const storageRef = ref(storage, `listings/${listingId}/${filename}`);
        await uploadBytes(storageRef, optimizedBlob, {
          contentType: 'image/webp'
        });
        const downloadUrl = await getDownloadURL(storageRef);
        return downloadUrl;
      } catch (err) {
        console.warn('Firebase Storage upload failed, falling back to local object preview:', err);
      }
    }

    // Graceful fallback: Base64 data URL
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(optimizedBlob);
    });
  },

  optimizeImage(file: File): Promise<Blob> {
    return new Promise((resolve) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.src = url;

      img.onload = () => {
        URL.revokeObjectURL(url);
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        // Max dimension 1600px for web performance
        const maxDim = 1600;
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          canvas.toBlob(
            (blob) => {
              resolve(blob || file);
            },
            'image/webp',
            0.85
          );
        } else {
          resolve(file);
        }
      };

      img.onerror = () => resolve(file);
    });
  }
};
