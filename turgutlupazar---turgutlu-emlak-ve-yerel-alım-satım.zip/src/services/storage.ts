import {
  Listing,
  Offer,
  Conversation,
  Notification,
  User,
  Complaint,
  PaymentRecord,
  Category
} from '../types';
import {
  INITIAL_LISTINGS,
  INITIAL_OFFERS,
  INITIAL_CONVERSATIONS,
  INITIAL_NOTIFICATIONS,
  INITIAL_PAYMENTS,
  DEMO_USERS,
  CATEGORIES
} from '../data/turgutluData';

const KEYS = {
  LISTINGS: 'tp_listings_v1',
  FAVORITES: 'tp_favorites_v1',
  OFFERS: 'tp_offers_v1',
  CONVERSATIONS: 'tp_conversations_v1',
  NOTIFICATIONS: 'tp_notifications_v1',
  CURRENT_USER_ID: 'tp_current_user_id_v1',
  USERS: 'tp_users_v1',
  COMPLAINTS: 'tp_complaints_v1',
  PAYMENTS: 'tp_payments_v1',
  CATEGORIES: 'tp_categories_v1',
  ANNOUNCEMENT: 'tp_announcement_v1'
};

export const StorageService = {
  // --- USERS ---
  getUsers(): User[] {
    const raw = localStorage.getItem(KEYS.USERS);
    if (!raw) {
      localStorage.setItem(KEYS.USERS, JSON.stringify(DEMO_USERS));
      return DEMO_USERS;
    }
    return JSON.parse(raw);
  },

  getCurrentUser(): User {
    const users = this.getUsers();
    const currentId = localStorage.getItem(KEYS.CURRENT_USER_ID) || 'user-ahmet';
    const found = users.find(u => u.id === currentId);
    return found || users[0];
  },

  setCurrentUser(userId: string): User {
    localStorage.setItem(KEYS.CURRENT_USER_ID, userId);
    return this.getCurrentUser();
  },

  updateUser(updated: Partial<User> & { id: string }): User {
    const users = this.getUsers().map(u => (u.id === updated.id ? { ...u, ...updated } : u));
    localStorage.setItem(KEYS.USERS, JSON.stringify(users));
    return users.find(u => u.id === updated.id)!;
  },

  // --- LISTINGS ---
  getListings(): Listing[] {
    const raw = localStorage.getItem(KEYS.LISTINGS);
    if (!raw) {
      localStorage.setItem(KEYS.LISTINGS, JSON.stringify(INITIAL_LISTINGS));
      return INITIAL_LISTINGS;
    }
    return JSON.parse(raw);
  },

  saveListings(listings: Listing[]) {
    localStorage.setItem(KEYS.LISTINGS, JSON.stringify(listings));
  },

  getListingById(id: string): Listing | undefined {
    return this.getListings().find(l => l.id === id);
  },

  addListing(listing: Omit<Listing, 'id' | 'createdAt' | 'viewCount' | 'favoriteCount'>): Listing {
    const listings = this.getListings();
    const newId = `tp-${Date.now().toString().slice(-5)}`;
    const fullListing: Listing = {
      ...listing,
      id: newId,
      createdAt: new Date().toISOString().split('T')[0],
      viewCount: 1,
      favoriteCount: 0,
      status: 'active'
    };
    const updated = [fullListing, ...listings];
    this.saveListings(updated);

    // Notify user
    this.addNotification({
      userId: listing.sellerId,
      title: 'İlanınız Yayına Alındı',
      message: `"${listing.title}" başlıklı ilanınız TurgutluPazar'da yayında!`,
      type: 'status'
    });

    return fullListing;
  },

  updateListing(id: string, updates: Partial<Listing>): Listing | null {
    const listings = this.getListings();
    const index = listings.findIndex(l => l.id === id);
    if (index === -1) return null;

    // Check if price changed
    const oldPrice = listings[index].price;
    const newPrice = updates.price;
    let priceHistory = listings[index].priceHistory || [];

    if (newPrice && newPrice !== oldPrice) {
      priceHistory = [
        ...priceHistory,
        { date: new Date().toISOString().split('T')[0], price: newPrice }
      ];

      // If price decreased, notify users who favorited
      if (newPrice < oldPrice) {
        this.addNotification({
          userId: 'user-ahmet',
          title: 'İlan Fiyatı Düştü!',
          message: `"${listings[index].title}" fiyatı ${oldPrice.toLocaleString('tr-TR')} TL'den ${newPrice.toLocaleString('tr-TR')} TL'ye indi.`,
          type: 'price_drop'
        });
      }
    }

    const updatedItem = {
      ...listings[index],
      ...updates,
      priceHistory
    };

    listings[index] = updatedItem;
    this.saveListings(listings);
    return updatedItem;
  },

  deleteListing(id: string): boolean {
    const listings = this.getListings().filter(l => l.id !== id);
    this.saveListings(listings);
    return true;
  },

  incrementView(id: string) {
    const listings = this.getListings();
    const item = listings.find(l => l.id === id);
    if (item) {
      item.viewCount = (item.viewCount || 0) + 1;
      this.saveListings(listings);
    }
  },

  // --- FAVORITES ---
  getFavorites(): string[] {
    const raw = localStorage.getItem(KEYS.FAVORITES);
    if (!raw) return ['tp-101', 'tp-102'];
    return JSON.parse(raw);
  },

  toggleFavorite(listingId: string): boolean {
    const favs = this.getFavorites();
    const listings = this.getListings();
    const listing = listings.find(l => l.id === listingId);

    let isFav = false;
    let newFavs: string[];

    if (favs.includes(listingId)) {
      newFavs = favs.filter(id => id !== listingId);
      if (listing && listing.favoriteCount > 0) {
        listing.favoriteCount -= 1;
      }
    } else {
      newFavs = [...favs, listingId];
      isFav = true;
      if (listing) {
        listing.favoriteCount = (listing.favoriteCount || 0) + 1;
      }
    }

    localStorage.setItem(KEYS.FAVORITES, JSON.stringify(newFavs));
    this.saveListings(listings);
    return isFav;
  },

  // --- OFFERS ---
  getOffers(): Offer[] {
    const raw = localStorage.getItem(KEYS.OFFERS);
    if (!raw) {
      localStorage.setItem(KEYS.OFFERS, JSON.stringify(INITIAL_OFFERS));
      return INITIAL_OFFERS;
    }
    return JSON.parse(raw);
  },

  createOffer(params: {
    listingId: string;
    offeredPrice: number;
    message?: string;
  }): Offer {
    const user = this.getCurrentUser();
    const listing = this.getListingById(params.listingId)!;
    const offers = this.getOffers();

    const newOffer: Offer = {
      id: `off-${Date.now()}`,
      listingId: listing.id,
      listingTitle: listing.title,
      listingPrice: listing.price,
      listingImage: listing.images[0] || '',
      buyerId: user.id,
      buyerName: user.name,
      sellerId: listing.sellerId,
      offeredPrice: params.offeredPrice,
      message: params.message,
      createdAt: new Date().toLocaleString('tr-TR', { dateStyle: 'short', timeStyle: 'short' }),
      status: 'pending'
    };

    const updated = [newOffer, ...offers];
    localStorage.setItem(KEYS.OFFERS, JSON.stringify(updated));

    // Notify seller
    this.addNotification({
      userId: listing.sellerId,
      title: 'Yeni Teklif Alındı',
      message: `${user.name}, "${listing.title}" ilanınız için ${params.offeredPrice.toLocaleString('tr-TR')} TL teklif sundu.`,
      type: 'offer'
    });

    return newOffer;
  },

  respondToOffer(
    offerId: string,
    action: 'accept' | 'reject' | 'counter',
    counterPrice?: number
  ): Offer | null {
    const offers = this.getOffers();
    const offer = offers.find(o => o.id === offerId);
    if (!offer) return null;

    if (action === 'accept') {
      offer.status = 'accepted';
      this.addNotification({
        userId: offer.buyerId,
        title: 'Teklifiniz Kabul Edildi! 🎉',
        message: `"${offer.listingTitle}" için sunduğunuz ${offer.offeredPrice.toLocaleString('tr-TR')} TL teklif kabul edildi. Satıcı ile iletişime geçebilirsiniz.`,
        type: 'offer'
      });
    } else if (action === 'reject') {
      offer.status = 'rejected';
      this.addNotification({
        userId: offer.buyerId,
        title: 'Teklif Reddedildi',
        message: `"${offer.listingTitle}" için verdiğiniz teklif satıcı tarafından kabul edilmedi.`,
        type: 'offer'
      });
    } else if (action === 'counter' && counterPrice) {
      offer.status = 'countered';
      offer.counterPrice = counterPrice;
      this.addNotification({
        userId: offer.buyerId,
        title: 'Karşı Teklif Geldi!',
        message: `Satıcı "${offer.listingTitle}" için ${counterPrice.toLocaleString('tr-TR')} TL karşı teklif sundu.`,
        type: 'offer'
      });
    }

    localStorage.setItem(KEYS.OFFERS, JSON.stringify(offers));
    return offer;
  },

  // --- CONVERSATIONS & CHAT ---
  getConversations(): Conversation[] {
    const raw = localStorage.getItem(KEYS.CONVERSATIONS);
    if (!raw) {
      localStorage.setItem(KEYS.CONVERSATIONS, JSON.stringify(INITIAL_CONVERSATIONS));
      return INITIAL_CONVERSATIONS;
    }
    return JSON.parse(raw);
  },

  sendMessage(params: {
    listingId: string;
    text: string;
  }): Conversation {
    const user = this.getCurrentUser();
    const listing = this.getListingById(params.listingId)!;
    const convs = this.getConversations();

    let conv = convs.find(
      c =>
        c.listingId === params.listingId &&
        (c.buyerId === user.id || c.sellerId === user.id)
    );

    const timeStr = new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
    const newMsg = {
      id: `m-${Date.now()}`,
      senderId: user.id,
      text: params.text,
      timestamp: timeStr
    };

    if (conv) {
      conv.messages.push(newMsg);
      conv.lastMessage = params.text;
      conv.lastMessageTime = timeStr;
      if (conv.sellerId === user.id) {
        conv.unreadCount = 0;
      }
    } else {
      conv = {
        id: `conv-${Date.now()}`,
        listingId: listing.id,
        listingTitle: listing.title,
        listingImage: listing.images[0] || '',
        listingPrice: listing.price,
        buyerId: user.id,
        buyerName: user.name,
        sellerId: listing.sellerId,
        sellerName: listing.sellerName,
        messages: [newMsg],
        lastMessage: params.text,
        lastMessageTime: timeStr,
        unreadCount: 1
      };
      convs.unshift(conv);
    }

    localStorage.setItem(KEYS.CONVERSATIONS, JSON.stringify(convs));

    // Notify other party
    const targetUserId = user.id === listing.sellerId ? conv.buyerId : listing.sellerId;
    this.addNotification({
      userId: targetUserId,
      title: `Yeni Mesaj: ${user.name}`,
      message: params.text.slice(0, 60),
      type: 'message'
    });

    return conv;
  },

  // --- NOTIFICATIONS ---
  getNotifications(): Notification[] {
    const raw = localStorage.getItem(KEYS.NOTIFICATIONS);
    if (!raw) {
      localStorage.setItem(KEYS.NOTIFICATIONS, JSON.stringify(INITIAL_NOTIFICATIONS));
      return INITIAL_NOTIFICATIONS;
    }
    return JSON.parse(raw);
  },

  addNotification(notif: Omit<Notification, 'id' | 'timestamp' | 'isRead'>) {
    const list = this.getNotifications();
    const item: Notification = {
      ...notif,
      id: `notif-${Date.now()}`,
      timestamp: 'Az önce',
      isRead: false
    };
    localStorage.setItem(KEYS.NOTIFICATIONS, JSON.stringify([item, ...list]));
  },

  markNotificationsRead() {
    const list = this.getNotifications().map(n => ({ ...n, isRead: true }));
    localStorage.setItem(KEYS.NOTIFICATIONS, JSON.stringify(list));
  },

  // --- COMPLAINTS ---
  getComplaints(): Complaint[] {
    const raw = localStorage.getItem(KEYS.COMPLAINTS);
    if (!raw) return [];
    return JSON.parse(raw);
  },

  submitComplaint(params: {
    listingId: string;
    listingTitle: string;
    reason: string;
    details: string;
  }) {
    const user = this.getCurrentUser();
    const complaints = this.getComplaints();
    const newComp: Complaint = {
      id: `comp-${Date.now()}`,
      listingId: params.listingId,
      listingTitle: params.listingTitle,
      reporterName: user.name,
      reason: params.reason,
      details: params.details,
      createdAt: new Date().toISOString().split('T')[0],
      status: 'pending'
    };
    complaints.unshift(newComp);
    localStorage.setItem(KEYS.COMPLAINTS, JSON.stringify(complaints));
  },

  resolveComplaint(complaintId: string, action: 'dismiss' | 'remove_listing') {
    const complaints = this.getComplaints();
    const c = complaints.find(item => item.id === complaintId);
    if (!c) return;

    if (action === 'dismiss') {
      c.status = 'dismissed';
    } else {
      c.status = 'listing_removed';
      this.deleteListing(c.listingId);
    }
    localStorage.setItem(KEYS.COMPLAINTS, JSON.stringify(complaints));
  },

  // --- PAYMENTS & DOPING ---
  getPayments(): PaymentRecord[] {
    const raw = localStorage.getItem(KEYS.PAYMENTS);
    if (!raw) {
      localStorage.setItem(KEYS.PAYMENTS, JSON.stringify(INITIAL_PAYMENTS));
      return INITIAL_PAYMENTS;
    }
    return JSON.parse(raw);
  },

  recordPayment(record: Omit<PaymentRecord, 'id' | 'date'>): PaymentRecord {
    const list = this.getPayments();
    const newRec: PaymentRecord = {
      ...record,
      id: `pay-${Date.now()}`,
      date: new Date().toISOString().split('T')[0]
    };
    const updated = [newRec, ...list];
    localStorage.setItem(KEYS.PAYMENTS, JSON.stringify(updated));

    this.addNotification({
      userId: record.userId,
      title: 'Ödeme Başarılı',
      message: `${record.packageName} siparişiniz başarıyla onaylandı (${record.amount} TL).`,
      type: 'status'
    });

    return newRec;
  },

  // --- CATEGORIES ---
  getCategories(): Category[] {
    const raw = localStorage.getItem(KEYS.CATEGORIES);
    if (!raw) {
      localStorage.setItem(KEYS.CATEGORIES, JSON.stringify(CATEGORIES));
      return CATEGORIES;
    }
    return JSON.parse(raw);
  },

  addCategory(name: string, subcategories: string[]) {
    const cats = this.getCategories();
    const id = name.toLowerCase().replace(/[^a-z0-9]/g, '-') as any;
    cats.push({
      id,
      name,
      icon: 'Tag',
      subcategories
    });
    localStorage.setItem(KEYS.CATEGORIES, JSON.stringify(cats));
  },

  // --- SYSTEM ANNOUNCEMENT ---
  getAnnouncement(): string {
    return (
      localStorage.getItem(KEYS.ANNOUNCEMENT) ||
      'TurgutluPazar ile Manisa Turgutlu bölgesinde güvenli gayrimenkul ve yerel alım-satım deneyimi! Komisyonsuz ilan verin.'
    );
  },

  setAnnouncement(text: string) {
    localStorage.setItem(KEYS.ANNOUNCEMENT, text);
  },

  // --- RESET ALL DATA ---
  resetToDefault() {
    localStorage.clear();
    window.location.reload();
  }
};
