export type CategoryId = 'emlak' | 'arac' | 'elektronik' | 'ev-yasam' | 'tarim' | 'is-hizmet';

export interface Category {
  id: CategoryId;
  name: string;
  icon: string;
  subcategories: string[];
}

export type ListingType = 'satilik' | 'kiralik' | 'ikinci-el' | 'sifir' | 'hizmet';

export interface ListingSpecs {
  // Emlak
  m2Net?: number;
  m2Gross?: number;
  roomCount?: string; // örn: "3+1", "2+1", "4+2"
  buildingAge?: string; // örn: "0 (Yeni)", "5-10"
  floor?: string; // örn: "3. Kat", "Bahçe Katı"
  heating?: string; // Doğalgaz (Kombi), Yerden Isıtma, Soba
  bathroomCount?: number;
  balcony?: boolean;
  parking?: boolean;
  elevator?: boolean;
  deedStatus?: string; // Kat Mülkiyeti, Kat İrtifakı, Hisseli, Müstakil Parsel
  zoningStatus?: string; // Konut, Ticari, Tarım, Sanayi
  creditEligible?: boolean;

  // Araç & Tarım
  brand?: string;
  model?: string;
  year?: number;
  km?: number;
  engineHours?: number; // Traktör için çalışma saati
  fuelType?: string; // Dizel, Benzin, Hibrit, Elektrik
  transmission?: string; // Manuel, Otomatik
  hp?: number; // Beygir gücü
  condition?: string; // Boyasız, Değişensiz, vb.

  // Genel
  warranty?: boolean;
}

export interface Listing {
  id: string;
  title: string;
  description: string;
  price: number;
  categoryId: CategoryId;
  subcategory: string;
  listingType: ListingType;
  city: string; // Manisa
  district: string; // Turgutlu
  neighborhood: string; // İstasyonaltı, Subaşı, Selvilitepe vs.
  street?: string;
  images: string[];
  specs: ListingSpecs;
  sellerId: string;
  sellerName: string;
  sellerType: 'bireysel' | 'kurumsal';
  sellerPhone: string;
  sellerAvatar?: string;
  sellerRating: number;
  isVerifiedSeller: boolean;
  createdAt: string; // YYYY-MM-DD
  viewCount: number;
  favoriteCount: number;
  status: 'active' | 'passive' | 'pending' | 'sold';
  isFeatured?: boolean; // Vitrin ilanı
  isDoping?: boolean; // Acil / Fırsat
  priceHistory?: { date: string; price: number }[];
  coordinates?: { lat: number; lng: number };
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'user' | 'realtor' | 'admin';
  companyName?: string;
  companyLogo?: string;
  authorizedDocNo?: string; // Taşınmaz Ticareti Yetki Belgesi No
  address?: string;
  verifiedPhone: boolean;
  verifiedEmail: boolean;
  verifiedIdentity: boolean;
  rating: number;
  avatarUrl: string;
  joinedDate: string;
}

export interface Offer {
  id: string;
  listingId: string;
  listingTitle: string;
  listingPrice: number;
  listingImage: string;
  buyerId: string;
  buyerName: string;
  sellerId: string;
  offeredPrice: number;
  counterPrice?: number;
  message?: string;
  createdAt: string;
  status: 'pending' | 'accepted' | 'rejected' | 'countered';
}

export interface MessageItem {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
}

export interface Conversation {
  id: string;
  listingId: string;
  listingTitle: string;
  listingImage: string;
  listingPrice: number;
  buyerId: string;
  buyerName: string;
  sellerId: string;
  sellerName: string;
  messages: MessageItem[];
  lastMessage: string;
  lastMessageTime: string;
  unreadCount: number;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'message' | 'offer' | 'status' | 'price_drop' | 'system';
  linkTarget?: string;
  timestamp: string;
  isRead: boolean;
}

export interface Complaint {
  id: string;
  listingId: string;
  listingTitle: string;
  reporterName: string;
  reason: string;
  details: string;
  createdAt: string;
  status: 'pending' | 'reviewed' | 'dismissed' | 'listing_removed';
}

export interface PaymentRecord {
  id: string;
  userId: string;
  userName: string;
  packageName: string;
  amount: number;
  date: string;
  method: 'card' | 'bank_transfer' | 'secure_pay';
  status: 'completed' | 'pending';
}
